/*
 Implementare la classe MyString, che rappresenta una stringa con la seguente caretteristica: due oggetti
MyString sono considerati uguali (da equals) se sono uno l'anagramma dell'altro. Inoltre, la classe MyString
deve essere clonabile e deve offrire un'implementazione di hashCode coerente con equals e non banale (che
non restituisca lo stesso codice hash per tutti gli oggetti).
Suggerimento: Nella classe String è presente il metodo public char charAt(int i), che restituisce l'iesimo
carattere della stringa, per i compreso tra 0 e length()-1.

Esempio d'uso:
MyString a = new MyString("uno due tre");
MyString b = new MyString("uno tre deu");
MyString c = new MyString("ert unodue");
MyString d = c.clone();
System.out.println(a.equals(b));
System.out.println(b.equals(c));
System.out.println(a.hashCode()==b.hashCode());

Output dell'esempio d'uso:
true
false
true

 */
package esame.pkg12.pkg03.pkg09;
import java.util.*;


class MyString implements Cloneable{
        private String S;
        private final int i=0;
        
    public MyString(String s){
        this.S=s;
        
    }
    
    public MyString clone(){
        try{
            MyString s=(MyString) super.clone(); return s;
        }
        catch(CloneNotSupportedException c){
            return null;
        }
    }
    
    public boolean equals(MyString x){
        if(S.charAt(i))
            
    }
    
      public char charAt(int i){
          return S.charAt(i);
      }
    
    
}


(bo)public class Esame120309 {
    public static void main(String[] args) {
       MyString a = new MyString("uno due tre");
        MyString b = new MyString("uno tre deu");
        MyString c = new MyString("ert unodue");
        MyString d = c.clone();
        System.out.println(a.equals(b));
        System.out.println(b.equals(c));
        System.out.println(a.hashCode()==b.hashCode());
    }
    
}
