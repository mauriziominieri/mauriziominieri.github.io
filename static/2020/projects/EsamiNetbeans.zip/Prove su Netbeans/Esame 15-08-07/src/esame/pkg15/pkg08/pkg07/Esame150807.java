package esame.pkg15.pkg08.pkg07;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

class A {
        public String f(A x, long l, float m) { return "A1"; }
        public String f(A x, byte l, int m) { return "A2"; }
        public String f(B x, short l, boolean m) { return "A3"; }
}
class B extends A {
        //public String f(A y, long m, float p) { return "B1"; }
       // public String f(A y, long m, long p) { return "B2"; }
      //  public String f(Object y, double m, float p) { return "B3"; }
}

/*
Per un sito di domande e risposte, realizzare le classi Question e Answer. Ogni risposta è associata
ad un’unica domanda e gli utenti possono votare la risposta migliore invocando il metodo voteUp
di Answer. Inoltre, il metodo getBestAnswer restituisce in tempo costante la risposta (o una delle risposte) che ha ottenuto il maggior numero di voti.
Rispettare il seguente caso d’uso.
Caso d’uso:
Question q = new Question("Dove␣si␣trova␣Albuquerque?");
Answer a1 = new Answer(q, "Canada");
Answer a2 = new Answer(q, "New␣Mexico");
a1.voteUp();
System.out.println(q.getBestAnswer());
a2.voteUp();
a2.voteUp();
System.out.println(q.getBestAnswer());
Output:
Canada
New Mexico
*/



class Question{
    
    private String domanda;
   // protected TreeSet<Answer> S;     //Un set ordinato. Io lo ordinerò in base al voto delle risposte, quindi dovrò implementare Comparable<Answer> sotto. Il tree set non funzionerà perchè si, aggiunge in ordine, ma NON ordina l'array, 
      protected ArrayList<Answer> S;
    public Question(String d){
        domanda=d;
        S=new ArrayList();
    }

    public Answer getBestAnswer(){  
         // return S.first();      //il primo elemento del TreeSet sarà quello con il voto maggiore
         return S.get(0);
    }
}

class Answer{
    private String risposta;
    private int voto=0;
    Question quest;
    
    public Answer(Question q,String r){
        risposta=r;                //creo l'oggetto canada e l'oggetto mexico entrambi con l'attributo voto=0
        quest=q;
    }
    
    public void voteUp(){
         voto++;             //quando lo voto allora incremento il suo parametro voto
         if(!quest.S.contains(this))
            quest.S.add(this);   //Aggiungo l'oggetto nel TreeSet e grazie al compareTo gia so che verrà messo in ordine decrescente di voto
        // System.out.println("S : "+quest.S);
         Collections.sort(quest.S,new Comparator<Answer>(){
             public int compare(Answer a,Answer b){
                  if(a.voto<b.voto) return 1;             //senso decrescente (l'answer con il voto maggiore sarà il primo elemento nel TreeSet)
        else if(a.voto>b.voto) return -1;
        else return 0;
             }
         });
         
        //  System.out.println("S : "+quest.S);
    }
    
   /* public int compareTo(Answer a){
        if(voto<a.voto) return 1;             //senso decrescente (l'answer con il voto maggiore sarà il primo elemento nel TreeSet)
        else if(voto>a.voto) return -1;
        else return 0;
    }*/
    
    public String toString(){
        return risposta;
    }
}


/*
Implementare la classe thread-safe TimeToFinish, che permette a diversi thread di comunicare
quanto tempo manca alla propria terminazione. Il metodo setEstimate accetta un long che rappresenta
il numero di millisecondi che mancano al thread chiamante per terminare la sua esecuzione
(cioè, il time-to-finish). Il metodo maxTimeToFinish restituisce in tempo costante il numero di
millisecondi necessari perché tutti i thread terminino. La stringa restituita da toString riporta il
time-to-finish di tutti i thread.
Suggerimento: il metodo statico System.currentTimeMillis() restituisce un long che rappresenta il
numero di millisecondi trascorsi dal 1 gennaio 1970 (POSIX time).
Caso d’uso:
TimeToFinish ttf = new TimeToFinish();
ttf .setEstimate(5000);
// a questo punto un altro thread invoca ttf .setEstimate(3000)
Thread.sleep(500);
System.out.println("Tempo␣rimanente:␣" + ttf.maxTimeToFinish() + "␣millisecondi.");
System.out.println( ttf );
Output:
Tempo rimanente: 4500 millisecondi.
Thread 1: 2500
Thread main: 4500

*/



class TimeToFinish{
    private Map<Thread,Long> m=new HashMap();
    private Long maxTime;
   
   
    public void setEstimate(long tf){
             if(maxTime == null || maxTime < tf) 
                maxTime = tf + System.currentTimeMillis();
            
            m.put(Thread.currentThread(),tf + System.currentTimeMillis());
    }
    public long maxTimeToFinish(){
       
        return maxTime-System.currentTimeMillis();
    }
    
  
    public String toString(){
        String res="";
        for(Thread t: m.keySet()){
             res=res+t+": "+(m.get(t)-System.currentTimeMillis())+"\n";
        }
        return res;
    }
}



public class Esame150807 {
    public static void main(String[] args) throws InterruptedException {
        
        B beta = new B();
        A alfa = beta;
       // System.out.println( alfa . f ( alfa , (short)500, 1));
       // System.out.println(beta. f ( alfa , (short)500, 1));
       // System.out.println(beta. f (beta, (short)500,1));
        //System.out.println(beta. f (beta, (byte)1, 2L));
        
        
        /*Question q = new Question("Dove␣si␣trova␣Albuquerque?");
        Answer a1 = new Answer(q, "Canada");
        Answer a2 = new Answer(q, "New Mexico");
        a1.voteUp();
        System.out.println(q.getBestAnswer());
        a2.voteUp();
        a2.voteUp();
        System.out.println(q.getBestAnswer());*/
        
        
      TimeToFinish ttf = new TimeToFinish();
      ttf.setEstimate(5000);
      Thread t = new Thread(){
            public void run(){
                    ttf.setEstimate(3000);
            }
     };
     t.start();
     Thread.sleep(500);
     System.out.println("Tempo rimanente: " + ttf.maxTimeToFinish() + " millisecondi.");
     System.out.println(ttf) ;
       
    }
    
}
