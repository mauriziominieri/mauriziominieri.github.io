/*
 Implementare la classe BoundedMap, che rappresenta una mappa con capacità limitata. Il costruttore
accetta la dimensione massima della mappa. I metodi get e put sono analoghi a quelli dell'interfaccia Map.
Se però la mappa è piena e viene invocato il metodo put con una chiave nuova, verrà rimossa dalla mappa
la chiave che fino a quel momento è stata ricercata meno volte con get.
L'implementazione deve rispettare il seguente caso d'uso.

Esempio d'uso:
BoundedMap<String,String> m = new BoundedMap<String,String>(2);
m.put("NA", "Napoli");
m.put("SA", "Salerno");
System.out.println(m.get("NA"));
m.put("AV", "Avellino");
System.out.println(m.get("SA"));

Output dell'esempio d'uso:
Napoli
null
 */
package esame.pkg12.pkg18.pkg06;
import java.util.*;

class BoundedMap<T1,T2>{
    
    private Map<T1,T2> Map;
    private int dim_max;
    
    public BoundedMap(int dim_max){
        Map=new HashMap<>();
        this.dim_max=dim_max;
    }
    
    public void put(T1 key,T2 value){
        
        if(Map.size()<dim_max)
           Map.put(key,value);
        else                                //Scorro le chiavi cercando il minimo
        {
              T1 min;
              for(T1 t: Map.keySet())
                  if(max...)
                     min=t;
                     
                     
                  Map.remove(min);
        }
    }
    
    public T2 get(T1 key){               //Qui dovrei incrementare un campo conta all'interno della key, quindi avrei NA 1 Napoli...
         
         return Map.get(key); 
    }
    
    public void Stampa(){
         System.out.println(Map);
    }
}

(??)public class Esame121806 {
    public static void main(String[] args) {
      BoundedMap<String,String> m = new BoundedMap<String,String>(2);
        m.put("NA", "Napoli");
        m.put("SA", "Salerno");
        m.Stampa();
        System.out.println(m.get("NA"));
        m.put("NA", "Avellino");
        m.Stampa();
        System.out.println(m.get("SA"));
    }
    
}
