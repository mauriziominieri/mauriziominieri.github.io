package esame.pkg18.pkg03.pkg23;
import java.util.*;

/**
Implementare la classe Studente e le due sottoclassi Triennale e Magistrale. Uno studente è
caratterizzato da nome e matricola. Ciascuna sottoclasse ha un prefisso che viene aggiunto a
tutte le sue matricole. Due studenti sono considerati uguali da equals se hanno lo stesso nome e
la stessa matricola (compreso il prefisso).
L’implementazione deve rispettare il seguente esempio d’uso:
Esempio d’uso:
Studente.Triennale. setPrefisso ("N86");
Studente.Magistrale. setPrefisso ("N97");
Object luca1 = new Studente.Triennale("Luca", "004312"),
luca2 = new Studente.Triennale("Luca", "004312"),
anna1 = new Studente.Triennale("Anna", "004312"),
anna2 = new Studente.Magistrale("Anna", "004312");
System.out.println(luca1.equals(luca2));
System.out.println(anna1.equals(anna2));
System.out.println(anna1);
Output:
true
false
Anna N86/004312
 */


class Studente{
    private static String nome,matricola;
    
    public Studente(String n,String m){
        nome=n;
        matricola=m;
    }
    
    public String toString(){
        if(this.getClass()==Triennale.class)
           return nome+" "+Triennale.prefisso+"/"+matricola;
        else
              return nome+" "+Magistrale.prefisso+"/"+matricola;
    }
    
    public boolean equals(Studente student){
       // System.out.println("nome : "+nome+", student.nome : "+student.nome);
        // System.out.println("matricola : "+matricola+", student.matricola : "+student.matricola);
        if(nome.compareTo(student.nome)==0 && matricola.compareTo(student.matricola)==0 && this.getClass()==student.getClass())
            return true;
        else
            return false;
    }

    static class Triennale extends Studente{
        private static String prefisso;
      //  private static String nome,matricola_t;
        
        public Triennale(String n,String m){
            super(n,m);
         /*   matricola_t=prefisso.concat(m);
            System.out.println("matricola Triennale : "+matricola_t);*/
        }
        
        public static void setPrefisso(String s){
             prefisso=s;
         }
        
       
    }

    static class Magistrale extends Studente{
         private static String prefisso;
        //  private static String nome,matricola_m;
         
         public Magistrale(String n,String m){
            super(n,m);
          /*  matricola_m=prefisso.concat(m);
            System.out.println("matricola Magistrale : "+matricola_m);*/
        }
         
         public static void setPrefisso(String s){
             prefisso=s;
         }
    }

}

/*
Implementare il metodo statico isSetSmaller, che accetta due insiemi e un comparatore, e restituisce
vero se e solo se tutti gli elementi del primo insieme sono più piccoli, in base al comparatore,
di tutti gli elementi del secondo insieme.
Porre particolare attenzione alla scelta della firma.
*/

class Prova<T>{
    
    public static <T> boolean isSetSmaller(ArrayList<Integer> A,ArrayList<Integer> B,Comparator<ArrayList<Integer>> c){
       
        c=new Comparator<ArrayList<Integer>>(){
            int c_p=0;
            int c_m=0;
            public int compare(ArrayList<Integer> A, ArrayList<Integer> B) {
                for(int i=0;i<A.size();i++)
                {
                  if(A.get(i)>B.get(i)) c_p++;
                  else if(A.get(i)<B.get(i)) c_m++;
                }
                
                if(c_p==A.size())
                    return -1;
                else if(c_m==A.size())
                    return 1;
                else return 0;
            }
        
         };
  
        if(c.compare(A,B)==1)
            return true;
        else 
           return false;
    }
}
 
public class Esame180323 {

   
    public static void main(String[] args) {
        
        //ESERCIZIO1
        /*Studente.Triennale.setPrefisso("N86");
        Studente.Magistrale.setPrefisso ("N97");
        Studente luca1 = new Studente.Triennale("Luca", "004312"),
        luca2 = new Studente.Triennale("Luca", "004312"),
        anna1 = new Studente.Triennale("Anna", "004312"),
        anna2 = new Studente.Magistrale("Anna", "004312");
        System.out.println(luca1.equals(luca2));
        System.out.println(anna1.equals(anna2));
        System.out.println(anna1);*/
        
        
        ArrayList<Integer> A,B;
        A=new ArrayList();
        B=new ArrayList();
        A.add(1);
        A.add(2);
        A.add(3);
        B.add(8);
        B.add(9);
        B.add(0);
        
        Comparator c=new Comparator() {
            @Override
            public int compare(Object t, Object t1) {
                throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }
        };
      
        Prova<Integer> p=new Prova<Integer>();
        System.out.println(p.isSetSmaller(A,B,c));
        
    }
    
}
