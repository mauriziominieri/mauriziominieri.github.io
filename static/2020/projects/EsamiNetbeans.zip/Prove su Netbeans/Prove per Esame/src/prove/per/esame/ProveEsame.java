//INGEGNERIA

package prove.per.esame;
import com.sun.xml.internal.bind.v2.schemagen.xmlschema.TopLevelElement;
import java.util.*; 

 
abstract class A{
   String owner;
   
    
  void deposit(String amount){   }
  
  abstract void withdrawal(String amount);
}


class B extends A{
  
    
    void processCheck(String checkToProcess){     }
    
    void withdrawal(String amount){   }
}


class C extends A{
  
    
    void depositMonthlyInterest(){     }

    @Override
    void withdrawal(String amount) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
   
}

public class ProveEsame{ 
    public static void main(String[] args) {
      
     
         
    }
 }