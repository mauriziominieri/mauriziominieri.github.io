package esame.pkg17.pkg01.pkg25;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;



/*
Realizzare l’enumerazione LengthUnit, che rappresenta le principali unità di misura di lunghezza,
dei sistemi metrico e imperiale: centimetri (CM), metri (M), kilometri (KM), pollici (INCH),
iarde (YARD), e miglia (MILE). Il metodo convertTo accetta un’altra unità di misura u e un
numero in virgola mobile x, e converte x da questa unità di misura a u.
I fattori di conversione per le misure imperiali sono i seguenti: 
1 pollice = 0.0254 metri, 1 iarda = 0.914 metri, 1 miglio = 1609 metri.
L’implementazione deve rispettare il seguente esempio d’uso.
Esempio d’uso:
System.out.println(LengthUnit.CM.convertTo(LengthUnit.INCH, 10));
System.out.println(LengthUnit.KM.convertTo(LengthUnit.YARD, 3.5)
);
System.out.println(LengthUnit.MILE.convertTo(LengthUnit.M, 6.2));
Output:
3.9370078740157486
3829.3216630196935
9975.800000000001
*/

enum LengthUnit{       //Ogni elemento avrà un numero che rappresetna la sua conversione in metri
    CM(100),              
    M(1),
    KM(1000),
    INCH(0.0254),
    YARD(0.914),
    MILE(1609);

    private double metri;
    
    private LengthUnit(double d){
        metri=d;         //In questo modo posso fare in modo che ogni elemento dell'enumerazione abbia un numero (conv)
    }
    
    public double convertTo(LengthUnit u,double x){
       
        return (x*this.metri)/u.metri;       //se da metri voglio passare a centimetri basta fare: metri*1/100  -> 1m=0.01cm
                                             //da metri a centimetri stesso ragionamento: centimetri*100/1      -> 1cm=100m
               //e questo ragionamento vale per ogni singola cosa.  In pratica porto tutto nello stesso sistema di riferimento, il metro.    
    }
}






/*Esercizio 1
Implementare il metodo statico mergeIfSorted, che accetta due liste a e b, e un comparatore c, e
restituisce un’altra lista. Inizialmente, usando due thread diversi, il metodo verifica che le liste
a e b siano ordinate in senso non decrescente (ogni thread si occupa di una lista). Poi, se le liste
sono effettivamente ordinate, il metodo le fonde (senza modificarle) in un’unica lista ordinata,
che viene restituita al chiamante. Se, invece, almeno una delle due liste non è ordinata, il metodo
termina restituendo null.
Il metodo dovrebbe avere complessità di tempo lineare.
Porre particolare attenzione alla scelta della firma, considerando i criteri di funzionalità, completezza,
correttezza, fornitura di garanzie e semplicità.
*/


public class Esame170125 {
    
   
    
    
    
    private static boolean flag,flag1;
    static Comparator comp;
    
    //Ho usato qesta firma perchè è FUNZIONALE. COMPLETA. CORRETTA. Le due liste non si possono modificare, quindi fornisce 
    //ulteriori garanzie. SEMPLICE. SPECIFICA.
    public static <T> List<T> mergeIfSorted(List<?> a,List<?> b,Comparator<T> c){
        List<T> L_r=new LinkedList();
        comp=c;
        Thread t1=new MyThread(a),t2=new MyThread1(b); 
        t1.start(); t2.start();
        
        try {
            t1.join();                      //Se non lo mettessi il thread man andrebbe nell'if ancor prima che i thread vadano nelle run
                    } catch (InterruptedException ex) {
            Logger.getLogger(Esame170125.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        if(flag==true&&flag1==true){
           L_r.addAll((Collection<? extends T>) a);
           L_r.addAll((Collection<? extends T>) b);
           Collections.sort(L_r,comp);
            
           return L_r;
        }
        else
            return null;
    }
    
    static class MyThread extends Thread{
        private List L;
        
        public MyThread(List<?> l){
             L=l;
        }
       
        public void run(){
             Iterator it=L.iterator();
             System.out.println("SONO : "+Thread.currentThread().getName()+" L : "+L);
             int n1=(int)it.next();
             while(it.hasNext()){
                int n2=(int)it.next();
                 if(comp.compare(n1,n2)==1)
                 { 
                      System.out.println("FALSA");
                      return;
                 }
                 n1=n2;
             }
              flag=true;    
        }  
    }
    
    static class MyThread1 extends Thread{
        private List L;
        
        public MyThread1(List<?> l){
             L=l;
        }
       
        public void run(){
             Iterator it=L.iterator();
             System.out.println("SONO : "+Thread.currentThread().getName()+" L : "+L);
             int n1=(int)it.next();
             while(it.hasNext()){
                int n2=(int)it.next();
                 if(comp.compare(n1,n2)==1)
                 { 
                      System.out.println("FALSA1");
                      return;
                 }
                 n1=n2;
             }
              flag1=true;    
        }  
    }
    
    public static void main(String[] args) throws InterruptedException {
       
        //ESERCIZIO 1
        LinkedList top1=new LinkedList(),top2=new LinkedList();
        
        top1.add(1);
        top1.add(3); 
        top1.add(5); 
        top2.add(4); 
        top2.add(5);
        top2.add(6);
        
        Comparator c=new Comparator<Integer>(){
            public int compare(Integer i1, Integer i2) {
              if(i1>i2) return 1;
              else if(i1<i2) return -1;
              else return 0;
            }   
        };

        System.out.println("L_merged : "+mergeIfSorted(top1, top2, c));
        
        
        
        
        //ESERCIZIO 2
        System.out.println(LengthUnit.CM.convertTo(LengthUnit.INCH, 10));
        System.out.println(LengthUnit.KM.convertTo(LengthUnit.YARD, 3.5));
        System.out.println(LengthUnit.MILE.convertTo(LengthUnit.M, 6.2)); 
    }
    
}
