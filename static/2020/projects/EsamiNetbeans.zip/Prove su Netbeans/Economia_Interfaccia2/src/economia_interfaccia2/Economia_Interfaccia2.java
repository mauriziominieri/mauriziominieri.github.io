/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package economia_interfaccia2;
import java.util.*;


public class Economia_Interfaccia2 {

    public static Map<String,double[]> Map1=new HashMap(){            //peso,prezzo,p.tec.,estetica,comfort
        {                                               put("settore1",new double[]{0.03,0.14,0.52,0.03,0.28});
                                                        put("settore2",new double[]{0.08,0.27,0.47,0.04,0.14});
                                                        put("settore3",new double[]{0.28,0.08,0.32,0.18,0.14});
                                                        put("settore4",new double[]{0.03,0.12,0.52,0.27,0.06});
                                                        put("settore5",new double[]{0.7,0.50,0.29,0.03,0.11});
        }};  
    
    public static Map<String,double[]> Map2=new HashMap(){
        {
                                                       put("ASUS ROG GL503VL",new double[]{0.10,0.20,0.35,0.20,0.15});
                                                       put("ASUS ZEN UX3907",new double[]{0.20,0.30,0.10,0.10,0.30});
                                                       put("SURFACE LAPTOP 15",new double[]{0.15,0.15,0.30,0.20,0.20});
                                                       put("XPS 15 9560",new double[]{0.40,0.10,0.10,0.10,0.30});
        }
    };
    
    
    public static void main(String[] args) {
        Pc_Selector n=new Pc_Selector();
        
      
    }
    
}
