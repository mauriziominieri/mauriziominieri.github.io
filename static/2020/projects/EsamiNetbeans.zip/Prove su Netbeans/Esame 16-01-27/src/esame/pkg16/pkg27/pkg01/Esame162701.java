package esame.pkg16.pkg27.pkg01;
import java.util.*;


/*//esercizio 1
 class A {                                           
           public String f(A x,Object y) { return "A1"; }
           public String f(Object x,A y) { return "A2"; }
}

class B extends A {
	public String f(A x, Object y) { return "B1"; }
	public String f(A x,A y) { return "B2"; }
	public String f(B x,B y) { return "B3"; }
       
}
class C extends B {
	public String f(B x,B y) { return "C1"; }
        
}
*/


/*    //Esercizio 2
 Un oggetto Curriculum rappresenta una sequenza di lavori, ognuno dei quali è un'istanza della classe Job.
Il costruttore di Curriculum accetta il nome di una persona. Il metodo addJob aggiunge un lavoro alla
sequenza, caratterizzato da una descrizione e dall'anno di inizio, restituendo un nuovo oggetto di tipo
Job. Infine, la classe Job offre il metodo next, che restituisce in tempo costante il lavoro successivo nella
sequenza (oppure null).
Implementare le classi Curriculum e Job, rispettando il seguente caso d'uso

Caso d'uso:
Curriculum cv = new Curriculum("Walter White");
Curriculum.Job j1 = cv.addJob("Chimico", 1995);
Curriculum.Job j2 = cv.addJob("Insegnante", 2005);
Curriculum.Job j3 = cv.addJob("Cuoco", 2009);
System.out.println(j2.next());
System.out.println(j3.next());

Cuoco: 2009
null
 */

class Curriculum{
    private ArrayList<Job> A;
    private String nome;
    
    public Curriculum(String n){
        A=new ArrayList();
        nome=n;
    }
    
    public Job addJob(String d,int a){
        Job j=new Job(d,a);
        A.add(j);
        return j;
    }
    
    class Job{
        private String descrizione;
        private int anno;
        private int id;
        public Job(String d,int a){
            descrizione=d;
            anno=a;
            id=A.size();
        }
        
        public Job next(){
            if(A.size()==id+1)
                return null;
            
            return A.get(id+1);
        }
        
        public String toString(){
            return descrizione+": "+anno;
        }
    }
}

/* //Esercizio 3
La seguente classe A fa riferimento ad una classe B. Implementare la classe B in modo che venga
compilata correttamente e permetta la compilazione della classe A.
public class A
{
    public static <S,T extends S> void f(Set<S> set1, Set<T> set2)
    {
        B.process(set1, set2);
        B.process(set2, set1);
        B<S> b = new B<S>();
        S choice1 = b.select (set1),
        choice2 = b.select (set2);
        Collection<? extends S> c = b.filter(set1);
        HashSet<? super S> hs = b.filter(set1);
    }
}
*/

 /*
class B<T>{                

    public static <T,V> void process(Set<T> S1,Set<V> S2){
        
    }
    
    public T select(Set<?> S){
        T t=(T) new B();
        return t;
    }
    
    public HashSet<T> filter(Set<T> S){
        HashSet<T> set=new HashSet();
        return set;
    }
}

class A
{
    public static <S,T extends S> void f(Set<S> set1, Set<T> set2)   //il trucco è capire quando mettere <?> oppure <T>
    {
        B.process(set1, set2);         //process accetta come parametri (<S>,<T>) e anche (<T>,<S>) quindi è evidente che process deve accettare <?><?> come tipo, oppure <T><V>
        B.process(set2, set1);
        B<S> b = new B<S>();
        S choice1 = b.select(set1), choice2 = b.select(set2);      //select accetta <S><T> quindi steso discroso, accetta <?> per forza.
        Collection<? extends S> c = b.filter(set1);        //filter deve restituire un tipo <T>, dato che <?> non può essere convertito in <? extends T>
        HashSet<? super S> hs = b.filter(set1);       //filter restituisce Collection e HashSet, Collection può essere convertito in Colelction? si, Collection può in HashSet? NO, quindi filter deve restituire un HashSet
    }
}
*/

/*  Esercizio 4
Implementare il metodo statico twoPhases, che accetta due Iterable<Runnable> ed esegue in
parallelo tutti i Runnable contenuti nel primo Iterable (prima fase), seguiti da tutti i Runnable
contenuti nel secondo Iterable (seconda fase). Precisamente, appena l’i-esimo Runnable del primo
gruppo termina, quel thread passa ad eseguire l’i-esimo Runnable del secondo gruppo.
*/



public class Esame162701 {
    
    
    /*//esercizio 4
    public static void twoPhases(Iterable<Runnable> L1,Iterable<Runnable> L2){   //1 2 3 4      6 7 8 9
               Iterator<Runnable> i1=L1.iterator();      //Gli iterable sono semplicemnte liste, ma per scorrerle e accedere agli elementi devi usare l'iterator
               Iterator<Runnable> i2=L2.iterator();
               while(i1.hasNext()){
                    Runnable runnableOfL2 = i1.hasNext() ? i2.next() : null;  //runnableOfL2 sarà il runnable di L2 se c'è, oppure null se non c'è.
                    Thread t=new Thread(i1.next()){      //creo un thread (classe anonima) sul primo runnable della lista L1 (ricorda che il metodo next() restituisce l'i-esimo elemento della i'esima chiamata. 
                       public void run(){
                           super.run();                //esegue i1.next(), cioè il primo runnable di L1, è come se avessi fatto: i1.next().run();
                        
                          if(runnableOfL2!=null)       //se il runnable di L2 esiste   
                               runnableOfL2.run();    //lo eseguo
                       }
                    };
                   t.start();                          //e lo starto, quindi vado nel run che sta sopra.
               }
               
               while(i2.hasNext()){       //se la lista2 è più lunga della 1 allora vado a eseguire tutti i suoi runnable rimanenti
                    Thread t=new Thread(i2.next()){      //creo un thread (classe anonima) sul primo runnable della lista a
                       public void run(){
                           super.run();
                       }
                    };
                   t.start();
               }
    }*/
 
    public static void main(String[] args) {
        
           // B beta=new C();         // ESERCIZIO 1
           // A alfa=beta;
   
           //  System.out.println(beta.f((C)alfa,beta));  
           // System.out.println(beta.f(beta,null));                                         
            // System.out.println(beta.f((Object)beta,alfa));
            // System.out.println(alfa.f(beta,beta));
         //  System.out.println(beta.getClass());  
     
         
     
     
                 //Esercizio 2
           /*Curriculum cv = new Curriculum("Walter White");
           Curriculum.Job j1 = cv.addJob("Chimico", 1995);
           Curriculum.Job j2 = cv.addJob("Insegnante", 2005);
           Curriculum.Job j3 = cv.addJob("Cuoco", 2009);
           System.out.println(j2.next());
           System.out.println(j3.next());  */
         
            
            
           
          /* final class myRunnable implements Runnable {
			private int id, sleep;
			public myRunnable(int id, int sleep){
				this.id=id; this.sleep=sleep;
			}
			public void run(){
				//System.out.println("I'm myRunnable " + id + ". I'll sleep for "+sleep+" second(s) then die.");
				try {
					Thread.sleep(sleep*1000);
				} catch (InterruptedException e) {
					return;
				}
				System.out.println("I'm myRunnable " + id + ". I slept for "+sleep+" second(s) and am now dying.");
			}
		}
		
		List<Runnable> a = new ArrayList<Runnable>();
		a.add(new myRunnable(1,10));
		a.add(new myRunnable(2,2));
		a.add(new myRunnable(3,8));
                a.add(new myRunnable(4,8));
		List<Runnable> b = new ArrayList<Runnable>();
		b.add(new myRunnable(11,4));
		b.add(new myRunnable(22,3));
		b.add(new myRunnable(33,1));
		b.add(new myRunnable(44,2));
		Esame162701.twoPhases(a, b);*/
                           
    }  
}
