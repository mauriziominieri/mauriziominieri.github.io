/*  //Esercizio 2
Implementare le classi Song e Playlist. Una canzone è caratterizzata dal nome e dalla durata in secondi.
Una playlist è una lista di canzoni, compresi eventuali duplicati, ed offre il metodo add, che aggiunge una
canzone in coda alla lista, e remove, che rimuove tutte le occorrenze di una canzone dalla lista. Infine, la
classe Playlist è dotata di ordinamento naturale basato sulla durata totale di ciascuna playlist.
Sono preferibili le implementazioni in cui il confronto tra due playlist avvenga in tempo costante.

Caso D'uso:
Song one = new Song("One", 275), two = new Song("Two", 362);
Playlist a = new Playlist(), b = new Playlist();
a.add(one); a.add(two); a.add(one);
b.add(one); b.add(two);
System.out.println(a.compareTo(b));
a.remove(one);
System.out.println(a.compareTo(b));

Output:
1 -1
 */
package esame.pkg14.pkg28.pkg07;
import java.util.*;


           //Esercizio 1
class A {
    public String f(Object x, double n) { return "A1"; }
    public String f(A x, int n) { return "A2"; }
    private String f(B x, int n) { return "A3"; }
}
class B extends A {
    private String f(A x, double n) { return "B1"; }
    public String f(B x, double n) { return "B2:" + f((A) x, 2); }
    public String f(A x, long n) { return "B3"; }
}
class C extends B {
    public String f(A x, int n) { return "C1"; }
   
}





class Song{                         //Esercizio 2
    private String nome;
    private int durata;
    
    public Song(String nome,int durata){
        this.nome=nome;
        this.durata=durata;
    }
    
    public int getDurata(){
        return durata;
    }
    public String getNome(){
        return nome;
    }
  
    public String toString(){
        return nome;
    }
    
}

class Playlist{
    
    private LinkedList<Song> top;
    private int ordinamento_naturale;
    
    public Playlist(){
        top=new LinkedList<>();
    }
    
    public void add(Song x){
        top.add(x);
        ordinamento_naturale=ordinamento_naturale+x.getDurata();
    }
    
    
    
    public void remove(Song x){
        Iterator i = top.iterator();                            //creo un iteratore i sulla lista top
        Song curr = null;
        
        while(i.hasNext()) {                                    //finchè i incontra il prossimo elemento
            curr = (Song) i.next();                            //i.next() restituirà il primo elemento, poi il secondo e cosi via
            if (curr.getNome().equals(x.getNome())) {          //quindi curr all'inizio sarà il primo elemento della lista
                i.remove();
                ordinamento_naturale=ordinamento_naturale-x.getDurata();
            }
        }
    }
    
    
    public int compareTo(Playlist x){                                               
        if(this.ordinamento_naturale>x.ordinamento_naturale)
            return 1;
        else if(this.ordinamento_naturale<x.ordinamento_naturale)
           return -1;
        else
            return 0;
    }
    
    public void Stampa(){
        System.out.println(top);
    }
   
    
}



/*
Un Exchanger è un oggetto che serve a due thread per scambiarsi due oggetti dello stesso tipo. Ciascun
thread invocherà il metodo exchange passandogli il proprio oggetto e riceverà come risultato l'oggetto
passato dall'altro thread. Il primo thread che invoca exchange dovrà aspettare che anche il secondo thread
invochi quel metodo, prima di ricevere il risultato. Quindi, il metodo exchange risulta bloccante per il
primo thread che lo invoca e non bloccante per il secondo.
Un Exchanger può essere usato per un solo scambio. Ulteriori chiamate ad exchange dopo le prime due
portano ad un'eccezione.
Nell'esempio d'uso, due thread condividono il seguente oggetto:
Exchanger<String> e = new Exchanger<String>();
Thread 1:
String a = e.exchange("ciao");
System.out.println(a);
Thread 2:
String a = e.exchange("Pippo");
System.out.println(a);
Output thread 1:
Pippo
Output thread 2:
ciao

*/



class MyThread<T> extends Thread{
   
   
    @Override
    public void run() {
        System.out.println("Thread started:::"+Thread.currentThread().getName());
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("Thread ended:::"+Thread.currentThread().getName());
    }
    
}

class Exchanger<T>{

        public T exchange(T s)
        {
              try{ 
                  synchronized(s){
                       s.wait();
                  }
              }
              catch(InterruptedException e){
                   e.printStackTrace();
              }
              
              return o;
        }
}


public class Esame142807 {
    public static void main(String[] args) {
        
       /*          //ESERCIZIO 1
        C gamma = new C();
        B beta = new B();
        A alfa = gamma;
        //System.out.println( alfa . f (gamma, 2L));             
       // System.out.println(beta. f (beta, 5.0) );
        //System.out.println(gamma.f(beta, 5.0));
         //System.out.println(11 & 3);*/
       
       
        /*               // Esercizio 2
        Song one = new Song("One", 275), two = new Song("Two", 362);           
        Playlist a = new Playlist(), b = new Playlist();
        a.add(one); a.add(two); a.add(one);
        b.add(one); b.add(two);
       // a.Stampa();
        //b.Stampa();  
        System.out.println(a.compareTo(b));           //Il metodo compareTo mi fa pensare subito che devo implementare l'interfaccia Iterable
        a.remove(one);                               //deve cancellare OGNI occorrenza dell'oggetto one nella lista.
       // a.Stampa();
       // b.Stampa();  
        System.out.println(a.compareTo(b));*/
        
       
       
        Exchanger<String> e = new Exchanger<String>();
        Thread t1=new MyThread();
        String a = e.exchange("ciao");
        System.out.println(a);
        Thread t2=new MyThread();
        
        String b = e.exchange("Pippo");
        System.out.println(b);
        

    }
}


/*
public class Esame142807 {

    public static void main(String[] args) {
        Thread t1 = new Thread(new MyRunnable(), "t1");
        Thread t2 = new Thread(new MyRunnable(), "t2");
        Thread t3 = new Thread(new MyRunnable(), "t3");
        
        t1.start();
        
        //dico al thread main di aspettare 2 secondi o la fine del thread1 per andare avanti
        try {
            t1.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        
        t2.start();
        
        //start third thread only when first thread is dead
        try {
            t1.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        
        t3.start();
        
        //let all threads finish execution before finishing main thread
        try {
            t1.join();
            t2.join();
            t3.join();
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        
        System.out.println("All threads are dead, exiting main thread");
    }

}

class MyRunnable implements Runnable{

    @Override
    public void run() {
        System.out.println("Thread started:::"+Thread.currentThread().getName());
        try {
            Thread.sleep(4000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("Thread ended:::"+Thread.currentThread().getName());
    }
    
}*/