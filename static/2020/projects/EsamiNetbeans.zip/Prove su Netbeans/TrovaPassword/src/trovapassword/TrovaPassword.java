/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trovapassword;
import java.util.*;


public class TrovaPassword {
    public static void main(String[] args) {
     
        Frame1 f=new Frame1();
    }
    
}
