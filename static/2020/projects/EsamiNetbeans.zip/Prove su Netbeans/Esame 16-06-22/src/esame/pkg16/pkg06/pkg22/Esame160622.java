package esame.pkg16.pkg06.pkg22;
import java.util.*;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.logging.Level;
import java.util.logging.Logger;

class A {
    public String f(Object[] x, A y) { return "A0"; }
    public String f(A[] x, A y) { return "A1"; }
    public String f(A[] x, B y) { return "A2"; }
}
class B extends A {
    public String f(A[] x, A y) { return "B1"; }
    public String f(B x, A y) { return "B2:" + f((A) x, null); }
    public String f(B[] x, A y) { return "B3"; }
    private String f(A x, A y) { return "B4"; }
}





/*
Realizzare la classe BlockingArray, che rappresenta un array di dimensione fissa, in cui diversi
thread mettono e tolgono elementi.
Il costruttore accetta la dimensione dell’array. Inizialmente, tutte le celle risultano vuote. Il
metodo put(i, x) inserisce l’oggetto x nella cella i-esima, aspettando se quella cella è occupata.
Simmetricamente, il metodo take(i) preleva l’oggetto dalla cella i-esima, aspettando se quella
cella è vuota. La classe deve risultare thread-safe.
L’implementazione deve rispettare il seguente esempio d’uso.

Esempio d’uso:
BlockingArray<String> array = new BlockingArray<>(10);
array.put(0, "uno");
array.put(1, "due");
System.out.println(array.take(0));
array.put(1, "tre");
Output:
uno
A questo punto il thread si ferma
finché un altro thread non invocherà take(1)*/

//

class BlockingArray<T>{
    private T[] A;
    public BlockingArray(int d){
        A=(T[]) new Object[d];
    }
    public void put(int i,T x){
        
        synchronized(A){
              if(A[i]!=null){         //se la cella è piena aspetta. se un altro thread va nel put 
                                     // e mette un elemento in una cella vuota non va nell'if, mette l'elemento e sveglia tutti i thread sull'array
                try {
                   A.wait(); } 
                catch (InterruptedException ex) {return;}
              }
             
                 A[i]=x;
                 A.notifyAll();   
        }
    }
    public T take(int i){
      
        synchronized(A){
              if(A[i]==null)
              {
                  try {
                         A.wait(); } 
                     catch (InterruptedException ex) {return null;}
              }
              
              A.notifyAll();
              return A[i];
        }
    }
    
    
}


/*
Il metodo statico arePermutations, accetta due liste e controlla se contengono gli stessi elementi
(secondo equals), anche in ordine diverso.
Valutare ciascuna delle seguenti intestazioni in base ai criteri di funzionalità, completezza, correttezza,
fornitura di ulteriori garanzie e semplicità. Scegliere l’intestazione migliore oppure
proporne un’altra. Infine, implementare il metodo usando l’intestazione prescelta.
a) boolean arePermutations(List<?> a, List<?> b)
b) <S,T> boolean arePermutations(List<S> a, List<T> b)
c) <S> boolean arePermutations(List<S> a, List<S> b)
d) <S> boolean arePermutations(List<? extends S> a, List<? extends S> b)
e) boolean arePermutations(List<Object> a, List<Object> b)
f) <S, T extends S> boolean arePermutations(List<? extends S> a, List<? extends T> b)
*/

//a) FUNZIONALE. COMPLETA. NON CORRETTA, lista di stringhe e interi. ULT GAR. SEMPLICE. SPECIFICA.
//b) FUNZIONALE. COMPLETA. NON CORRETTA. NON ULT GAR. NON SEMPLICE. SPECIFICA.
//c) FUNZIONALE. NON COMPLETA, sono lo stesso tipo. CORRETTA. NON ULT GAR. SEMPLICE. SPECIFICA
//d) FUNZIONALE. COMPLETA, se S è object allora posso prendere qualsiasi tipo. NON CORRETTA. ULT GAR. SEMPLICE. SPECIFICA
//e) FUNZIONALE. NON COMPLETA, solo Obejct. CORRETTA. NON ULT GAR. SEMPLICE. SPECIFICA.
//f) FUNZIONALE. COMPLETA(?). CORRETTA(?). ULT GAR. NON SEMPLICE. SPECIFICA.



/*
Dire quali delle seguenti sono specifiche valide per un Comparator tra due oggetti di tipo Set<Integer>,
motivando la risposta. Nei casi non previsti dalle specifiche, il comparatore restituisce 0.
compare(a, b) restituisce:
a) −1 se a contiene un numero minore di tutti i numeri di b; 1 se b contiene un numero minore
di tutti i numeri di a
b) −1 se la somma dei numeri di a è minore della somma dei numeri di b; 1 se la media dei
numeri di b è maggiore della media dei numeri di a
c) −1 se a contiene tutti numeri negativi e b no; 1 se b contiene tutti numeri positivi e a no
d) −1 se a contiene il numero 0; 1 se a non contiene il numero 0
e) −1 se a contiene il numero 0 e b no; 1 se b contiene il numero 0 e a no
*/
//a) RIFLESSIVA, il confronto tra a ed a può essere fatto e il risultato sarà 0.
     //2) prop2. ovvia, se viene -1 significa che a contiene un numero < di tutti i numeri di b, implica che a contiene un numero < di tutti i num di b? ovvio.
     //3) prop3. se viene 0 allora vuol dire che a non contiene un numero < di tutti i numeri di b e viceversa (quindi a e b saranno uguali), implica che b non contiene un numero minore di tutti quelli di a e viceversa? vera  
     //TRANSITIVA, a contiene un num < di tutti i num di b, b contiene un num < di tutti i num di c, a contiene un num < di tutti i num di c? Ovvio.
public class Esame160622 {
    
    public static <S, T extends S> boolean arePermutations(List<? extends S> a, List<? extends T> b){
        int c=0;
      
          if(a.size()!=b.size()) return false;
          for(int i=0;i<a.size();i++)
              for(int j=0;j<b.size();j++)
                   if(a.get(i).equals(b.get(j)))
                      c++;
          
          if(c==a.size())
             return true;
          return false;
    }
    
    
    
    public static void main(String[] args) {
        B beta = new B();
        A alfa = beta;
        B[] arr = new B[10];
       /* System.out.println(alfa.f(null, alfa));
        System.out.println(beta. f (arr [0], alfa ));
        System.out.println(beta. f (arr [0], arr [1]) );
       // System.out.println(beta. f (arr, beta));  //Non si può definire la più specifica tra B3 e A2, le candidate sono B1 B3 A1 A2 A0
        System.out.println(5871 | 5871);       //Ovviamente il risultato è 5871, non mi interessa manco trasformarlo in bit
                                               //se ho un AND tra 1011 e se stesso è ovvio che avrò 1011. Idem per l'OR
*/
                                               
                 
      /* List<Integer> A=new ArrayList();
       List<Integer> B=new ArrayList();
       A.add(3);
        A.add(7);
         A.add(2);
          B.add(2);
        B.add(7);
         B.add(3);
         
         System.out.println(arePermutations(A,B));*/
      
      
       //ESERCIZIO 3
        BlockingArray<String> array = new BlockingArray<>(10);
        array.put(0, "uno");
        array.put(1, "due");
        System.out.println(array.take(0));
        array.put(1, "tre");
        
   
    }
}
