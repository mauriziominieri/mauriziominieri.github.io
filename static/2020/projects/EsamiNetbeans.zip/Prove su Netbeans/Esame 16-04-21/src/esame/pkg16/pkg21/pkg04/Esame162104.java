package esame.pkg16.pkg21.pkg04;

import java.util.*;


//ESERCIZIO 1
class A {                                           
           public String f(Object x,A y) { return "A1"; }
           private String f(B x,C y) { return "A2"; }
}

class B extends A {
	public String f(Object x, A y) { return "B1"+" "+f(this,new B()); }
	public String f(A x,B y) { return "B2"; }
       
}
class C extends B {
	public String f(Object x,B y) { return "C1"+f(this,y); }
        public String f(B x,C y) { return "C2"; }
      
        
}


 /*ESERCIZIO 2
Realizzare la classe Engine, che rappresenta un motore a combustione, caratterizzato da
cilindrata (in cm3) e potenza (in cavalli). Normalmente, due oggetti Engine sono uguali se hanno la stessa
cilindrata e la stessa potenza. Il metodo byVolume converte questo Engine in modo che venga confrontata
solo la cilindrata. Analogamente, il metodo byPower converte questo Engine in modo che venga confrontata
solo la potenza.
L'implementazione deve rispettare il seguente esempio d'uso

Esempio d'uso:
Engine a = new Engine(1200, 69), b = new Engine(1200, 75), c = new Engine(1400, 75);
System.out.println(a);
System.out.println(a.equals(b));
Engine aVol = a.byVolume(), bVol = b.byVolume();
System.out.println(aVol);
System.out.println(aVol.equals(bVol));
System.out.println(a==aVol);
Engine bPow = b.byPower(), cPow = c.byPower();
System.out.println(bPow);
System.out.println(bPow.equals(cPow));

Output:
(1200.0 cm3, 69.0 CV)
false
(1200.0 cm3, 69.0 CV)
true
false
(1200.0 cm3, 75.0 CV)
true
 */
class Engine {

    private double cilindrata;
    private double potenza;

    public Engine(double c, double p) {
        cilindrata = c;
        potenza = p;
    }

    public boolean equals(Engine e) {
        if (cilindrata == e.cilindrata && potenza == e.potenza) 
            return true;

        return false;
    }

    public Engine byVolume() {
        return new Engine(cilindrata, potenza) {
            public boolean equals(Engine e) {
                if (cilindrata == e.cilindrata) {
                    return true;
                }
                return false;
            }
        };
    }

    public Engine byPower() {
        return new Engine(cilindrata, potenza) {
            public boolean equals(Engine e) {
                if (potenza == e.potenza) {
                    return true;
                }
                return false;
            }
        };
    }

    public String toString() {
        return "("+cilindrata+" cm3, "+potenza+" CV)";
    }
}


/*
Il metodo count accetta una LinkedList e restituisce un intero. Il suo contratto è il seguente:
   pre-condizione La lista contiene stringhe.
   post-condizione Restituisce la somma delle lunghezze delle stringhe presenti nella lista.
Dire quali dei seguenti sono contratti validi per un overriding di f, motivando la risposta.
a) pre-condizione Nessuna.
   post-condizione Restituisce la somma delle lunghezze delle stringhe presenti nella lista
(oggetti diversi da stringhe vengono ignorati).
b) pre-condizione La lista contiene stringhe non vuote.
post-condizione Restituisce la lunghezza della lista.
*/
// a) la precondizione(obblighi) va bene postcondizione anche va bene perchè da addirittura PIU' benefici del contratto
// b) precondizione:NON VA BENE, perchè da più obblighi, le stringhe devono essere non vuote, postcondizione assolutamente no

public class Esame162104 {

    public static void main(String[] args) {

        C gamma=new C();
          B beta=gamma;
          A alfa=gamma;

       System.out.println(alfa.f(beta,gamma));
       System.out.println(gamma.f(beta,beta));
      System.out.println(gamma.f(beta,null));
       System.out.println(8&4);
        
        //Esercizio 2
       /* Engine a = new Engine(1200, 69), b = new Engine(1200, 75), c = new Engine(1400, 75);
        System.out.println(a);
        System.out.println(a.equals(b));
        Engine aVol = a.byVolume(), bVol = b.byVolume();
        System.out.println(aVol);
        System.out.println(aVol.equals(bVol));
        System.out.println(a == aVol);
        Engine bPow = b.byPower(), cPow = c.byPower();
        System.out.println(bPow);
        System.out.println(bPow.equals(cPow));*/

    }

}
