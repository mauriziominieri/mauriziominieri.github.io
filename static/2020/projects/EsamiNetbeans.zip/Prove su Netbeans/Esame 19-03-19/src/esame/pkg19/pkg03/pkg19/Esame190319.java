/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package esame.pkg19.pkg03.pkg19;
import java.util.*;

/**
 *
 * @author Maurizio
 */

/*
Realizzare per una biblioteca le classi Library e Book. Un oggetto Book è caratterizzato dal suo
titolo. La classe Library offre le seguenti funzionalità:
• Un costruttore senza argomenti che crea una biblioteca vuota.
• Il metodo addBook aggiunge un libro alla biblioteca. Se il libro era già stato aggiunto,
restituisce false.
• Il metodo loanBook prende un libro come argomento e lo dà in prestito, a patto che sia
disponibile. Se quel libro è già in prestito, restituisce false. Se quel libro non è mai stato
inserito nella biblioteca, lancia un'eccezione.
• Il metodo returnBook prende un libro come argomento e restituisce quel libro alla biblioteca.
Se quel libro non era stato prestato col metodo loanBook, il metodo returnBook lancia
un'eccezione.
• Il metodo printLoans stampa la lista dei libri attualmente in prestito, in ordine temporale
(a partire dal libro in prestito da più tempo).
Inoltre, rispondere alla seguente domanda: nella vostra implementazione, qual è la complessità
dei metodi loanBook e returnBook, rispetto al numero di libri n inseriti nella biblioteca?
L'implementazione deve rispettare il seguente esempio d'uso.

Output:
true
true
true
false
true
true
b
a
*/


class Library{
    
    Map<String,Boolean> M=new HashMap();
    List<String> L=new ArrayList();
    
    public Library(){ 
    }
    
    public boolean addBook(Book b){
       
        if(!M.containsKey(b.titolo)){
            M.put(b.titolo,false);
           // System.out.println("Inserito "+b.titolo);
            return true;
        }
        else{
           // System.out.println("Libro già esistente");
            return false;
        }
    }
    
    public boolean loanBook(Book b){
        
        if(M.get(b.titolo)==null) 
            throw new RuntimeException("Il libro "+b.titolo+" non esiste nella libreria");
        
        if(M.get(b.titolo)==true)   //il libro già è in prestito
           return false;
        else{
            M.put(b.titolo,true);   //metto il valore del libro a true, cioè quel libro diventa in prestito
            L.add(b.titolo);
            return true;
        }
    }
    
    public void returnBook(Book b){
         
        if(M.get(b.titolo)==true){
            M.put(b.titolo,false);
            System.out.println("Libro "+b.titolo+" restituito");
            L.remove(b.titolo);
        }
        else
            throw new RuntimeException("Il libro "+b.titolo+" non è mai stato prestato");
    }
    
    public void printLoans(){
        
       /* for(String s: M.keySet()){
            if(M.get(s)==true)
                System.out.println(s);
        }*/
       
       for(String s: L){
           System.out.println(s);
       }
    }
    
}

class Book{
    
    protected String titolo;
    
    public Book(String t){
        titolo=t;
    }
    
}


public class Esame190319 {
    public static void main(String[] args) {
       
        Library lib = new Library();
        Book a = new Book("a"), b = new Book("b"), c = new Book("c");
        System.out.println( lib .addBook(a));
        System.out.println( lib .addBook(b));
        System.out.println( lib .addBook(c));
        System.out.println( lib .addBook(a));
        System.out.println( lib .loanBook(b));
        System.out.println( lib .loanBook(a));
        lib.printLoans();
    }
    
}
