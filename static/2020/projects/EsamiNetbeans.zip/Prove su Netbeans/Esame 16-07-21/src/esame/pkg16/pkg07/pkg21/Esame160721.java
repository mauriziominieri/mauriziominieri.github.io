package esame.pkg16.pkg07.pkg21;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/*   //Esercizio 1
class A {
    public String f (A x, A y) { return "A1"; }
    private String f(A x, Object y) { return "A2"; }
}
class B extends A {
    public String f(B x, A y) { return "B1:" + y.f(y, y); }
    public String f(A x, A y) { return "B2"; }
}
class C extends B {
   public String f(A x, A y) { return "C1:" + y.f(y, null); }
}
*/

/* ESERCIZIO 2
Implementare la classe Book, che rappresenta un libro diviso in capitoli. Il metodo addChapter
aggiunge un capitolo in coda al libro, caratterizzato da titolo e contenuto. I capitoli sono
automaticamente numerati a partire da 1. Il metodo getChapterName(i) restituisce il titolo del
capitolo i-esimo, mentre il metodo getChapterContent(i) ne restituisce il contenuto.
Gli oggetti Book devono essere clonabili. Inoltre, la classe deve essere dotata di ordinamento
naturale, basato sul numero di capitoli.
L’implementazione deve rispettare il seguente esempio d’uso.
Esempio d’uso:
Book b = new Book();
b.addChapter("Prefazione", "Sono␣passati␣pochi␣anni...");
b.addChapter("Introduzione", "Un␣calcolatore␣digitale...");
b.addChapter("Sistemi␣di␣elaborazione", "Un␣calcolatore...");
Book bb = b.clone();
System.out.println(bb.getChapterContent(1));
System.out.println(bb.getChapterTitle(2));
Output:
Sono passati pochi anni...
Introduzione*/

class Book implements Cloneable,Comparator<Capitolo>{
    
    private List<Capitolo> L;
    private static int k=1;
    
    public Book(){
        L=new ArrayList();
    }
     public void addChapter(String t,String c){
         Capitolo cap=new Capitolo(t,c,k);    //creo un nuovo oggetto capitolo che avrà titolo contenuto e 1, poi incremento k, cosi quando creerò u nuovo capitolo avrò titolo contenuto e 2
         k++;
         L.add(cap);
     }
     
     public String getChapterContent(int i){
         return L.get(i-1).getContenuto();    //Dato che l'array parte dalla posizione 0
     }
     
      public String getChapterTitle(int i){
         return L.get(i-1).getTitle();    //Dato che l'array parte dalla posizione 0
     }
      
      public Book clone(){
          try{
              return(Book) super.clone();
          }
          catch(CloneNotSupportedException e){
              throw new RuntimeException(e);
          }
      }
      
      public int compare(Capitolo c1,Capitolo c2){
          if(c1.getId()>c2.getId()) return 1;
          else if(c1.getId()<c2.getId()) return -1;
          return 0;
      }
      
}

class Capitolo{
    private String titolo,contenuto;
    private int id;
    
    public Capitolo(String t,String c,int k){
        titolo=t;
        contenuto=c;
        id=k;
    }
    
    public String getContenuto(){
        return contenuto;
    }
    
    public String getTitle(){
        return titolo;
    }
    
    public int getId(){
        return id;
    }
}

/* ESERCZIO 4
La seguente classe A fa riferimento ad una classe B. Implementare la classe B in modo che venga
compilata correttamente e permetta la compilazione della classe A.
public class A extends B<Object> {
    private B<?> b;
    private String msg;
    public A() {
        b = new B<Object>(null);
        msg = B.<A>buildMessage(this);
    }
    public Set<? super Number> f(Set<Integer> set1, Set<String> set2) {
        for (Integer n: b)
            if (b.check(set1, n))
                return b.process(set1, set2, n);

        return b.process(set2, set1, null);
    }
}
*/
/*
class B<T>{                               //Il trucco è mettere <?> nei tipi (String, Integer...) e mettere T dove c'è null, this ecc
     ArrayList<Integer> array;
     
    public B(T t){
      //  Object o=null;
         array=new ArrayList();
        // return o;
    }
    
    public static <T> String buildMessage(T t){ 
        return "ciao";
    }
    
    public boolean check(Set<?> set,Object n){
        return true;
    }
    
    public <T> Set<T> process(Set<?> s1,Set<?> b,T n){
        Set<T> S=new HashSet();
        return S;
    }
}

class A extends B<Object> {       //è una sottoclasse, come tale deve avere lo stesso costruttore
    private B<?> b;
    private String msg;
    
    public A() {         
         b = new B(null);
         msg = B.<A>buildMessage(this);
    }
    
    public Set<? super Number> f(Set<Integer> set1, Set<String> set2) {
        for (Integer n: b)
            if (b.check(set1, n))
                return b.process(set1, set2, n);
        
        return b.process(set2, set1, null);
    }
}
*/

/* //ESERCIZIO 3
Implementare il metodo statico findString che accetta una stringa x e un array di stringhe a
e restituisce “vero” se x è una delle stringhe di a, e “falso” altrimenti. Per ottenere questo
risultato, il metodo usa due tecniche in parallelo: un primo thread confronta x con ciascuna
stringa dell’array; un altro thread confronta solo la lunghezza di x con quella di ciascuna stringa
dell’array. Il metodo deve restituire il controllo al chiamante appena è in grado di fornire una
risposta certa.
Ad esempio, se il secondo thread scopre che nessuna stringa dell’array ha la stessa lunghezza di
x, il metodo deve subito restituire “falso” e terminare il primo thread (se ancora in esecuzione).
*/



public class Esame160721 {
    
    private static ArrayList<String> A=new ArrayList();
    private static String parola;
    private static boolean flag1=false;
    private static boolean flag2=false;
    private static  Thread t1;
    private static  Thread t2;
    
    public static boolean findString(String x,ArrayList<String> a){
        A=a;
        parola=x;
        t1=new MyThread1();
        t2=new MyThread2();
        t1.start();
        t2.start();
        
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
           }
        
       if(flag1==true){
           return true;
       }
       
       return false;
    }
    
    static class MyThread1 extends Thread{
    
        public void run(){
            System.out.println(Thread.currentThread().getName()+"INIZIO");
            while(!this.isInterrupted()){
             
             for(String s: A){
                  if(t1.isInterrupted())
                        return;
                 System.out.println(Thread.currentThread().getName());
                 if(s.compareTo(parola)==0){
                    System.out.println("parola trovata");
                    flag1=true;
                    System.out.println("trovato, interrompo t2");
                    t1.interrupt();
                    t2.interrupt();
                 }     
             }
            } 
        }

    }
    
    static class MyThread2 extends Thread{
        boolean ispresent=false;
        public void run(){
              System.out.println(Thread.currentThread().getName()+"INIZIO");

                for(String s: A){
                    if(t2.isInterrupted())
                        return;
                    
                 System.out.println(Thread.currentThread().getName());
                 if(s.length()==parola.length()){
                     System.out.println("stessa lunghezza");
                     ispresent=true;
                 } 
                }  
             
            if(ispresent==false){
                System.out.println("niente, interrompo t1");
                t2.interrupt();
                t1.interrupt();
            }
       
            
        }

    }
    
    public static void main(String[] args) {
       /* C gamma = new C();
        B beta = gamma;
        A alfa = new A();
        System.out.println(beta. f (gamma, alfa));
        System.out.println(gamma.f(alfa, alfa ));
        System.out.println((12 & 3) > 0);      //1100 AND 0011 = 0000 = 0>0? FALSO
*/
        
        //ESERCIZIO 2
      /*  Book b = new Book();
        b.addChapter("Prefazione", "Sono passati pochi anni...");
        b.addChapter("Introduzione", "Un calcolatore digitale...");
        b.addChapter("Sistemi di elaborazione", "Un calcolatore...");
        Book bb = b.clone();
        System.out.println(bb.getChapterContent(1));
        System.out.println(bb.getChapterTitle(2));*/
        
        ArrayList<String> a=new ArrayList();
        a.add("mela");  a.add("pera"); a.add("fragola"); a.add("banana"); a.add("coccoooo");
        System.out.println(findString("peraa",a));

    }
    
}
