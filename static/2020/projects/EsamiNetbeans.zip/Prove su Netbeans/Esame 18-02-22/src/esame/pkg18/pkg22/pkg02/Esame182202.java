
package esame.pkg18.pkg22.pkg02;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;


/*
 Realizzare le classi Book e Library, che rappresentano rispettivamente un libro e una collezione di libri. Il
metodo addBook di Library aggiunge un libro alla collezione, con un dato titolo e un dato autore. A ciascun
libro è possibile attribuire uno o più argomenti tramite il suo metodo addTag. Il metodo getBooksByTag
di Library restituisce in tempo costante l’insieme dei libri di un argomento dato.
L’implementazione deve rispettare il seguente esempio d’uso:

Esempio d’uso:
    Library casa = new Library(), ufficio = new Library();
    Library.Book b1 = casa.addBook("Esercizi di stile", "Queneau");
    b1.addTag("letteratura");
    b1.addTag("umorismo");
    Library.Book b2 = casa.addBook("Me parlare bene un giorno", "Sedaris");
    b2.addTag("umorismo");
    Library.Book b3 = ufficio.addBook("Literate programming", "Knuth");
    b3.addTag("programmazione");
    Set<Library.Book> humorCasa = casa.getBooksByTag("umorismo");
    System.out.println(humorCasa);
    Set<Library.Book> humorUfficio = ufficio.getBooksByTag("umorismo");
    System.out.println(humorUfficio);

Output:
    [Esercizi di stile, by Queneau, Me parlare bene un giorno, by Sedaris]
    null

 */





 class Library {

 	HashSet<Book> set;

 	public Library() {
 		set = new HashSet();
 	}

 	public Book addBook(String t, String a) {
 		Book b = new Book(t,a);
 		set.add(b);
 		return b;
 	}

 	public Set<Book> getBooksByTag(String a){

 		Set<Book> returnSet = new HashSet();

 		 for (Book b : set) {
 			if (b.argomenti.contains(a))
 				returnSet.add(b);
 		}

 		return returnSet;
 	}




 	class Book {

 		private String autore;
 		private String titolo;
 		private HashSet<String> argomenti;

 		public Book(String t, String a) {
 			this.titolo = t;
 			this.autore = a;
 			argomenti = new HashSet();
 		}

 		public void addTag(String a) {
 			this.argomenti.add(a);
 		}

 		public String toString() {
 			return titolo+", by "+autore;
 		}

 	}

 }


/*
Data una classe Pair<S,T>, il metodo statico cartesianProduct accetta due insiemi e restituisce
il loro prodotto cartesiano.
Valutare ciascuna delle seguenti intestazioni in base ai criteri di funzionalità, completezza, correttezza,
fornitura di ulteriori garanzie, semplicità e specificità del tipo di ritorno. Infine, scegliere
l’intestazione migliore oppure proporne un’altra.
a) <S,T> Set<Pair<S,T>> cartesianProduct(Set<S> s, Set<T> t)
b) <S,T> Set<Pair<S,T>> cartesianProduct(Set<?> s, Set<?> t)
c) Set<Pair<?,?>> cartesianProduct(Set<Object> s, Set<Object> t)
d) <S,T> Set<?> cartesianProduct(Set<S> s, Set<T> t)
e) <S> Set<Pair<S,S>> cartesianProduct(Set<S> s, Set<S> t)
f) <S,T extends S> Set<Pair<S,T>> cartesianProduct(Set<S> s, Set<T> t)
*/

class Pair<S,T>{
    S a1;
    T a2;
    public Pair(S a, T b){
        a1=a;
        a2=b;
    }

    public static <S,T extends S> Set<Pair<S,T>> cartesianProduct(Set<S> s,Set<T> t){
        Set<Pair<S,T>> S=new HashSet();

        for(Object item : s){
            for(Object item2: t){
              Pair p=new Pair(item,item2);
              S.add(p);
              System.out.println("aggiunto ("+item+" e "+item2+")");

            }
        }

        return S;
    }
}
//1) Funzionale. Completa. Corretta. Non ulteriori garanzie. Non semplice. Specifica.
//2) Funzionale. è possibile prendere gli elementi dai due set ma solo in Object. Completa. Corretta. Ulteriori garanzie, non
       //sarà possibile modificare i set. Non semplice. Specifica.
//3) Funzionale. Non completa, posso avere solo due st Object. Corretta. Non ult garanzie. Semplice. NON specifica.
//4) NON funzionale. Non potrò usare la funzione add del Set formato dal prodotto cartesiano dei due.
//5) Funzionale. Non completa, accetta solo lo stesso tipo. Corretta. Non ulteriori gar. Semplice. Specifica.
//6) Funzionale. Non completa, accetta solo tipi correlati. Corretta. Non ult. gar. Non semplice. Specifica.
//La migliore è la 2)... sempre se è vero che valgono le ulteriori garanzie.





/*
Implementare un programma Java che avvia contemporaneamente due thread, che condividono
una lista di interi:
a) il primo thread aggiunge un numero casuale alla lista ogni decimo di secondo, terminando
quando il numero estratto è multiplo di 100;
b) il secondo thread calcola e stampa a video la somma di tutti i numeri nella lista, una volta
al secondo, terminando non appena termina il primo thread.
È necessario evitare race condition e attese attive.
Suggerimento. Per ottenere un numero intero casuale, si consiglia di utilizzare le seguenti
funzionalità della classe java.util.Random:
public Random()
public int nextInt()
*/



public class Esame182202 {

    //ESERCIZIO 3
    /* private static List<Integer> L=new LinkedList();
     private static boolean FLAG=false;
     private static int sum=0;

     static class MyThread1 extends Thread{
     public void run(){

           System.out.println("SONO"+Thread.currentThread().getName()+", INIZIO");

            while(!this.isInterrupted()){      //il thread continua fino a che non viene interrotto
               try{Thread.sleep(100);}     //decimo di secondo = 100
               catch(InterruptedException e){return;}
               Random rand = new Random();
               int num=rand.nextInt(6); //se metti 100 ti esce un numero random da 0 a 99
               L.add(num);
               System.out.println("L : "+L);
               if(num%10==0){
                   this.interrupt();          //interrompo il thread corrente
                   FLAG=true;}
            }
     }
}

     static class MyThread2 extends Thread{
    public void run(){
          System.out.println("SONO"+Thread.currentThread().getName()+", INIZIO");
        while(!this.isInterrupted()){      //il thread continua fino a che non viene interrotto
               if(L!=null){
                   try{Thread.sleep(1000);}    //ogni secondo
               catch(InterruptedException e){return;}
                   for(int i=0;i<L.size();i++){
                       sum=sum+L.get(i);
                   }
                   System.out.println("SOMMA : "+sum);
                   sum=0;

                    if(FLAG==true)
                      this.interrupt();
               }
            }
    }
}*/
     //Se mettessi un blocco sincronizzato su L allora il primo thread farebbe ciò che deve fare,
//quando finisce allora parte il secondo thread


    public static void main(String[] args) {
        //Esercizio 1
        Library casa = new Library(), ufficio = new Library();
        Library.Book b1 = casa.addBook("Esercizi di stile", "Queneau");
        b1.addTag("letteratura");
        b1.addTag("umorismo");
        Library.Book b2 = casa.addBook("Me parlare bene un giorno", "Sedaris");
        b2.addTag("umorismo");
        Library.Book b3 = ufficio.addBook("Literate programming", "Knuth");
        b3.addTag("programmazione");
        Set<Library.Book> humorCasa = casa.getBooksByTag("umorismo");
        System.out.println(humorCasa);
        Set<Library.Book> humorUfficio = ufficio.getBooksByTag("umorismo");
        System.out.println(humorUfficio);

        //Esercizio 2
       /*
        Set<Object> s=new HashSet();
        Set<Integer> t=new HashSet();
        s.add("a");
        s.add("b");
        t.add(1);
        t.add(2);
        System.out.println(Pair.cartesianProduct(s,t));
        */

        //Esercizio 3
       /* MyThread1 t1=new MyThread1();
        MyThread2 t2=new MyThread2();
        t1.start();
        t2.start();*/

    }

}
