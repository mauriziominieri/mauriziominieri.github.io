/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package esame.pkg17.pkg21.pkg06;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

class A {
  public String f(Object x, A y,A z) { return "A1"; }
  private String f(A x, B y, B z) { return "A2"; }
}
class B extends A {
    public String f(A x, B y, B z) { return "B1"+" "+f(null,new B(),z);}
    private String f(B x,B y,C z) { return "B2"; }
    
}
class C extends B {
   public String f(A x, B y, B z) { return "C1"+" "+f(this,this,z);}
   public String f(B x, B y, B z) { return "C2"; }
  
}

NON HO CAPITO
/* ESERCIZIO 2     
Realizzare la classe thread-safe Market, che permette a diversi thread di contrattare il prezzo
di un servizio. Il metodo sell offre il servizio per un certo prezzo e blocca il chiamante finché
non arriverà una richiesta con un importo adeguato. Simmetricamente, il metodo buy richiede il
servizio per un certo prezzo e blocca il chiamante finché non arriverà un’offerta adeguata.
Per semplicità, si può supporre che tutti gli importi passati a sell e buy siano diversi.
L’implementazione deve rispettare il seguente esempio d’uso, in cui diversi thread condividono
un oggetto Market m:
Thread 1: m.buy(10.0); resta bloccato
Thread 2: m.sell (15.50); resta bloccato
Thread 3: m.sell (12.0) ; resta bloccato
Thread 4: m.buy(13.0); sblocca T3 e ritorna
Thread 5: m.buy(11.0); resta bloccato
Thread 6: m.sell (9.50) ; sblocca T1 oppure T5 e ritorna
*/
/*
class MyThread extends Thread{
    private static int id=0;
    private int buy;
    private int sell;
    public MyThread(double d){
        id=id+1;
    }
   
    public void run(){ 
        System.out.println("Thread "+id+" parte");
       
    }
    
}*/

class Market{
    
	private class Pair<S,T>{
		private S first;
		private T second;
		
		public Pair(S f, T s){
			first = f;
			second = s;
		}
	
	}
	
	private List<Pair<Thread,Float>> buyers;
	private List<Pair<Thread,Float>> sellers;

	public Market(){
		buyers = new ArrayList<>();
		sellers = new ArrayList<>();
	}
	
	public synchronized void sell(Float f){
            System.out.println("SONO : "+Thread.currentThread().getName()+" nel sell");
		Pair<Thread,Float> p = new Pair<>(Thread.currentThread(),f);
		Iterator<Pair<Thread,Float>> i = buyers.iterator();
		while(i.hasNext()){
			Pair<Thread,Float> x = i.next();
			if(p.second <= x.second){
				i.remove();
				x.first.interrupt();
				return;
			}
		}
		sellers.add(p);
		try {this.wait();}
		catch(InterruptedException e) {return;}
	}
	
	public synchronized void buy(Float f){
             System.out.println("SONO : "+Thread.currentThread().getName()+" nel buy");
		Pair<Thread,Float> p = new Pair<>(Thread.currentThread(),f);
		Iterator<Pair<Thread,Float>> i = sellers.iterator();
		while(i.hasNext()){
			Pair<Thread,Float> x = i.next();
			if(p.second >= x.second){
				i.remove();
				x.first.interrupt();
				return;
			}
		}
		buyers.add(p);
		try{this.wait();}
		catch(InterruptedException e) {return;}
	}
	
	
	
}




/*
Il metodo statico findNext accetta un insieme, un comparatore e un oggetto x, e restituisce il più
piccolo oggetto dell’insieme che è maggiore di x (secondo il comparatore).
Valutare ciascuna delle seguenti intestazioni in base ai criteri di funzionalità, completezza, correttezza,
fornitura di ulteriori garanzie, semplicità e specificità del tipo di ritorno. Infine, scegliere
l’intestazione migliore oppure proporne un’altra.
a) <T> T findNext(Set<? extends T> set, Comparator<?> comp, T x)
b) <S,T extends S> T findNext(Set<T> set, Comparator<S> comp, T x)
c) <S,T extends S> S findNext(Set<S> set, Comparator<T> comp, S x)
d) <T> T findNext(Set<T> set, Comparator<? super T> comp, T x)
e) <T> T findNext(Set<T> set, Comparator<T> comp, Object x)
*/

class Prova{
    
    public static <T> T findNext(Set<T> set, Comparator<T> comp, Object x){
        T min=null;
        Iterator it=set.iterator();
        while(it.hasNext()){
            if(comp.compare((T)it.next(),(T)x)==-1)
                   System.out.println();   
        }
        
        return min;
    }
}
//a) NON FUNZIONALE, non potrò usare il compare.
//b) FUNZIONALE. NON COMPLETA, solo tipi correlati. CORRETTA. NON ULT. G. NON SEMPLICE. SPECIFICA.
//c) FUNZIONALE. NON COMPLETA. NON CORRETTA, o questa o la b deve essere non corretta, sono invertiti i tipi apposta. NON. NON. SPECIFICA.
//d) FUNZIONALE. NON COMPLETA. CORRETTA. NON ULT. G. SEMPLICE. SPECIFICA.
//e) FUNZIONALE. COMPLETA. NON CORRETTA. NON U.G. SEMPLICE. SPECIFICA.


public class Esame172106 {
    public static void main(String[] args) {
       //ESERCIZIO 1
       /* C gamma=new C();
       B beta=gamma;
       A alfa=gamma;
       
     //  System.out.println(alfa.f(alfa,beta,gamma));
       //   System.out.println(gamma.f(beta,beta,beta));
        //System.out.println(gamma.f(alfa,beta,null));
      //  System.out.println(((Object)beta).equals(alfa));
*/
       
       
      /*  Market m=new Market();
        m.buy((float)10.0);
        m.sell ((float)15.50); 
        m.sell ((float)12.0) ; 
        m.buy((float)13.0); 
        m.buy((float)11.0); 
        m.sell ((float)9.50) ; */
        
        Market m = new Market();
		Thread t1 = new Thread(){
			public void run(){
				m.buy(new Float(10.0));
			}
		};
		Thread t2 = new Thread(){
			public void run(){
				m.sell(new Float(9.50));
			}
		};
                Thread t3 = new Thread(){
			public void run(){
				m.sell(new Float(12.0));
			}
		};
                Thread t4 = new Thread(){
			public void run(){
				m.buy(new Float(13.0));
			}
		};
                 Thread t5 = new Thread(){
			public void run(){
				m.buy(new Float(11.0));
			}
		};
                  Thread t6 = new Thread(){
			public void run(){
				m.sell(new Float(9.50));
			}
		};
		t1.start();
		t2.start();
                t3.start();
                t4.start();
                t5.start();
                t6.start();
       
    }
}
