package esame.pkg15.pkg02.pkg05;
import java.util.*;

/* //Esercizio 2
Realizzare la classe Box, che rappresenta una scatola, caratterizzata dalle sue tre dimensioni:
altezza, larghezza e profondità. Due scatole sono considerate uguali (da equals) se hanno le
stesse dimensioni. Le scatole sono dotate di ordinamento naturale basato sul loro volume. Infine,
il metodo fitsIn, invocato su una scatola x, accetta un’altra scatola y e restituisce true se e solo
se y è sufficientemente grande da contenere x.
Esempio d’uso:
Box grande = new Box(20, 30, 40), grande2 = new Box(30, 20, 40), piccolo = new Box(10, 10, 50);
System.out.println(grande.equals(grande2));
System.out.println(grande.compareTo(piccolo));
System.out.println(piccolo . fitsIn (grande));
Output:
false
1
false
*/

class Box implements Comparable<Box>{
  
       private int altezza,larghezza,profondita;
       private int volume;
    
    public Box(int a,int l,int p){
        altezza=a;
        larghezza=l;
        profondita=p;
        volume=a*l*p;
    }
    
    public boolean equals(Box b){
        if(altezza==b.altezza && larghezza==b.larghezza&&profondita==b.profondita)
            return true;
        return false;
    }
    
    public int compareTo(Box o){
        if(volume>o.volume) return 1;
        else if(volume<o.volume) return -1;
        else return 0;
    }
    
    public boolean fitsIn(Box b){
        if(altezza>=b.altezza && larghezza>=b.larghezza && profondita>=b.profondita)
            return true;
        return false;
    }
    
}

/*
8. (reverseList, 2015-2-5)
Il metodo reverseList accetta una lista e restituisce una nuova lista, che contiene gli stessi elementi
della prima, ma in ordine inverso.
Valutare ciascuna delle seguenti intestazioni in base ai criteri di funzionalità, completezza, correttezza,
fornitura di ulteriori garanzie, semplicità e specificità del tipo di ritorno. Infine, scegliere
l’intestazione migliore oppure proporne un’altra.
a) List<?> reverseList(List<?> l)
b) <T> List<? extends T> reverseList(List<? super T> l)
c) <T extends List<?>> T reverseList(T l)
d) <T> List<T> reverseList(List<T> l)
e) List<Object> reverseList(List<Object> l)
*/
//a) Non funzionale, non posso inserire gli elementi di l nella lista che dovrò restituire. Object cant be converted in <?>
//b) Non funzionale. Object cant be converted in <?>
//c) FUNZIONALE, con un cast. COMPLETA. CORRETTA. NON U.G. SEMPLICE. SPECIFICA
//d) FUNZIONALE. COMPLETA. CORRETTA. NON U.G. SEMPLICE. SPECIFICA
//e) FUNZIONALE. COMPLETA. CORRETTA. NON U.G. SEMPLICE. NON SPECIFICA.

public class Esame150205 {
    
    public List<Object> reverseList(List<Object> l){
        
        List<Object> L=new ArrayList();
        l.add("ciao");
        for(int i=l.size();i>=0;i--)
            L.add(l.get(i));
        
        return L;
    }
    
    public static void main(String[] args) {
        Box grande = new Box(20, 30, 40), grande2 = new Box(30, 20, 40), piccolo = new Box(10, 10, 50);
        System.out.println(grande.equals(grande2));
        System.out.println(grande.compareTo(piccolo));
        System.out.println(piccolo.fitsIn(grande));
    }
    
}
