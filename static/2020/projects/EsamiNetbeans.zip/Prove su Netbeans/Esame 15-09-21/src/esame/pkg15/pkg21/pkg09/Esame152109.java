package esame.pkg15.pkg21.pkg09;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
/*
Nell’ambito di un programma di gestione del personale, la classe Progression calcola il salario dei
dipendenti, in base alla loro anzianità in servizio. Il salario mensile parte da un livello base ed ogni
anno solare aumenta di un certo incremento. Il costruttore accetta il salario base e l’incremento
annuale. Il metodo addEmployee aggiunge un impiegato a questa progressione, specificando il
nome e l’anno di assunzione. Il metodo getSalary restituisce il salario mensile di un impiegato
in un dato anno. Infine, il metodo addBonus attribuisce ad un impiegato un bonus extra in un
dato anno. Cioè, addBonus(“Pippo”, 2010, 50) significa che Pippo percepirà 50 euro in più in ogni
mese del 2010.
Caso d’uso:
Progression a = new Progression(1000, 150);
a.addEmployee("Jesse", 2008);
a.addEmployee("Gale", 2009);
a.addBonus("Gale", 2010, 300);
System.out.println(a.getSalary("Jesse", 2009));
System.out.println(a.getSalary("Gale", 2010));
System.out.println(a.getSalary("Gale", 2011));
Output:
1150
1450
1300
*/


class Progression{
    private int salario,incremento;
    private Map<String,Employee> M;
    
    public Progression(int s,int i){
        salario=s;
        incremento=i;
        M=new HashMap();
    }
    
    public void addEmployee(String nome,int anno){
       Employee e=new Employee(anno);
        e.Map_emp.put(anno,0);
       // System.out.println(nome+" "+e.Map_emp);
        M.put(nome,e);
    }
    
    public int getSalary(String nome,int anno){
          Employee e=M.get(nome);
          // System.out.println(nome+" quii "+e.Map_emp);
           int n=anno-e.anno_assunzione;        //n sarà la differenza tra l'anno chiamato dal main e l'anno di assunzione.
           if(e.Map_emp.get(anno)!=null)
               return salario+(incremento*n)+e.Map_emp.get(anno);
           
           return salario+(incremento*n);
        
    }
    
    public void addBonus(String nome,int anno,int bonus){
         Employee e=M.get(nome);
         e.Map_emp.put(anno,bonus);
        // System.out.println(nome+" "+e.Map_emp);
    }
}

class Employee{
    protected Map<Integer,Integer> Map_emp;
    protected int anno_assunzione;
    
    public Employee(int a){
        Map_emp=new HashMap();
        anno_assunzione=a;
    }
}


/*
La classe StringQuiz consente a diversi thread di tentare di indovinare una stringa segreta, entro
un tempo prestabilito. Il costruttore accetta la stringa segreta e un timeout in millisecondi. Il
metodo guess accetta una stringa e restituisce vero se è uguale a quella segreta e falso altrimenti.
Ciascun thread ha 3 possibilità di indovinare, oltre le quali il metodo guess lancia un’eccezione.
Scaduto il timeout, il metodo guess lancia un’eccezione ogni volta che viene invocato. La classe
deve risultare thread-safe.

*/

class StringQuiz extends Thread{
    private String segreto;
    private boolean stop;
    private long timeout;
    
    public StringQuiz(String s,long t){
        segreto=s;
        timeout=t;
    }
    
    public synchronized boolean guess(String s){           //metodo thread safe
        if(stop==true)
            throw new RuntimeException("tempo scaduto");
          
        if(Thread.currentThread().isInterrupted())
            throw new RuntimeException("3 tentativi falliti");
      
        System.out.println("ciao, sono : "+Thread.currentThread().getName()+" e sto provando con : "+s);
        if(s.compareTo(segreto)==0) return true;
        
        return false;

    }
    
    public void run(){
        try {
            Thread.sleep(timeout);
        } catch (InterruptedException ex) {  
        }
        stop=true;
        System.out.println("ciao, sono : "+Thread.currentThread().getName()+" e ora dopo "+timeout+" secondi ho messo stop a true");
    }
}

public class Esame152109 {
    public static void main(String[] args) {
       /*Progression a = new Progression(1000, 150);
        a.addEmployee("Jesse", 2008);
        a.addEmployee("Gale", 2009);
        a.addBonus("Gale", 2010, 300);
        System.out.println(a.getSalary("Jesse", 2009));
        System.out.println(a.getSalary("Gale", 2010));
        System.out.println(a.getSalary("Gale", 2011));*/
       
       
       
       StringQuiz sq=new StringQuiz("ciao",1000);;
       
       Thread t1=new Thread(){
           public void run(){
               sq.start();
           }
       };
        t1.start();
       
       
      /* Thread t1=new Thread(){
           private int fails=0;
           public void run(){
               sq.guess("wau");
           }
       };*/
       
      Thread t2=new Thread(){
        
           public void run(){
               sq.guess("cia");
               sq.guess("ciao2");
               sq.guess("cia");
              // Thread.currentThread().interrupt();
               sq.guess("ciao3");
           }
       };
      Thread t3=new Thread(){
          
           public void run(){
               sq.guess("ciao2");
               sq.guess("noooo");
              if(sq.guess("cia3")){
                   System.out.println("t3 vince");
                   return;
               }
              if(sq.guess("ciao")){
                   System.out.println("t3 vince");
                   return;
               }
               
           }
       };
       
      
       //t1.start();
       t2.start();
       t3.start();
       
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(Esame152109.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
