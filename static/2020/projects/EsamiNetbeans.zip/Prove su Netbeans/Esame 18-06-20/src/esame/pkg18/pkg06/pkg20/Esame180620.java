package esame.pkg18.pkg06.pkg20;
import java.util.*;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.logging.Level;
import java.util.logging.Logger;


class A {
public String f(Object x, A y, B z) { return "A1"; }
public String f(A x, C y, C z) { return "A2"; }
}
class B extends A {
public String f (Object x, A y, A z) { return "B1 + " + f(null, new B(), y); }
private String f(A x, B y, B z) { return "B2"; }
}
class C extends B {
public String f(A x, A y, B z) { return "C1"; }
public String f(A x, C y, C z) { return "C2"; }
}


/*  //Esercizio 3
Realizzare la classe PeriodicExecutor, che consente di eseguire una serie di task periodicamente, con un
limite al numero di task che possono essere eseguiti contemporaneamente. Il costruttore accetta questo
limite. Il metodo addTask accetta un Runnable e un long x, e fa in modo che il Runnable venga eseguito
ripetutamente, con un ritardo di x millisecondi tra la fine di un’esecuzione e l’inizio della successiva.
Se però (ri)avviare un Runnable porta a superare il limite, l’avvio viene rimandato finché ci sarà la
possibilità di eseguirlo senza violare il limite.
Il limite si riferisce al numero di task che stanno eseguendo il loro Runnable, non al periodo durante il
quale stanno aspettando il ritardo x.
L’implementazione deve rispettare il seguente esempio d’uso.
PeriodicExecutor exec = new PeriodicExecutor(2);
Runnable r1 = ..., r2 = ..., r3 = ...;
exec.addTask(r1, 1000);
exec.addTask(r2, 500);
exec.addTask(r3, 700);
*/




class MyRunnable implements Runnable{
    private int id;
    
    public MyRunnable(int n){
        id=n;
    }
    
    public void run(){
        System.out.println("task "+id+" eseguito"); 
    }
}


class PeriodicExecutor extends Thread{   //dubbi
    
    private ArrayBlockingQueue<Runnable> Q;
    private int conta=0;
    private int limite;
    
    public PeriodicExecutor(int lim){
        Q=new ArrayBlockingQueue(lim);
        limite=lim;
    }
    
    public void addTask(Runnable r,long x){
        Thread t=new Thread(r){           
            public void run(){
                while(true){
                    while(conta<limite){
                         try{Q.put(r);}catch(InterruptedException e){}   //metto il thread nella coda
                         conta++;                                         //e conta diventa 1, poi ne metto un altro e conta diventa = limite quindi esco dal while
                    }
                    super.run();                                            //starto il runnable
                    try{Thread.sleep(x);}  catch(InterruptedException e){}  //aspetta quanti secondo deve aspettare

                    try{Q.take();}catch(InterruptedException e){}         // e lo levo dalla coda
                    System.out.println("Sono "+ Thread.currentThread().getName()+", ho aspettato "+x+"secondi e rifaccio la run");
                    conta=0;                     //conta torna a 0
                }   
            }
        };
        t.start();
    }
}


/*
Il metodo statico makeMap accetta una lista di chiavi e una lista di valori (di pari lunghezza), e restituisce
una mappa ottenuta accoppiando ciascun elemento della prima lista al corrispondente elemento della
seconda lista.
Valutare ciascuna delle seguenti intestazioni in base ai criteri di funzionalità, completezza, correttezza,
fornitura di ulteriori garanzie, semplicità e specificità del tipo di ritorno. Infine, scegliere l’intestazione
migliore oppure proporne un’altra.
(a) <K,V> Map<? extends K,? extends V> makeMap(List<K> keys, List<V> vals)
(b) <K,V> Map<? extends K,?> makeMap(List<K> keys, List<?> vals)
(c) <K,V> Map<K,V> makeMap(List<K> keys, List<?> vals)
(d) <T> Map<T,T> makeMap(List<? extends T> keys, List<? extends T> vals)
(e) <K> Map<K,?> makeMap(List<K> keys, List<Object> vals)
(f) <K, V extends K> Map<K,V> makeMap(List<K> keys, List<V> vals)
*/

/*
class A1{
    
}
class B1 extends A1{
    
}

class Prova{
  
    public static <K,V> Map<? extends K,?> makeMap(List<K> keys, List<?> vals)
    {
       Map<? extends K,?> M=new HashMap<>();;
       for(int i=0;i<3;i++){
            M.put((K)keys.get(i),vals.get(i));
        }
       return M;
    }
}*/

//a)NON funzionale perchè non sarà possibile usare il metodo put della mappa. K non può essere convertito in <?>
//b)NON funzionale. perchè non sarà possibile usare il metodo put della mappa. K non può essere convertito in <?>
//c)FUNZIONALE(col cast). COMPLETA. CORRETTA. NON ULT GAR. NON SEMPLICE. SPECIFICA.
//d)FUNZIONALE. NON completa, perchè non accetta tipi diversi. CORRETTA. ULT. GAR. in quanto le liste 
  //non potranno essere modificate, però la traccia non dice nulla al riguardo quindi forse non sono ulteriori garanzie.
  //SEMPLICE, ha solo un parametro di tipo (T). SPECIFICA.
//e)NON funzionale. Object non può essere convertito in <?>
//f)Funzionale. Non completa, accetta solo due tipi uno sottotipo dell'altro. Corretta. Non ulteriori garanzie. Non semplice. Specifica.


public class Esame180620 {
    public static void main(String[] args) {
       //Esercizio 1 
       /* C gamma = new C();
        B beta = gamma;
        A alfa = gamma;
        System.out.println( alfa . f (beta, gamma, gamma));
        System.out.println(beta. f (beta, beta, beta));
        System.out.println(gamma.f(alfa, null, beta));*/
       
        
        PeriodicExecutor exec = new PeriodicExecutor(2);
        Runnable r1 = new MyRunnable(1), r2 = new MyRunnable(2), r3 = new MyRunnable(3);
        exec.addTask(r1, 5000);
        exec.addTask(r2, 3000);
        exec.addTask(r3,6000);
       
       /*ArrayList A=new ArrayList();
       ArrayList B=new ArrayList();
       A.add("k1");
        A.add("k2");
         A.add("k3");
         B.add("1");
         B.add("2");
         B.add("3");
         Map<? extends String,?> M=Prova.makeMap(A, B);
         System.out.println("M : "+M);*/
         
       
        
    }
}
