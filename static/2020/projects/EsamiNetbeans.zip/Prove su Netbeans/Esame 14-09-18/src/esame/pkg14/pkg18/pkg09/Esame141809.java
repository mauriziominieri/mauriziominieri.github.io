/*
 Un oggetto di tipo Contest consente ai client di votare per uno degli oggetti che partecipano a
un “concorso”. Implementare la classe parametrica Contest con i seguenti metodi: il metodo add
consente di aggiungere un oggetto al concorso; il metodo vote permette di votare per un oggetto;
se l’oggetto passato a vote non partecipa al concorso (cioè non è stato aggiunto con add), viene
lanciata un’eccezione; il metodo winner restituisce uno degli oggetti che fino a quel momento ha
ottenuto più voti.
Tutti i metodi devono funzionare in tempo costante.

Esempio d’uso: 
Contest<String> c = new Contest<String>(); 
String r = "Red", b = "Blue", g = "Green"; 
c.add(r); c.vote(r); c.add(b); c.add(g); c.vote(r); c.vote(b); System.out.println(c.winner());

Output:
Red

 */
package esame.pkg14.pkg18.pkg09;
import java.util.*;


/*
class Contest<String>{
    
    private Map<String,Integer> Map;
    private String MAX;
    private int imax=0;
    
    
    public Contest(){
        Map=new HashMap<>();
    }
    
    public void add(String ogg){
        Map.put(ogg,0);  
    }
    
    public void vote(String ogg){
        
        int i=Map.get(ogg);
   
        if(Map.containsKey(ogg)){
           Map.put(ogg,i+1); 
          
           if(i>imax)
           {
              imax=i+1;
              MAX=ogg;
           }
           else if(i+1==imax)
              MAX=null;
        }
        else
            throw new RuntimeException("Oggetto non esistente");
    }
    
    public String winner(){
        System.out.print("IL vincitore è : ");
        if(MAX==null)
            return (String)"Non esistente";
        return MAX;
        
    }
    
    void Stampa(){
        System.out.println(Map);
    }
}
*/


class Contest<T>{
    private Map<T,Integer> Map;
    private int max;
    private T omax;
    
    public Contest(){
        Map=new HashMap();
    }
    
    public void add(T s){
        Map.put(s,0);
    }
    
    public void vote(T s){
        if(Map.get(s)==null)
            throw new RuntimeException("Oggetto non esistente");
        else{
            int m=Map.get(s);
            m++;
            Map.put(s,m);
            if(m>max){
                max=m; omax=s;
            }
        }
    }
    
    public T winner(){
        return omax;
    }
    
     void Stampa(){
        System.out.println(Map);
    }
}


public class Esame141809 {
    public static void main(String[] args) {
        Contest<String> c = new Contest<String>();
        String r = "Red", b = "Blue", g = "Green";
      
        c.add(r);
        c.vote(r);
        c.add(b);
        c.add(g);
        c.vote(r);
        c.vote(b);
       
        c.Stampa();
        
        System.out.println(c.winner()); 
        c.vote(b);
        c.Stampa();
        System.out.println(c.winner());
          c.vote(r);
          c.Stampa();
           System.out.println(c.winner());
            c.vote(g);
            c.vote(g);
              c.vote(g);
               c.vote(g);
             c.Stampa();
           System.out.println(c.winner());
          
          
          
          
         
    }
    
}
