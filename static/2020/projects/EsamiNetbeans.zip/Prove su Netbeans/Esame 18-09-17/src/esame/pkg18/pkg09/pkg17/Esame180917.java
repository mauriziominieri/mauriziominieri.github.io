package esame.pkg18.pkg09.pkg17;
import java.util.*;
//Esercizio 1
class A{
     public String f(Object x,A y){return "A1";}
     private String f(A x,Object y){return "A2";}
     protected String f(A x,B y){return "A3";}
}
class B extends A{
     public String f(B x,B y){return "B1 + "+f(x,(Object)y);}
     public String f(A x,Object y){return "B2";}
}
class C extends B{
    public String f(A x,Object y){return "C1 + "+f(x,(B)y);}
    public String f(Object x,A y){return "C2";}
}


/* //versione nuova
class Cellphone {

	private String gestore;
	private String numero;

	private static HashMap<String, HashMap<String,Double>> M1 = new HashMap();


	public Cellphone(String g,String n) {
		gestore = g;
		numero = n;
		M1.put(g,null);
	}

	public static void setCost(String g1, String g2, Double costo) {

		HashMap<String, Double> M2;

		if(M1.get(g1)==null) {
		    M2 = new HashMap();
			M2.put(g2,costo);
			M1.put(g1,M2);
			//System.out.println(M1);
		}
		else {
			M2 = M1.get(g1);
			M2.put(g2,costo);
			//iSystem.out.println(M1);
		}

	}

	public Double getCost(Cellphone c, Integer m) {



		HashMap<String,Double> M2 = M1.get(this.gestore);

		if(M2 == null)
			throw new RuntimeException("Map vuota");

		if(M2.get(c.gestore)==null)
			throw new RuntimeException("Non è stato settato un costo da "+this.gestore+" a "+c.gestore);

		return m * M2.get(c.gestore);
	}

}

*/



class Cellphone{
    private String gestore,numero;
    private static Map<String,Utente> M=new HashMap();
    public Cellphone(String g,String n){
        gestore=g;
        numero=n;
        M.put(gestore,new Utente());
    }

    public static void setCost(String a,String b,double x){
        Utente u=M.get(a);
        if(u!=null)
            u.M2.put(b,x);
    }

    public double getCost(Cellphone c,int m){
        Utente u=M.get(gestore);
        if(u.M2.get(c.gestore)!=null){
            return u.M2.get(c.gestore)*m;
        }
        else{
            throw new RuntimeException("Utente non trovato");
        }
    }

    class Utente{
        private  Map<String,Double> M2;
        public Utente(){
            M2=new HashMap();
        }
    }
}


class SharedCounter{
    private static int cont=0;

    public static synchronized void incr(){
        cont++;
      //  System.out.println("sono "+Thread.currentThread().getName()+" e incremento cont : "+cont);
    }

    public static synchronized void decr(){
        if(cont>0)
           cont--;
         //System.out.println("sono "+Thread.currentThread().getName()+" e decremento cont : "+cont);
    }

    public static synchronized void waitForValue(int n){
       //  System.out.println("sono "+Thread.currentThread().getName()+" e controllo se cont è uguale a n, cont : "+cont);
          if(cont!=n)
              Thread.currentThread().interrupt();

          while( Thread.currentThread().isInterrupted()){
             //  System.out.println("sono "+Thread.currentThread().getName()+" e controllo nel while, cont:"+cont);
              if(cont==n)
                  return;
          }
    }
}





public class Esame180917 {
    public static void main(String[] args) {
        //Esercizio 1
       B beta=new C();
       A alfa=beta;
       System.out.println(alfa.f(beta,null));
       System.out.println(beta.f(beta,beta));
       System.out.println(beta.f(alfa,(B)null));   //il cast a B vale eccome.
        System.out.println(3|12);



       /*Cellphone a= new Cellphone("TIMMY","3341234"),
                 b= new Cellphone("Megafon","3355678"),
                 c= new Cellphone("Odissey","3384343");
       Cellphone.setCost("TIMMY","TIMMY",0.05);
       Cellphone.setCost("TIMMY","Megafon",0.15);
       Cellphone.setCost("Megafon","TIMMY",0.25);

        System.out.println(a.getCost(b,10));
        System.out.println(b.getCost(a,8));
        System.out.println(a.getCost(c,10));*/


    /*   Thread t1=new Thread(){
           public void run(){
               SharedCounter.incr();
           }
       };
        Thread t2=new Thread(){
           public void run(){
               SharedCounter.incr();
           }
       };
         Thread t3=new Thread(){
           public void run(){
               SharedCounter.decr();
           }
       };

          Thread t4=new Thread(){
           public void run(){
               SharedCounter.waitForValue(2);
           }
       };
           Thread t5=new Thread(){
           public void run(){
               SharedCounter.incr();
           }
       };
           t1.start(); t2.start(); t3.start(); t4.start(); t5.start();*/
    }

}
