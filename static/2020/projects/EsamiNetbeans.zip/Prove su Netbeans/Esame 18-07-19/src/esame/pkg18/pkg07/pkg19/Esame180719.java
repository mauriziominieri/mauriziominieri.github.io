package esame.pkg18.pkg07.pkg19;

import java.math.BigInteger;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;


class A{
     public String f(Object a,A b){ return "A1";}
     public String f(A a,B b){ return "A2";}
}
class B extends A{
     public String f(B a,B b){ return "B1 + "+f(a,(A)b);}
     public String f(A a,B b){ return "B2";}
}


/*
Implementa Fraction e la sottoclasse ReducedFraction
Due oggetti di questo tipo devono essere uguali per equals se rappresentano lo stesso numero razionale
Oltre a un costruttore che accetta numeratore e denominatore, le due classi offrono il metodo times, che
calcola il prodotto, restituendo un nuovo oggetto Fraction. Il nuovo oggetto deve essere di tipo effettivo
ReducedFraction se e soltanto se entrambi gli operandi del prodotto sono di tipo effettivo ReducedFraction.
Suggerimento: per calcolare il massimo comun divisore tra due interi a e b, si può usare l’istruzione
BigInteger.valueOf(a).gcd(BigInteger.valueOf(b)).intValue().

Esempio d’uso:
Fraction a = new Fraction(12,30), b = new ReducedFraction(12,30), c = new Fraction(1,4), d = c.times(a);
System.out.println(a);
System.out.println(b);
System.out.println(d);
System.out.println(a.equals(b));
System.out.println(c.times(b));
Output:
12/30
2/5
12/120
true
2/20
*/

class Fraction{                 //Devo subito pensare che nella sottoclasse dovrò usare il costruttore con gli stessi parametri e fare super(...);
    protected int numeratore;
    protected int denominatore;

    public Fraction(int n,int d){
        numeratore=n;
        denominatore=d;
    }

    public Fraction times(Fraction f){    //se un oggetto è di tipo effettivo Fraction allora o.times() dal main andrà qui.
       // System.out.println("Entrato in times di Fraction");
        if(f.getClass()==ReducedFraction.class){       //se f è di tipo effettivo ReducedFraction
            ReducedFraction f2=(ReducedFraction) f;     //trasformo f in ReducedFraction per poter utilizzare il numeratore_r e denominatore_r
            Fraction f1=new Fraction(numeratore*f2.numeratore_r,denominatore*f2.getDenominatoreR());  //esempio su come si possa fare senza usare l'attributo protected
            return f1;
        }
        else{
            Fraction f1=new Fraction(numeratore*f.numeratore,denominatore*f.denominatore);
            return f1;
        }
    }

    public boolean equals(Fraction f){
        if(numeratore==f.numeratore && denominatore==f.denominatore)
            return true;

        return false;
    }

    public String toString(){
        return numeratore+"/"+denominatore;
    }
}

class ReducedFraction extends Fraction{
    protected int numeratore_r;
    private int denominatore_r;     //uso getDenominatore_r perchè avrò un istanza in times di questo'oggetto che mi permette di usarla.
    private int MCD;
    public ReducedFraction(int n,int d){
        super(n,d);                             //regola della sottoclasse, n e d saranno i valori passati dal main. Niente paura.
        MCD=BigInteger.valueOf(n).gcd(BigInteger.valueOf(d)).intValue();
        numeratore_r=n/MCD;
        denominatore_r=d/MCD;
    }

    public Fraction times(Fraction f){      //se un oggetto è di tipo effettivo ReducedFraction allora o.times() dal main andrà qui.
      //  System.out.println("Entrato in times di ReducedFraction");
        if(f.getClass()==ReducedFraction.class){     //se anche f è di tipo effettivo ReducedFraction allora
            ReducedFraction f2=(ReducedFraction) f;   //trasformo f in ReducedFraction in modo tale da poter accedere al numeratore_r,denominatore_r
            ReducedFraction rf=(ReducedFraction) new ReducedFraction(numeratore_r*f2.numeratore_r,denominatore_r*f2.denominatore_r);
            return rf;
        }
        else{
            Fraction f1=new Fraction(numeratore_r*f.numeratore,denominatore_r*f.denominatore);
            return f1;
        }
    }

     public String toString(){
        return numeratore_r+"/"+denominatore_r;
    }

     public int getDenominatoreR(){
         return denominatore_r;
     }
}


//Esercizio 3
/*
Realizzare la classe SafeSet, che rappresenta un insieme che richiede due passaggi per rimuovere completamente
un oggetto. Il metodo add aggiunge un elemento all’insieme, restituendo true se l’inserimento
ha avuto successo. Il metodo remove rimuove un elemento dall’insieme, ma la rimozione è definitiva solo
dopo una seconda chiamata. Il metodo contains verifica se l’insieme contiene un dato elemento (in base a
equals). Infine, un SafeSet deve essere thread-safe. Il seguente diagramma rappresenta il ciclo di vita di
un oggetto all’interno di un SafeSet:*/
class SafeSet<T> {

	HashSet<T> mySet;
	HashSet<T> trash;

	public SafeSet() {
		mySet = new HashSet();
		trash = new HashSet();
	}

	public Boolean add(T s) {

		if(mySet.contains(s))  //present, cioè se s è già presente nel mySet
			return false;

		if(trash.contains(s))   //trash, cioè se s è presente nel trash (poi aggiungo nel mySet e restituisco true)
			trash.remove(s);

		mySet.add(s);     //absent, cioè s viene aggiunto al mySet
		return true;
	}

	public Boolean remove(T s) {

		if(trash.contains(s)) {   //trash
			trash.remove(s);
			return true;
		}

		if(!mySet.contains(s))  //absent
			return false;

		mySet.remove(s);   //present, mySet contiene s, lo elimino e lo inserisco nel trash
		trash.add(s);
		return true;
	}

	public Boolean contains(T s) {


		if(!mySet.contains(s))   //absent e anche trash
			 return false;

		return true;   //present, l'unica volta in cui restituisco true è quando s è presente in mySet

	}

}


public class Esame180719 {
    public static void main(String[] args) {

            //Esercizio 1
       /* B beta=new B();
        A alfa = beta;
        System.out.println(alfa.f(beta,null));
        System.out.println(beta.f(beta,beta));
        System.out.println(beta.f(alfa,null));*/


         //Esercizio 2
        Fraction a= new Fraction(12,30),b=new ReducedFraction(12,30),c=new Fraction(1,4),d=c.times(a);
        System.out.println("a : "+a);
        System.out.println("b : "+b);
       //System.out.println("c : "+c);
        System.out.println("d : "+d);
        System.out.println(a.equals(b));
        System.out.println(c.times(b));






         //Esercizio 3
       /* SafeSet<String> a = new SafeSet<>();
        System.out.println(a.add("ciao"));
        System.out.println(a.add("mondo"));
        System.out.println(a.remove("ciao"));
        System.out.println(a.contains("ciao"));
        System.out.println(a.remove("ciao"));
        System.out.println(a.contains("ciao"));*/



       /*
        //Esercizio 4
        final Object x=new Object();
        final int[] count = new int[1];

        class MyThread extends Thread{
            int id;
            public MyThread(int n){
                id=n;
            }

            public void run(){
                System.out.println("Sono "+id+" e sono partito il mio nome è : "+Thread.currentThread().getName());

                synchronized(x){
                    synchronized(count){
                        System.out.println("Sono "+id+" e sto nel sync count");
                        count[0]++;
                           System.out.println("Sono "+id+" e count = "+count[0]);
                        count.notify();
                        System.out.println("Sono "+id+" e risveglio uno dei thread su count");
                    }
                    try{
                      //   System.out.println("Sono "+id+" e incontro x.wait()");
                        x.wait();
                     //    System.out.println("Sono "+id+" e l'attesa è finita");
                    }catch(Exception e){
                       //  System.out.println("Sono "+id+" e sveglio chi sta in attesa su x");
                        x.notify();
                        //  System.out.println("Sono "+id+" e ho svegliato chi sta in attesa su x");
                    }

                        System.out.println(id);

                }
            }

        }

        Thread t1=new MyThread(1),t2=new MyThread(2),t3=new MyThread(3);          //Quando creo mythread i thread vedono tutti gli oggetti in cui sono, quindi vedono anche count e x
        t1.start();
        t2.start();
        t3.start();

        System.out.println("Sono "+Thread.currentThread().getName()+" e sto dopo gli start");
        synchronized(count){
            while(count[0]<3)
                try{   System.out.println("Sono "+Thread.currentThread().getName()+" e metto chi sta su count in attesa");count.wait();}catch(Exception e){}
        }
           System.out.println("Sono "+Thread.currentThread().getName()+" e setto a true la flag interrupt di t2");
        t2.interrupt();
     //      System.out.println("Sono "+Thread.currentThread().getName()+" e aspetto t2");
        try{t2.join();}catch(Exception e){}
        //   System.out.println("Sono "+Thread.currentThread().getName()+" e sto prima del fatto");
        System.out.println("Fatto");*/
    }
    /*
    Tutti e 3 i thread hanno x e count nel corpo, supponendo che partano i thread in quest'ordine: 1,2,3 avremmo che 1 incrementa
    count, nel frattempo il main sta nel while e si ferma(dato che anche lui ha count nel corpo), 1 sveglia il main che fa un
    iterazione nel while e si riblocca e intanto anche 1 si blocca perchè incontra x.wait().
    La stessa cosa la fanno 2 e 3, si bloccano tutti a x.wait(). Però sbloccano il main che esce dal while, cambia la flag di
    interrupt di 2 con : t2.interrupt(), quindi 2 dal try salta al catch e sveglia un thread a caso che sta in attesa su x (1 o 3).
   Il main intanto si blocca perchè incontra t2.join(), quindi asdpetta che t2 finisca prima di proseguire. Viene stampato quindi
    sempre prima 2, poi potrebbe essere stampato Fatto e poi 1, oppure 2 1 e fatto...
    Gli output possibili sono : 2,1,fatto,->.       2,fatto,1,->.       2,3,fatto,->.      2,fatto,3,->.
    */


}
