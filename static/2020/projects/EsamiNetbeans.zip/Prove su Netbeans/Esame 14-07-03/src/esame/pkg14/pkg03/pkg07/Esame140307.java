
package esame.pkg14.pkg03.pkg07;
import java.util.*;







class A {
    public String f(Object x, int n) { return "A1"; }
    public String f(A x, int n) { return "A2:" + n; }
    public String f(A x, double n) { return "A3:" + x.f(x, (int) n); }
    private String f(B x, int n) { return "A4"; }
}
class B extends A {
    public String f(A x, double n) { return "B1:" + n; }
    public String f(B x, double n) { return "B2:" + f((A) x, 2); }
    public String f(A x, int n) { return "B3"; }
}




/*   //Esercizio 2
L'enumerazione Nutrient contiene i valori FAT, CARBO e PROTEIN. Implementare la classe NutrInfo che
rappresenta la scheda nutrizionale di un prodotto gastronomico. Il suo costruttore accetta il numero di
chilocalorie. Il metodo setNutrient permette di impostare la quantità (in grammi) di ciascun nutriente.
La classe è dotata di un ordinamento naturale, basato sul numero di calorie. Inoltre, la classe offre
il metodo statico comparatorBy che accetta un valore Nutrient e restituisce un comparatore basato sul
contenuto di quel nutriente.

Esempio d'uso:
NutrInfo x = new NutrInfo(500);
x.setNutrient(Nutrient.FAT, 12.0);
x.setNutrient(Nutrient.CARBO, 20.0);
x.setNutrient(Nutrient.PROTEIN, 15.0);
Comparator<NutrInfo> c = NutrInfo.comparatorBy(Nutrient.FAT);

 */
enum Nutrient{
    
    FAT(0.0),CARBO(0.0),PROTEIN(0.0);
    
    protected double quantità;
    
    private Nutrient(double quantità){
        this.quantità=quantità;
    }
}


class NutrInfo{
    private int num_kcal;
    private double A[];
    
    public NutrInfo(int num_kcal){
        this.num_kcal=num_kcal;
        A=new double[3];
    }
    
    
    public void setNutrient(Nutrient n,double quantità){
           A[n.ordinal()]=quantità;
           System.out.println(A[n.ordinal()]);
    }
    
   
    
    
    public static Comparator<NutrInfo> comparatorBy(Nutrient n){
        return new Comparator(){
            public int compare(Object o1,Object o2){
                
                NutrInfo x=(NutrInfo) o1;
                NutrInfo y=(NutrInfo) o2;
                
                
                if(x.A[n.ordinal()]>y.A[n.ordinal()])
                    return 1;
                else if(x.A[n.ordinal()]<y.A[n.ordinal()])
                    return -1;
                return 0;
            }
        };
    }
}

/*
Un Exchanger è un oggetto che serve a due thread per scambiarsi due oggetti dello stesso tipo. Ciascun
thread invocherà il metodo exchange passandogli il proprio oggetto e riceverà come risultato l'oggetto
passato dall'altro thread. Il primo thread che invoca exchange dovrà aspettare che anche il secondo thread
invochi quel metodo, prima di ricevere il risultato. Quindi, il metodo exchange risulta bloccante per il
primo thread che lo invoca e non bloccante per il secondo.
Un Exchanger può essere usato per un solo scambio. Ulteriori chiamate ad exchange dopo le prime due
portano ad un'eccezione.
Nell'esempio d'uso, due thread condividono il seguente oggetto:
Exchanger<String> e = new Exchanger<String>();
Thread 1:
String a = e.exchange("ciao");
System.out.println(a);
Thread 2:
String a = e.exchange("Pippo");
System.out.println(a);
Output thread 1:
Pippo
Output thread 2:
ciao
*/





class Exchanger<T>{
    
    public String exchange(String s){
        
    }
}

public class Esame140307 {
   
    
    public static void main(String[] args) {
        
       /* B beta = new B();             //Esercizio 1
        A alfa = beta;
        System.out.println( alfa . f (null, 2L));
        System.out.println(beta. f (beta, 5.0) );
        System.out.println(12 & 2);*/
        
        
      /* NutrInfo x = new NutrInfo(500);               //Esercizio 2
        x.setNutrient(Nutrient.FAT, 12.0);
        x.setNutrient(Nutrient.CARBO, 20.0);
        x.setNutrient(Nutrient.PROTEIN, 15.0);
        Comparator<NutrInfo> c = NutrInfo.comparatorBy(Nutrient.FAT);*/
      
      
        Thread t1=new Thread(),t2=new Thread();
         
        Exchanger<String> e = new Exchanger<String>();
        
        String a = e.exchange("ciao");
        System.out.println(a);
       
        String b = e.exchange("Pippo");
        System.out.println(b);
      
      
      
      
      
      
      
    }
    
}
