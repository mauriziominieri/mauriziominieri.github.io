package esame.pkg16.pkg03.pkg03;
import java.util.*;


abstract class A {                                           //CLASSE ASTRATTA
	public abstract String f(A[] x, Object y);          //METODO ASTRATTO, QUINDI LA SOTTOCLASSE CHE LA ESTENDE DEVE EFFETTUARNE L'OVVERIDE
                                                            //E DARNE L'IMPLEMENTAZIONE,(altrimenti anche lei dovrebbe essere astratta).
                                                            //Quando estendiamo (o deriviamo) da una classe astratta, la classe derivata deve 
                                                            //fornire una implementazione per tutti i metodi astratti dichiarati nella classe genitrice
                                                            //a questo punto quindi questo metodo farà  partire il metodo in B, quindi output B2
	public String f(Object[] x, A[] y) { return "A2"; }
}

class B extends A {
	public String f(B[] x, Object y) { return "B1"; }
	public String f(A[] x, Object y) { return "B2"; }
	public String f(B[] x, A[] y) { return "B3"; }
       
}
class C extends B {
	public String f(B[] x, A[] y) { return "C1"; }
        
}

/* Esercizio 2
Implementare la classe GameLevel, che rappresenta un livello in un gioco 2D, in cui un personaggio
si muove su una griglia di caselle. Il costruttore accetta le dimensioni del livello (larghezza e
altezza). Il metodo setWall accetta le coordinate di una casella e mette un muro in quella casella.
Il metodo areConnected accetta le coordinate di due caselle e restituisce vero se e solo se esiste
un percorso tra di loro.
Caso d’uso:
GameLevel map = new GameLevel(3, 3);
System.out.println(map.areConnected(0,0,2,2));
map.setWall(0,1);
map.setWall(1,1);
System.out.println(map.areConnected(0,0,2,2));
map.setWall(2,1);
System.out.println(map.areConnected(0,0,2,2));
Output:
true true false
*/
class GameLevel implements Cloneable{
    private int[][] Mat;
    int larghezza;
    int altezza;
    
    public GameLevel(int larghezza,int altezza){
        this.larghezza=larghezza;
        this.altezza=altezza;
        this.Mat=new int[altezza][larghezza];
    }
    
    public void setWall(int x,int y){
        if(x<0||y<0||x>=altezza||y>=larghezza)
            throw new RuntimeException("Errore");
        else
           this.Mat[x][y]=1;
    }
    
    public boolean areConnected(int a,int b,int x,int y){
        boolean[][] Mat2=new boolean[altezza][larghezza];
        return areConnected2(a,b,x,y,Mat2);
    }
    
     public boolean areConnected2(int a,int b,int x,int y,boolean[][] Mat2){
         
         Mat2[a][b]=true;
         
         if(a==x&&b==y)
             return true;
         
         if(isValid(a-1,b)&&this.Mat[a-1][b]!=1&&Mat2[a-1][b]==false)
             return areConnected2(a-1,b,x,y,Mat2);
         if(isValid(a,b-1)&&this.Mat[a][b-1]!=1&&Mat2[a][b-1]==false)
             return areConnected2(a,b-1,x,y,Mat2);
         if(isValid(a+1,b)&&this.Mat[a+1][b]!=1&&Mat2[a+1][b]==false)
             return areConnected2(a+1,b,x,y,Mat2);
         if(isValid(a,b+1)&&this.Mat[a][b+1]!=1&&Mat2[a][b+1]==false)
             return areConnected2(a,b+1,x,y,Mat2);
         
         return false;
         
     }
     
     public boolean isValid(int a,int b){
         if(a<0||b<0||a>=altezza||b>=larghezza)
             return false;
         else
             return true;
     }
    
}

/*Esercizio 3
Escludendo i cosiddetti spurious wakeup, elencare tutte le sequenze di output possibili per il
seguente programma.
public static void main(String[] args) {
class MyThread extends Thread {
private int id;
private Object object;
public MyThread(int n, Object x) {
id = n;
object = x;
}
public void run() {
try {
if (object!=null) synchronized (object) {
object.wait();
}
} catch (InterruptedException e) { return; }
System.out.println(id);
}
}
Object o1 = new Object(), o2 = new Object();
Thread t1 = new MyThread(1,null);
Thread t2 = new MyThread(2,o1);
Thread t3 = new MyThread(3,o1);
Thread t4 = new MyThread(4,o2);
t1. start () ; t2. start () ; t3. start () ; t4. start () ;
try { Thread.sleep(1000); } catch (InterruptedException e) { }
synchronized (o2) { o2.notify(); }
synchronized (o1) { o1.notify(); }
}*/
 //t1 ha nel corpo null, t2 ha nel corpo o1, t3 o1, t4 o2.
//li starto tutti contemporaneamente. Tutti entrano nel try e tutti tranne t1 restano bloccati nel object.wait(), 1 viene stampato
//Passa 1 secondo e viene risvegliato un thread a caso su o2, e uno a caso su o1.
//Output possibili quindi: (1,4,2,...) (1,2,4,...) (1,4,3,...) (1,3,4,...)


public class Esame160303 {

    public static void main(String[] args) {
               //ESERCIZIO1
                /*B beta = new C();
		A alfa = new B();
		B[] array = new B[10];
                
                System.out.println(alfa.f(array, beta));        // A.f(B[],B) //L'unica candidata è il metodo abstract, quindi B2, il metodo che ne fa l'ovveride
                System.out.println(beta. f (array, beta));      // B.f(B[],B) candidate: B1 B2
                System.out.println(beta. f (array, array));    //  B.f(B[],B[]) candidate: B1 B2 B3 A2
                System.out.println(beta. f (null, array));     //B.f(null,B[])  candidate: B1 B2 B3 A2*/

             
             
             GameLevel map = new GameLevel(3, 3);
             System.out.println(map.areConnected(0,0,2,2));
             map.setWall(0,1);
             map.setWall(1,1);
             System.out.println(map.areConnected(0,0,2,2));
             map.setWall(2,1);
             System.out.println(map.areConnected(0,0,2,2));
            
            
            
           
    }
}

