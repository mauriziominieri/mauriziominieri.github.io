/*
Si implementi la classe Crosswords, che rappresenta uno schema di parole crociate, inizialmente vuoto.
Il costruttore accetta le dimensioni dello schema. Il metodo addWord aggiunge una parola allo schema
e restituisce true, a patto che la parola sia compatibile con quelle precedentemente inserite; altrimenti,
restituisce false senza modificare lo schema. Il metodo prende come argomenti le coordinate iniziali della
parola, la parola stessa e la direzione (H per orizzontale e V per verticale).
Le regole di compatibilità sono:
• Una parola non si può sovrapporre ad un'altra della stessa direzione.
• Una parola si può incrociare con un'altra solo su di una lettera comune.
• Ogni parola deve essere preceduta e seguita da un bordo o da una casella vuota.
Non è necessario implementare il metodo toString. E' opportuno implementare le direzioni H e V in modo
che siano le uniche istanze del loro tipo.
Suggerimenti:
• Per evitare di scrivere separatamente i due casi per orizzontale e verticale, è possibile aggiungere i
metodi getChar/setChar, che prendono come argomenti una riga r, una colonna c, una direzione d (H
o V) e un offset x, e leggono o scrivono il carattere situato a distanza x dalla casella r, c, in direzione
d.
• Il metodo s.charAt(i) restituisce il carattere i-esimo della stringa s (per i compreso tra 0 e s.length()-1)


Esempio d'uso:
Crosswords c = new Crosswords(6, 8);
System.out.println(c.addWord(0,3, "casa", Crosswords.V));
System.out.println(c.addWord(2,1, "naso", Crosswords.H));
System.out.println(c.addWord(2,0, "pippo", Crosswords.H));
System.out.println(c);

Output:
true
true
false
c
a
*naso*
a
*
 */
package esame.pkg10.pkg03.pkg05;
import java.util.*;




class Crosswords{
   private CrossWordRow[] tabella;
	public static final boolean H=false;
	public static final boolean V=true;
	private int w,h;
	
	Crosswords(int w, int h){
		this.w = w;
		this.h = h;
		tabella = new CrossWordRow[h];
	}
	
	public boolean addWord(int x, int y, String word, boolean dir){
		if(dir){ //V
			for(int i=y,j=word.length(); i<(y+j);i++){
				if(tabella!=null && !tabella.checkEmpty(x)){
					return false;
				}
			}
		}else{
			if(tabella[y]!=null && !tabella[y].checkEmpty(x,word.length()))
				return false;
		}
		if(dir){
			for(int i=y,j=word.length(); i<(y+j);i++){
				if(tabella==null)
					tabella=new CrosswordsRow(w);
				
				tabella.setChar(x,word.charAt(i-y));
			}
			if((y+word.length())<this.h){
				tabella[y+word.length()].addBlockCell(x);
			}
		}else{
			if(tabella[y]==null)
				tabella[y]=new CrosswordsRow(w);
			
			tabella.setWord(x,word);
		}
	}
	
	private class CrosswordsRow{
		char[] riga;
		
		CrosswordsRow(int w){
			riga = new char[w];
		}
		
		void setChar(int x, char c){
			riga[x]=c;
		}
		
		void setWord(int x, String s){
			for(int i=0;i<w.length();i++)
				setChar(x+i,s.charAt(i));
			addBlockCell(x+w.length());
		}
		
		void addBlockCell(int x){
			if(x<w)
				riga[x]='\u0001'; //0001 is not printable char
		}
		
		boolean checkEmpty(int x){
			if(x>=w)
				return false;
			return riga[x] == '\u0000';
		}
		
		boolean checkEmpty(int x, String w){
			for(i=0;i<w.length();i++)
				if(!checkEmpty(x+i))
					return false;
			return true;
		}
	}
    
}




public class Esame100305 {
    public static void main(String[] args) {
      Crosswords c = new Crosswords(6, 8);
        System.out.println(c.addWord(0,3, "casa", Crosswords.V));
        System.out.println(c.addWord(2,1, "naso", Crosswords.H));
        System.out.println(c.addWord(2,0, "pippo", Crosswords.H));
        System.out.println(c);
    }
    
}
