package esame.pkg17.pkg02.pkg23;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;




/* ESERCIZIO 1
Implementare il metodo statico sumAndMax, che accetta un array di double e restituisce un array
di due double, che conterranno rispettivamente la somma e il massimo del primo array.
Il metodo deve calcolare i due risultati in parallelo. Inoltre, qualora la somma (anche parziale)
andasse in overflow, il metodo deve interrompere il thread che sta calcolando il massimo e
restituire null.
Suggerimento: se un’addizione tra due double va in overflow, il suo risultato sarà Double.POSITIVE_INFINITY
o Double.NEGATIVE_INFINITY.
*/
public class Esame170223 {
    
      private static double max=0;
      private static double sum=0;
      private static boolean flag=false;
      private static ArrayList<Double> ARRAY=new ArrayList();
      private static MyThreadMax t2;
    
    static class MyThreadSomma extends Thread{

        public MyThreadSomma(ArrayList<Double> A){
            ARRAY=A;
        }
        
        public void run(){
            
            for(int i=0;i<ARRAY.size();i++){
                
                sum=sum+ARRAY.get(i);
                if(sum==Double.POSITIVE_INFINITY||sum==Double.NEGATIVE_INFINITY){
                    t2.interrupt();
                    flag=true;}
                System.out.println("qui"+Thread.currentThread().getName());
            }
            
        }
    }
    
    static class MyThreadMax extends Thread{

        public MyThreadMax(ArrayList<Double> A){
            ARRAY=A;
            t2=this;
        }
        
        public void run(){
            
            for(int i=0;i<ARRAY.size();i++){
                if(this.isInterrupted())
                    return;
              if(max<ARRAY.get(i)){
                  max=ARRAY.get(i);
            }
              System.out.println("qui"+Thread.currentThread().getName());
            }
        }
    }
    
    public static Map<ArrayList<Double>,ArrayList<Double>> sumAndMax(ArrayList<Double> A){
        
        Map<ArrayList<Double>,ArrayList<Double>> R=new HashMap();
        ArrayList<Double> Somma=new ArrayList();
        ArrayList<Double> Max=new ArrayList();
        
        Thread t1=new MyThreadSomma(A);
        Thread t2=new MyThreadMax(A);
        
        t1.start();
        t2.start();
          try {
              t1.join();
          } catch (InterruptedException ex) {
             
          }
          try {
              t2.join();
          } catch (InterruptedException ex) {
              
          }
          
        Somma.add(sum);
        Max.add(max);
        System.out.println("somma : "+sum); 
        System.out.println("max : "+max);
        R.put(Somma,Max);
        
        if(flag==true) return null;
        
        return R;
        
    }
    
    public static void main(String[] args) {
      
       //esercizio 1
       /* ArrayList<Double> A=new ArrayList();
        A.add(10.0);
        A.add(19.0);
        A.add(Double.POSITIVE_INFINITY);
        A.add(19.0);
        A.add(18.0);
        System.out.println(sumAndMax(A));*/
    }
    
}
