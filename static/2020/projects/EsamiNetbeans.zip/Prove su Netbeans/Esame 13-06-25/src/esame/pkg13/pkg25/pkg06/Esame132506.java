/*
 Implementare la classe parametrica MultiBuffer, che rappresenta un insieme di buffer. Il suo
costruttore accetta il numero n di buffer da creare. Il metodo insert inserisce un oggetto nel
buffer che in quel momento contiene meno elementi. Il metodo bloccante take accetta un intero i
compreso tra 0 ed n − 1 e restituisce il primo oggetto presente nel buffer i-esimo. La classe deve
risultare thread-safe.
 */
package esame.pkg13.pkg25.pkg06;
import java.nio.Buffer;
import java.util.*;

class MultiBuffer<I>{
    int n_buffer;
    Buffer buffer;
    
    public MultiBuffer(int n_buffer){
        this.n_buffer=n_buffer;
    }
    
    public void insert(int oggetto){
        buffer.put(oggetto);
    }
    
    public int take(int i){
        if(i<0||i>=n_buffer)
            throw new RuntimeException("Errore");
        else
            
    }
}
        
(Non so farlo)public class Esame132506 {
    public static void main(String[] args) {
        MultiBuffer<Integer> mb = new MultiBuffer<Integer>(3);
        mb.insert(13);
        mb.insert(24);
        mb.insert(35);
        System.out.println(mb.take(0));
    }
    
}
