package esame.pkg12.pkg23.pkg04;
import java.util.*;

/*Implementare la classe Safe, che rappresenta una cassaforte che contiene una stringa segreta,
protetta da un numero intero che funge da combinazione. Il costruttore accetta la combinazione
e la stringa segreta. Il metodo open accetta un numero intero e restituisce la stringa segreta
se tale numero coincide con la combinazione. Altrimenti, restituisce null. Infine, se le ultime 3
chiamate a open sono fallite, la cassaforte diventa irreversibilmente bloccata ed ogni ulteriore
operazione solleva un’eccezione.
Implementare la classe ResettableSafe come una sottoclasse di Safe che aggiunge il metodo changeKey,
che accetta due interi old e new e restituisce un boolean. Se la cassaforte è bloccata, il
metodo solleva un’eccezione. Altrimenti, se l’argomento old coincide con la combinazione attuale,
il metodo imposta la combinazione della cassaforte a new e restituisce true. Se invece old
differisce dalla combinazione attuale, il metodo restituisce false.
Una ResettableSafe diventa bloccata dopo tre tentativi falliti di open o di changeKey. Ogni
chiamata corretta a open o changeKey azzera il conteggio dei tentativi falliti.
Suggerimento: prestare attenzione alla scelta della visibilità di campi e metodi.
Esempio d’uso:
ResettableSafe s = new ResettableSafe(2381313, "L’assassino␣e’␣il␣maggiordomo.");
System.out.println(s.open(887313));
System.out.println(s.open(13012));
System.out.println(s.changeKey(12,34));
System.out.println(s.open(2381313));
Output dell’esempio d’uso:
null
null
false
Exception in thread "main"...
*/


class Safe{
    protected int combinazione;
    private String segreto;
    protected int count_errori=0;
    
    public Safe(int c,String s){
        combinazione=c;
        segreto=s;
    }
    
    public String open(int i){
        
        if(count_errori==3){
            throw new RuntimeException("BLOCCATA");
        }
        
        if(i==combinazione){
            count_errori=0;
            return segreto;
        }
        
        count_errori++;
        return null;
    }
    
  
}

class ResettableSafe extends Safe{
    
    private static boolean RFbloccata=false;
    protected int count_errorirf=0;
    
     public ResettableSafe(int c,String s){
         super(c,s);              //vado a mettere in c e in s gli stessi c e s della superclasse, UNA SOTTOCLASSE è OBBLIGATA A FARE QUESTO PROCEDIMENTO SE LA SUPERCLASSE HA UN COSTRUTTORE.
        
     }
     
     public boolean changeKey(int old,int _new){
         if(count_errorirf==3||count_errori==3)
             throw new RuntimeException("RF bloccata");
         
         if(old==combinazione){
             combinazione=_new;
               count_errorirf=0;
             return true;
         }
         else{
             count_errorirf++;
             return false;
         }

     }
    
}




/*
class Safe{                                                  //CLASSE SAFE
   private String secret;
   protected int password;                                   //protected=Può essere visto da tutto ciò che sta in questo pacchetto
   protected int fails;
   
   public Safe(int password,String secret)                 //COSTRUTTORE DELLA CLASSE SAFE, (deve avere lo stesso nome della classe)        
   {
       this.secret=secret;                    
       this.password=password;
   }
   
   public String open(int pass)                                        //METODO OPEN, (prende in input un intero e restituisce una stringa)
   {
      if(fails==3)
          throw new RuntimeException("Cassaforte bloccata");
      else
      {
          if(password!=pass)
          {
              fails++;
              return null;
          }
          else
          {
              fails=0;
              return secret;
          }
      }
   }
}

class ResettableSafe extends Safe{                            //CLASSE RESETTABLESAFE, SOTTOCLASSE DI SAFE

   public ResettableSafe(int password,String secret)
   {
        super(password,secret);
   }
   
   public boolean changeKey(int old,int new_)                    //METODO CHANGEJEY, (prende in input due interi e restituisce un boolean)
   {
       if(fails==3)
          throw new RuntimeException("Cassaforte bloccata");
      else
      {
          if(old==password)
          {
              password=new_;
              fails=0;
              return true;
          }
          else
          {
              fails++;
              return false;
          }
      }
   }
   
   
}*/

public class Esame122304 {

    
    public static void main(String[] args) {                             //CASO D'USO
      
        ResettableSafe s=new ResettableSafe(2381313,"L'assassino è il maggiordomo");
        
        System.out.println(s.open(887313));
        System.out.println(s.open(13012));
        System.out.println(s.changeKey(12,34));
        System.out.println(s.open(2381313));
        
    }
    
}
