package esame.pkg18.pkg02.pkg05;
import java.util.*;







                //ESERCIZIO 1
class A{
    public String f(Object a,A b){return "A1";}
     public String f(A a,C b){return "A2";}
}
class B extends A{
    public String f(Object a,A b){return "B1 + "+f(null,new B());}
     private String f(A a,B b){return "B2";}
}

class C extends B{
    public String f(Object a,B b){return "C1";}
    public String f(A a,B b){return "C2";}
}








 /*             // ESERCIZIO 2
Realizzare la classe Product, che rappresenta un prodotto di un supermercato, caratterizzato da descrizione e prezzo.
I prodotti sono dotati di ordinamento naturale in base alla loro descrizione (ordine alfabetico). Il metodo getMostExpensive restituisce
il prodotto più costoso. Il campo comparatorByPrice contiene un comparatore tra prodotti, che confronta i prezzi.

Caso D'uso:
    Product a=new Product("Sale",0.60),b=new Product("Zucchero",0.95),c=new Product("Caffè",2.54);
    System.out.println(Product.getMostExpensive());
    System.out.println(b.compareTo(c));
    System.out.println(Product.comparatorByPrice.compare(b,c));

Output: 
    Caffè, 2.54
    1
    -1
 */

class Product implements Comparable<Product>{
    private String descrizione;
    private double prezzo;
    private static Product PMAX;
    protected static Comparator comparatorByPrice=new Comparator<Product>(){
        public int compare(Product a,Product b){
            if(a.prezzo>b.prezzo) return 1;
            else if(a.prezzo<b.prezzo) return -1;
            return 0;
        }
    };
    
    public Product(String d,double p){
        descrizione=d;
        prezzo=p;
        if(PMAX==null||PMAX.prezzo<prezzo){
            PMAX=this;
        }
    }
    
    public int compareTo(Product p){
        if(descrizione.compareTo(p.descrizione)>0) return 1;
        else if(descrizione.compareTo(p.descrizione)<0) return -1;
        else return 0;
    }
    
    public static Product getMostExpensive(){
        return PMAX;
    }
    
    public String toString(){
        return descrizione+", "+prezzo;
    }
    
    
}



 /*               //ESERCIZIO 3
Realizzare un metodo chiamato merge che rispetti il seguente contratto:
Pre-condizione Accetta due LinkedList dello stesso tipo di pari lunghezza.
Post-condizione Restituisce una nuova LinkedList ottenuta alternando gli elementi della prima lista e quelli della seconda.
Ad esempio, se la prima lista contiene (1, 2, 3) e la seconda lista (4, 5, 6), la nuova lista deve contenere
(1, 4, 2, 5, 3, 6).
Penale Se le liste non hanno la stessa lunghezza, lancia IllegalArgumentException
*/




class CLASSE<T>{
    
    
    public <T> LinkedList<T> merge(LinkedList<T> L1,LinkedList<T> L2){
        
        LinkedList<T> L3=new LinkedList();
        
             if(L1.size()!=L2.size())
                 throw new IllegalArgumentException("Le liste hanno lunghezza diversa");
             
             /*for(int i=0;i<L1.size();i++){
                 L3.add(L1.get(i));
                 L3.add(L2.get(i));
             }*/
             
            // OPPURE
             
             Iterator i1=L1.iterator();
             Iterator i2=L2.iterator();
             
             while(i1.hasNext()){
                L3.add((T)i1.next());
                L3.add((T)i2.next());
             }
             
             return L3;
     }
}


public class Esame180205 {
    public static void main(String[] args) {
    
        /*                        // Esercizio 1
        C gamma=new C();                   
        B beta=gamma;
        A alfa=gamma;
     
       
        System.out.println(alfa.f(beta,gamma));
        System.out.println(beta.f(beta,beta));
        System.out.println(gamma.f(alfa,null));
        System.out.println(beta instanceof A);*/
        
        
        
                                    //  Esercizio 2
        Product a=new Product("Sale",0.60),b=new Product("Zucchero",0.95),c=new Product("Caffè",2.54);
        System.out.println(Product.getMostExpensive());
        System.out.println(b.compareTo(c));
        System.out.println(Product.comparatorByPrice.compare(b,c));
      
        
        
        
        
        /*CLASSE<Integer> c=new CLASSE<Integer>();
          LinkedList top1=new LinkedList(),top2=new LinkedList();
          top1.add("ciao");
          top1.add(2);
          top1.add(3);
          top2.add(1);
          top2.add(5);
          top2.add(6);
        //  top2.add(7);
         
          System.out.println("L1 : "+top1);
          System.out.println("L2 : "+top2);
      
          LinkedList top3=c.merge(top1,top2);
          System.out.println("L3 : "+top3);*/
    }
    
}
