package esame.pkg18.pkg10.pkg18;
import static esame.pkg18.pkg10.pkg18.Component.M;
import java.util.*;


abstract class A{
    public abstract String f(A a,B b);
    public int f(B b,C c){return 1;}
}

class B extends A{
    public String f(A a,B b){return "2";}
     public String f(C c,B b){return "3";}
      public int f(C c,Object x){return 4;}
}
class C extends B{
    public String f(C c1,C c2){return "5";}
     public String f(A a,B b){return "6";}
}

enum Type {
	CPU,BOARD, RAM;
}

public class Component {

	protected Type tipologia;
	private String descrizione;
	protected static HashMap<Component, HashSet<Component>> M = new HashMap();

	public Component(Type t, String d) {
		tipologia = t;
		descrizione = d;
	}

	public void setIncompatible(Component c) {

		HashSet<Component> set = M.get(this);

		if(set == null)
			set = new HashSet();


		set.add(c);
		M.put(this, set);
	}

	public String toString() {
		return descrizione;
	}
}

class Configuration {

	private ArrayList<Component> pc;


	public Configuration() {
		pc = new ArrayList();

	}

	public Boolean add(Component c) {


		if(pc.isEmpty()) {
			pc.add(c);
			return true;
		}

		for (Component component : pc) {
			//vado a scorrere gli elementi della lista e
			//vado a prendere il set collegato alla chiave, vedo se in questo set c'è il componente parametrizzato ||
			//se già c'è una tipologia doppione...
			if(Component.M.get(component).contains(c) || component.tipologia == c.tipologia)
				return false;
		}

		pc.add(c);
		return true;

	}

}

public class Esame181018 {
    public static void main(String[] args) {
       C gamma=new C();
       B beta=gamma;
       A alfa = gamma;
       //System.out.println(alfa.f(null,gamma));
      //  System.out.println(beta.f(gamma,gamma));
       // System.out.println(gamma.f(gamma,alfa));
       // System.out.println(gamma.f(beta,beta));
       // System.out.println(1+"1");

       Component cpu1=new Component(Type.CPU,"Ryzen_5_2600"),
                 cpu2=new Component(Type.CPU,"Core_i5_7500"),
                 board1=new Component(Type.BOARD,"Prime_X470"),
                 board2=new Component(Type.BOARD,"Prime_Z370"),
                 ram=new Component(Type.RAM,"DDR4_SGB");

       cpu1.setIncompatible(board2);
       board1.setIncompatible(cpu2);

       Configuration pc=new Configuration();
        System.out.println(pc.add(cpu1));
        System.out.println(pc.add(cpu2));
        System.out.println(pc.add(board2));
        System.out.println(pc.add(board1));
        System.out.println(pc.add(ram));

    }

}
