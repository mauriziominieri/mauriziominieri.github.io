/*
 Realizzare la classe Cartella, che rappresenta una cartella nella Tombola. Una cartella contiene 15 numeri
casuali diversi, compresi tra 1 e 90, disposti in 3 righe di 5 numeri, rispettando la seguente regola:
• una riga non può contenere due numeri della stessa “decina”; ad esempio, una riga pu`o contenere 9
e 11, ma non 11 e 13.
Il metodo segna accetta il prossimo numero estratto, e controlla se questa cartella ha ottenuto un premio,
restituendo null, oppure un valore enumerato che rappresenta uno dei premi della Tombola: AMBO,
TERNO, QUATERNA, CINQUINA, TOMBOLA (implementare anche questa enumerazione).
L’implementazione deve rispettare il seguente esempio d’uso:

Esempio d’uso:
Cartella c = new Cartella();
System.out.println(c.segna(1));
System.out.println(c.segna(2));
System.out.println(c.segna(12));
System.out.println(c.segna(22));
System.out.println(c.segna(82));

Un output possibile:
null
null
null
AMBO
null
 */
package esame.pkg17.pkg20.pkg07;
import java.util.*;



class A {
   public String f(Object x, A y,A z) { return "A1"; }
   private String f(A x, B y, B z) { return "A2"; }
}
class B extends A {
    public String f(Object x, A y, A z) { return "B1 + " + f(null, new B(), new C());}
    private String f(B x,B y,C z) { return "B2"; }
    
}
class C extends B {
   public String f(A x, B y, B z) { return "C1 + "+f(this,this,z);}
   public String f(B x, B y, B z) { return "C2"; }
 
  
}


class Cartella{
    private int[][] Mat;            
    private int conta=0; 
    
   public Cartella(){
       Mat=new int[3][5];            //Creo una matrice 3x5
       Riempi(); 
   }
   
   public void Riempi(){
       int random;    // = (int)(Math.random()*90+1);            //numeri compresi da 1 a 90
       int n=9;
       int a=1;
       
       
       for(int i=0;i<3;i++){
           for(int j=0;j<5;j++){
              //  System.out.println("n="+n+" a="+a);
               random=(int)(Math.random()*n+a);           //da 1 a 9, poi da 10 a 19, poi da 20 a 29...
            //    System.out.println(random);
               Mat[i][j]=random;
               a=n+1;
               n=n+10;             
           }
           n=9; a=1;
       }
       
       System.out.println("STAMPA Matrice");
         for(int i=0;i<3;i++){
              for(int j=0;j<5;j++){
                 System.out.print(Mat[i][j]+" ");
              }
              System.out.println("");
         }
   }
    
    public enum premi{
        AMBO,TERNO,QUATERNA, CINQUINA, TOMBOLA;
    }
    
    public premi segna(int n){
          System.out.print("Viene estratto : "+n+" , ");
        int flag=0;
        
        for(int i=0;i<3;i++){
           for(int j=0;j<5;j++){
               
              if(Mat[i][j]==n){
                  conta++;
                  flag=1;}

           }
        }
        
        if(conta<2&&flag==1)
           return null;
       else if(conta<3&&flag==1)
           return premi.AMBO;
       else if(conta<4&&flag==1)
          return premi.TERNO;
       else if(conta<5&&flag==1)
           return premi.CINQUINA;
       else if(flag==1)
           return premi.TOMBOLA;
       else return null;
    }
}


/*
Implementare un metodo statico commonKeys, che accetta due mappe, e restituisce l’insieme
degli oggetti che compaiono come chiavi in entrambe le mappe.
Inoltre, valutare ciascuna delle seguenti intestazioni in base ai criteri di funzionalità, completezza,
correttezza, fornitura di ulteriori garanzie, semplicità e specificità del tipo di ritorno. Infine,
scegliere l’intestazione migliore oppure proporne un’altra.
a) <T> Set<T> commonKeys(Map<T,?> m1, Map<T,?> m2)
b) <T,V1,V2> Set<T> commonKeys(Map<T,V1> m1, Map<T,V2> m2)
c) Set<Object> commonKeys(Map<?,?> m1, Map<?,?> m2)
d) <T> Set<? extends T> commonKeys(Map<? extends T,?> m1, Map<? extends T,?> m2)
e) <T> Set<?> commonKeys(Map<T,?> m1, Map<?,?> m2)
*/
class Prova{
    
    public static <T> Set<?> commonKeys(Map<T,?> m1, Map<?,?> m2){
    
        Set<Object> S=new HashSet();
        for(Object t:m1.keySet())
          if(m2.keySet().contains(t))
               S.add(t);
        
        return S;
    }
    
}
//PRE CONDIZIONE: Accetta due mappe tali che le chiavi di entrambe possano essere confrontate
//a)FUNZIONALE. COMPLETA. CORRETTA. Non ulteriori garanzie, sarà possibile aggiungere le chiavi. SEMPLICE. SPECIFICA
//b)FUNZIONALE. COMPLETA. CORRETTA. NON ulteriori garanzie. NON SEMPLICE. SPECIFICA.
//c)FUNZIONALE. COMPLETA. NON CORRETTA, è possibile avere due mappe con chiavi differenti(String e Integer). Ulteriori garanzie. SEMPLICE. NON SPECIFICA.
//d)NON FUNZIONALE, anche se S e le keys fossero Object non potrei restituire S, dato che Object
   //non può essere convertito in <? extends T>. Posso subito capire che non è funzionale quando creo S di tipo Set<Object>
   //NON CORRETTA, infatti se T fosse Object allora le mappe potrebbero avere qualsiasi cosa come chiavi, anche tipi incompatibili. COMPLETA.
//e)FUNZIONALE. COMPLETA. NON CORRETTA, posso confrontare key di tipi incompatibili. NON U.G. SEMPLICE. NON SPECIFICA.
//La migliore è senza dubbio la a)
//CORRETTA UFFICIALMENTE

public class Esame172007 {
    public static void main(String[] args) {
       //Esercizio 1
      /* C gamma=new C();
       B beta=gamma;
       A alfa=gamma;
       
       System.out.println(beta.f(beta,beta,gamma));
       System.out.println(gamma.f(beta, null, beta));
       System.out.println(gamma.f(alfa, beta, gamma));
       System.out.println((Object)gamma.equals((Object)alfa));*/
       
       //Esercizio 2
        Cartella c = new Cartella();
        System.out.println(c.segna(1));
        System.out.println(c.segna(2));
        System.out.println(c.segna(12));
        System.out.println(c.segna(22));
        System.out.println(c.segna(82));
        
        
       /* class MyThread extends Thread {
           private int id;
           private Object object;
           public MyThread(int n, Object x) {
              id = n;
              object = x;
           }
            public void run() {
                try {
                   synchronized (object) {
                       System.out.println(Thread.currentThread().getName()+" il mio id è : "+id+", ho incontrato il wait");
                       object.wait();
                       System.out.println(Thread.currentThread().getName()+" il mio id è : "+id+", sto dopo il wait");
                    }
                } catch (InterruptedException e) {
                     return;
                }
              System.out.println(id);
            }
        }
        Object o1 = new Object(), o2 = new Object();
        Thread t1 = new MyThread(1,o1);
        Thread t2 = new MyThread(2,o1);
        Thread t3 = new MyThread(3,o1);
        Thread t4 = new MyThread(4,o2);
        t1. start () ; t2. start () ; t3.start () ; t4.start ();
        try { Thread.sleep(1000); } catch (InterruptedException e) { }
        System.out.println("Sono il main, ho aspettato 1 secondo");
        synchronized (o2) { o2.notifyAll();
        System.out.println("Ho svegliato i thread su o2");
        }
        synchronized (o1) { o1.notify(); 
         System.out.println("Ho svegliato i thread su o1");
        }*/
 //t1 ha id=1 e o1 come object, quindi il suo corpo è composto da id=1 e o1.  
 //t2 -> id=2 e o1;
 //t3 -> id=3 e o1;
 //t4 -> id=4 e o2;
//vengono startati tutti contemporaneamente. Intanto il main viene addormentato per 1 secondo, quindi sicuramente i 4 thread
//vanno nella run prima del main. Entrano tutti e 4 nella run e incontrano il wait, tutti quindi si stoppano.
//Il main ha aspettato un secondo e sveglia TUTTI i thread che stanno aspettando con o2 nel corpo(solo t4) e poi
//uno a caso tra t1 t2 e t3, gli altri due restano in attesa perenne a causa del wait. Ovviamente il main si, va prima nel o2.notifyAll
//e dopo su o1.notify() e infatti 4 si sveglierà sempre per primo, però poi non è detto che sia il primo ad arrivare al System.out.println(id);
//ecco perchè alcune volte viene stampato per secondo.
//Output possibili : (4 1) (4 2) (4 3) (1 4) (2 4) (3 4)
    
    }
    
}
