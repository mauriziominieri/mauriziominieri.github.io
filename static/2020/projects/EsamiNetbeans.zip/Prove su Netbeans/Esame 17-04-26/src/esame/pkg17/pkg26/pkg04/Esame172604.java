package esame.pkg17.pkg26.pkg04;
import java.util.*;



class A {
  public String f(Object x, A y,A z) { return "A1"; }
  private String f(B x, C y, B z) { return "A2"; }
}
class B extends A {
    public String f(Object x, A y, B z) { return "B1"+" "+f(null,new B(),z);}
    public String f(A x,B y,C z) { return "B2"; }
    
}
class C extends B {
   public String f(Object x, A y, B z) { return "C1"+" "+f(this,this,z);}
   public String f(B x, C y, B z) { return "C2"; }
  
}

/* ESERCIZIO 3
Ipotizzando la disponibilità delle classi Person, Employee e Manager, ciascuna sottoclasse della
precedente, realizzare la classe Container in modo che il seguente frammento sia corretto:
Container<Employee> cont1 = new <String>Container<Employee>("ciao");
Container<Employee> cont2 = new <Integer>Container<Employee>(new Integer(42));
Container<Manager> cont3 = new <Integer>Container<Manager>(new Integer(42));
e ciascuna delle seguenti istruzioni provochi un errore di compilazione:
Container<Employee> cont4 = new <Object>Container<Employee>(new Object());
Container<Person> cont5 = new <Integer>Container<Person>(new Integer(42));
*/
class Person{
    
}
class Employee extends Person{
    
}
class Manager extends Employee{
    
}

class Container<T>{
    
    public Container(Object o){
        System.out.println("o : "+o.getClass());
        System.out.println("T : "+this.);             //NON SO FARLO, NON HO CAPITO
        genera(o);
    }
    
    public Object genera(Object o){
        if(o.getClass()==String.class){
            String r=(String)o;
            return r;
        }
        else if(o.getClass()==Integer.class){
            Integer r=(Integer)o;
            return r;
        }
        else
            return o;
    }
}









        


/* ESERCIZIO 2
Realizzare le classi Room e Reservation, che rappresentano una camera d’albergo e una prenotazione per la camera. 
Il metodo reserve di Room accetta un nome, la data di inizio e di ﬁne prenotazione, e restituisce un oggetto di tipo Reservation. 
Se la camera è occupata in una delle giornate richieste, il metodo lancia un’eccezione. 
Per semplicità, una data è rappresentata da un numero intero tra 0 a 365. 
Il metodo reservations di Room consente di scorrere l’elenco delle prenotazioni, in ordine cronologico. 
L’implementazione deve rispettare il seguente esempio d’uso.

Esempio d’uso: 
Room r = new Room(); 
Reservation p1 = r.reserve("Pasquale␣Caﬁero", 105, 120); 
Reservation p2 = r.reserve("Carlo␣Martello", 5, 20); 
Reservation p3 = r.reserve("Piero", 20, 22); 
Reservation p4 = r.reserve("Marinella", 200, 222);
for (Reservation p: r.reservations()) 
   System.out.println(p.getName());

Output:
Carlo Martello Piero Pasquale Cafiero Marinella

 */



class Room{
    public static ArrayList<Reservation> A;
    
    public Room(){
        A=new ArrayList();
    }
    
     public boolean isFree(int inizio,int fine){
        
        for(Reservation r: A){
           // System.out.println("r.inizio="+r.inizio+" r.fine"+r.fine);
           //  System.out.println("inizio="+inizio+" fine"+fine);
            if((inizio<r.getInizio()&&inizio>r.getFine())&&fine>r.getInizio())        //la fine è contenuta nell'intervallo di un altro cliente
                return false;
            if((inizio>r.getInizio()&&inizio<r.getFine())&&fine>r.getFine())          //l'inizio è contenuto nell'intervallo di un altro cliente
                return false;
            if(inizio<r.getInizio()&&fine>r.getFine())          //l'intervallo del cliente appena arrivato include quello di un altro
                return false;
            if(inizio>r.getInizio()&&fine<r.getFine())          //l'intervallo del cliente appena arrivato è incluso in quello di un altro
                return false;
        }
        return true;
    }
     
    public boolean isValid(int inizio,int fine){
        if(inizio<0||fine<0||fine<inizio||fine>365||inizio>=365) 
            return false;
    
        return true;
    }
    
    
    
    public Reservation reserve(String nome, int inizio,int fine) throws RuntimeException{
       
        if(!isValid(inizio,fine))
           throw new RuntimeException("Data non valida");
        
        if(!isFree(inizio,fine))
           throw new RuntimeException("Camera occupata");
        

        Reservation r=new Reservation(nome,inizio,fine);
        A.add(r);
        return r;
    }
    
     public ArrayList<Reservation> reservations(){
      Collections.sort(A,new Comparator<Reservation>(){
             public int compare(Reservation a,Reservation b){          //Ordina dal giorno minore al giorno maggiore
                 if(a.getInizio()>b.getInizio()) return 1;
                 else if(a.getInizio()<b.getInizio()) return -1;
                 else return 0;
             }      
        });
      
      return A;
    }
    
   
}

class Reservation{
    private String nome;
    private int inizio;
    private int fine;
    public Reservation(String n,int i,int f){
        nome=n;
        inizio=i;
        fine=f;
    }
    
    public String getName(){
        return nome;
    }
    public int getInizio(){
        return inizio;
    }
    public int getFine(){
        return fine;
    }
}


public class Esame172604 {
    public static void main(String[] args) {
        
       /*C gamma=new C();
       B beta=gamma;
       A alfa=gamma;
       
      // System.out.println(alfa.f(alfa,beta,gamma));                                PRIMO ESERCIZIO
      // System.out.println(gamma.f(beta,beta,beta));
      // System.out.println(gamma.f(beta,beta,null));
      // System.out.println(128&127);*/
       
       
       
       
       
      /* Room r=new Room();
       Reservation p1=r.reserve("Pasquale Cafiero",105,120);
       Reservation p2=r.reserve("Carlo Martello",5,20);
       Reservation p3=r.reserve("Piero",20,22);
       Reservation p4=r.reserve("Marinella",200,212);
         
         
       for(Reservation p: r.reservations())           //Già capisco che reservations() deve restituire l'array Ordinato in ordine cronologico
           System.out.println(p.getName());*/
       
       
       //Esercizio 3
        Container<Employee> cont1 = new <String>Container<Employee>("ciao"); //System.out.println("cont1 : "+cont1.getClass());
        Container<Employee> cont2 = new <Integer>Container<Employee>(new Integer(42));
        Container<Manager> cont3 = new <Integer>Container<Manager>(new Integer(42));
        //e ciascuna delle seguenti istruzioni provochi un errore di compilazione:
        Container<Employee> cont4 = new <Object>Container<Employee>(new Object());
        Container<Person> cont5 = new <Integer>Container<Person>(new Integer(42));
       
    }
    
}

