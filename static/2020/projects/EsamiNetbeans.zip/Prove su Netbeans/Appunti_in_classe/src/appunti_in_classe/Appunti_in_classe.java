/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package appunti_in_classe;
import java.util.*;

/*class A{
   public String f(double u,A x) {return "A1";}
   public String f(double u,B x) {return "A2";}
   public String f(int u,Object x) {return "A3";}
}

class B extends A{
   public String f(double u,B x) {return "B1";}
   public String f(float u,Object x) {return "B2";}
  
}

class C extends A{
   public String f(int u,Object x) {return "C1";}
}*/

class Motorino{
    private String colore;
    public float velocità;
    private String tipo;
    public boolean antifurto=false;
     
     public Motorino(String colore,String tipo,float velocità){
         this.colore=colore;
         this.tipo=tipo;
         this.velocità=velocità;
     }
     
     public float getVelocità(){
         return velocità;
     }
     
     public void accelera(float numero){
         if(antifurto==false)
             velocità=velocità+numero;
     }
     
     public void inserisciAntifurto(){
         antifurto=true;
     }
}

class MotorinoImmatricolato extends Motorino{
    private float maxVelocità;
    private String targa;
    
    public MotorinoImmatricolato(String colore, String tipo, float velocità,String targa,float maxVelocità) {
        super(colore, tipo, velocità);
        this.targa=targa;
        this.maxVelocità=maxVelocità;
    }
    
    public void getMax(){
        System.out.println(maxVelocità);
    }
    
    public void accelera(float numero){
        float s=numero+velocità;
        
        if(antifurto==false){
            if(s<maxVelocità)
                velocità=s;
            else
                velocità=maxVelocità;
        }
    }
    
}


class Dipendente{
    String matricola;
    float stipendio;
    float straordinario;
    
    public Dipendente(String matricola,float stipendio,float straordinario){
        this.matricola=matricola;
        this.stipendio=stipendio;
        this.straordinario=straordinario;
    }
    
    public float getStipendio(){
        return stipendio;
    }
    
    public float paga(int ore){
        return stipendio+(ore*straordinario);
    }
    
    public void stampa(){
        System.out.println("matricola: "+matricola);
          System.out.println("stipendio: "+stipendio);
            System.out.println("straordinario: "+straordinario);
    }
}

class DipendenteA extends Dipendente{
    int malattia=0;
    
    public DipendenteA(String matricola,float stipendio,float straordinario){
        super(matricola,stipendio,straordinario);
    }
    public void prendiMalattia(int giorni ){
        malattia=malattia+giorni;
    }
    
    public float paga(int ore){
        float p=super.paga(ore);
        if(malattia==0)
            return p;
        else
            return (float) (p-(malattia*15.0));
    }
    
    public void stampaMalattia(){
        System.out.println(malattia);
    }
}



public class Appunti_in_classe {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       /* C gamma=new C();
       B beta = new B();
       A alfa = beta;
       
       //  System.out.println(alfa.f(3,beta));       //errore di compilazione
       
       System.out.println(alfa.f(3.0,beta));       //alfa.f(double,B) firme candidate A1 e A2, A2 più specifica 
                                                   //Output: Ricorda di considerare il tipo effettivo tramite il late binding. Il tipo effettivo di A è B
                                                     //dato che alfa=beta, quindi cerco in B una firma con (double,B), cioè B1. OUTPUT=B1
                                                     
      //  System.out.println(beta.f(3.0,alfa));     //beta.f(double,A) l'unica firma candidata è A1  
       
       // System.out.println(gamma.f(3,gamma));*/
       
       
       
      /* Motorino m=new Motorino("grigio","Piaggio",(float)40.5);
       float var=m.getVelocità();
       MotorinoImmatricolato mi=new MotorinoImmatricolato("rosso","Aprilia",(float)30.5,"CV1234",60.0f);
       mi.getMax();
       m.accelera((float)30.7);
       mi.accelera((float)30.7);
       System.out.println(m.getVelocità());
       System.out.println(mi.getVelocità());*/
       
       Dipendente d;
        d = new Dipendente("00309",10000.0f,7.5f);
       
        d.paga(10);
        System.out.println(d.getStipendio());
        
        DipendenteA da=new DipendenteA("00201",1500.0f,8.50f);
        da.prendiMalattia(5);
        da.paga(3);
        da.stampaMalattia();
       
    }
    
}
