package esame.pkg16.pkg20.pkg09;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

class A {
    public String f(A x, A[] y) { return "A1"; }
    public String f(A x, Object y) { return "A2:" + x.f(new C(), y); }
}
class B extends A {
    public String f(B x, A[] y) { return "B1:" + f((A)x, y); }
    public String f(A x, B[] y) { return "B2"; }
}
class C extends B {
    public String f(A x, A[] y) { return "C1"; }
}


/*
Per un social network, implementare le classi SocialUser e Post. Un utente è dotato di un nome
e può creare dei post tramite il metodo newPost. Il contenuto di un post è una stringa, che
può contenere nomi di utenti, preceduti dal simbolo “@”. Il metodo getTagged della classe Post
restituisce l’insieme degli utenti il cui nome compare in quel post, mentre il metodo getAuthor
restituisce l’autore del post.
L’implementazione deve rispettare il seguente esempio d’uso.
Esempio d’uso:
SocialUser adriana = new SocialUser("Adriana"), barbara = new SocialUser("Barbara");
SocialUser.Post p = adriana.newPost("Ecco una foto con @Barbara e @Carla.");
Set<SocialUser> tagged = p.getTagged();
System.out.println(tagged);
System.out.println(tagged. iterator () .next() == barbara);
System.out.println(p.getAuthor());
Output:
[Barbara]
true
Adriana
Suggerimento: l’invocazione a.lastIndexOf(b) restituisce -1 se la stringa b non è presente nella
stringa a, e un numero maggiore o uguale di zero altrimenti.
*/

class SocialUser{
    
    private String nome;
    private static ArrayList<SocialUser> setUsers=new ArrayList();  //Qui metto tutti gli User, cioè adriana e barbara, 
                    //essendo un oggetto statico ovviamente resterà lo stesso, indipendentemente dagli oggetti che istanzierò 
                   //cioè quando vado a creare adriana e barbara, andrò a creare due oggetti che avranno un nome diverso, ma setUsers è il medesimo per entrambi
                                    
    public SocialUser(String n){
        nome=n;
        setUsers.add(this);
    }
    
    public Post newPost(String s){
        Post p=new Post(s,this);    //quando creo un post gli passo il contenuto è l'oggetto che chiama il post, cioè l'autore, adriana.
        return p;
    }
    
    public String toString(){
        return nome;
    }
    
    class Post{                     //quindi il post avrà contenuto e autore appena creato.
        private String contenuto;          
        private SocialUser autore;
        
        public Post(String c,SocialUser u){
            contenuto=c;
            autore=u;
        }
        
        public Set<SocialUser> getTagged(){  //vado a confrontare tutti gli user con il contenuto del post, se il contenuto contiene (@nome di qualche user) allora lo aggiungo
                                                  //in set. Quindi faccio : "Ecco una foto con @Barbara e @Carla." contiene "@adriana"?, contiene "@barbara"?
            Set<SocialUser> set=new HashSet();
           
            for(int i=0;i<setUsers.size();i++)
               //if(contenuto.contains("@"+setUsers.get(i).nome+" "))                //cosi uso pure il suggerimento
               if(contenuto.lastIndexOf("@"+setUsers.get(i).nome+" ")>=0)    //cioè: se "contenuto" contains "@getUsers.get(i).nome "
                      set.add(setUsers.get(i));
                
            return set;
        }
        
        public SocialUser getAuthor(){
            return autore;
        }
    }
}



/*
Il seguente thread accede ad un array di interi, precedentemente istanziato.
class MyThread extends Thread {
public void run() {
        _____1_____
    for (int i=0; i<array.length; i++) {
        _____2_____
        array[i]++;
        _____3_____
        }
        _____4_____
    }
}
Un programma avvia due thread di tipo MyThread, con l’obiettivo di incrementare ogni elemento
dell’array di 2. Dire quali dei seguenti inserimenti rendono il programma corretto ed esente da
race condition (è possibile indicare più risposte):
(a) 1 = “synchronized (this){” 4 = “}”
(b) 1 = “synchronized {” 4 = “}”
(c) 1 = “synchronized (array){” 4 = “}”
(d) 2 = “synchronized (this){” 3 = “}”
(e) 2 = “synchronized (array){” 3 = “}”
(f) 2 = “array.wait();” 3 = “array. notify () ;”
*/
//a) so che synchronized(this) non sincronizza nulla, quindi sicuramente è sbagliata
//b) sbagliata la sintassi
//c) si, usare il blocco synchronized su un oggetto che usano entrambi assicura una classe ThreadSafe, cioè i thread sincronizzati.
//d) sta il this quindi ciaao
//e) non funziona, i due thread potranno accedere al for contemporaneamente e quindi creare casini 
//f) sbagliata la sintassi, il wait e il notify vanno in un blocco sincronizzato
//spouriuos wakeup : un thread che incontra wait() e viene risvegliato a caso dal sistema operativo.


public class Esame162009 {
    private static int[] array=new int[4];
    
    static class MyThread extends Thread {
      
        
    public void run() {
        synchronized(array){
        for (int i=0; i<array.length; i++) {
                System.out.println(Thread.currentThread().getName());
                array[i]++;
        }  
        }
    }
}
    
    public static void main(String[] args) {
        //Esercizio 1
        /*C gamma = new C();
        B beta = gamma;
        A[] array = new A[10];
        System.out.println(beta.f (beta, array));
        System.out.println(gamma.f(beta, null));  //Non si può definire chi sia la più specifica (B1 o B2, le candidate sono C1,B1,B2,A1,A2
*/
        //Esercizio 2
        SocialUser adriana = new SocialUser("Adriana"), barbara = new SocialUser("Barbara");
        SocialUser.Post p = adriana.newPost("Ecco una foto con @Barbara e @Carla.");
        Set<SocialUser> tagged = p.getTagged();
        System.out.println(tagged);
        System.out.println(tagged.iterator().next()==barbara);
        System.out.println(p.getAuthor());
        
        
       /* array[0]=0;
         array[1]=5;
          array[2]=2;
           array[3]=1;
           
        MyThread t1=new MyThread();
        MyThread t2=new MyThread();
        t1.start(); t2.start();
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            
        }
        for(int i=0;i<4;i++)
        System.out.println("array : "+array[i]);*/
     
    }
    
}
