package esame.pkg18.pkg01.pkg24;
import java.util.*;

/*
 Realizzare la classe Bug, che rappresenta un errore in un programma. Il costruttore accetta una descrizione
dell’errore. Inizialmente, l’errore non `e assegnato ad alcuno sviluppatore. Il metodo assignTo assegna
l’errore ad uno sviluppatore, identificato dal nome, che sar`a incaricato di risolvere l’errore.
Il metodo statico getUnassigned restituisce in tempo costante l’insieme degli errori non ancora assegnati.
Il metodo statico getAssignedTo restituisce in tempo costante l’insieme degli errori assegnati ad uno
sviluppatore dato.
Nota: un bug assegnato ad uno sviluppatore pu`o essere riassegnato ad un altro.
L’implementazione deve rispettare il seguente esempio d’uso:

Esempio d’uso:
Bug b1 = new Bug("Application crashes on Windows 8"),
b2 = new Bug("Application freezes after 2 hours"),
b3 = new Bug("Application does not print on laser printer"),
b4 = new Bug("Data missing after partial save");
Set<Bug> unassigned = Bug.getUnassigned();
System.out.println(unassigned.size ());
b2.assignTo("Paolo");
b3.assignTo("Filomena");
b4.assignTo("Filomena");
System.out.println(unassigned.size ());
Set<Bug> filo = Bug.getAssignedTo("Filomena");
System.out.println( filo );

Output:
4
1
[("Data missing after partial save", assigned to Filomena), ("Application does not print on laser printer", assigned to Filomena)]

 */

class Bug implements Comparable<Bug>{
    private String descrizione;
    private static String nome;
    private static HashMap<String,Set<Bug>> M=new HashMap();;
    private static TreeSet<Bug> set_unassigned=new TreeSet<Bug>();    //treeset perchè cosi posso ordinare il set come voglio io

    public Bug(String d){
        descrizione=d;
        set_unassigned.add(this);
    }

    public void assignTo(String nome){

        Set<Bug> set=M.get(nome);
        nome=n;
        if(set==null){
            set=new HashSet();
            set.add(this);
          //  System.out.println("set : "+set);
            M.put(nome,set);
        }
        else{

            set.add(this);
         //   System.out.println("set2 : "+set);
        }

        set_unassigned.remove(this);
    }

    public static Set<Bug> getUnassigned(){
       return set_unassigned;
    }

    public static Set<Bug> getAssignedTo(String n){
        return M.get(n);
    }

    public String toString(){
        return "(\""+descrizione+"\", assigned to "+nome+")";
    }

    public int compareTo(Bug b){          //Per il treeset
        if(descrizione.compareTo(b.descrizione)>0) return 1;
        else if(descrizione.compareTo(b.descrizione)<0) return -1;
         else return 0;
    }
}

/*
Il metodo statico isIncreasing accetta una mappa e un comparatore, e restituisce vero se e solo se
ciascuna chiave è minore o uguale del valore ad essa associato.
Valutare ciascuna delle seguenti intestazioni in base ai criteri di funzionalità, completezza, correttezza,
fornitura di ulteriori garanzie, e semplicità. Infine, scegliere l’intestazione migliore oppure
proporne un’altra.
a) <K,V> boolean isIncreasing(Map<K,V> m, Comparator<K> c)
b) <K,V> boolean isIncreasing(Map<K,V> m, Comparator<? super K> c)
c) <K,V extends K> boolean isIncreasing(Map<K,V> m, Comparator<? super K> c)
d) <T> boolean isIncreasing(Map<T,T> m, Comparator<T> c)
e) <T> boolean isIncreasing(Map<T,T> m, Comparator<? extends T> c)
f) <T> boolean isIncreasing(Map<? extends T, ? extends T> m, Comparator<T> c)
g) boolean isIncreasing(Map<?,?> m, Comparator<?> c)
*/
class Prova{

    public static boolean isIncreasing(Map<Integer,Integer> m,Comparator<Integer> c){
         int conta=0;
        // m.put(3,2);
        c=new Comparator(){

             public int compare(Object o, Object o1) {
                 Integer t=(Integer)o;
                 Integer t1=(Integer)o1;
                 if(t>t1) return 1;
                 else if(t<t1) return -1;
                 else return 0;
             }
         };


      //Devo prendere la chiave e il valore ad essa associato, e vedere se è minore in base al comparatore
       for(Integer i: m.keySet()){
           if(c.compare(i,m.get(i))==1 || c.compare(i,m.get(i))==0)
               conta++;
       }

       if(conta==m.size())
           return true;
       return false;
    }
}
//a) Funzionale. Completa. Non corretta, perchè permette di confrontare String e Integer, che non sono valori confrontabili.
//Non ult gar. Non semplice. Specifica.
//b) Funzionale. Completa. Non Corretta. ..bo
//c) Funzionale. Non completa. Non corretta.
//d) Funzionale. Non completa. Corretta. Semplice. Non ult gar. Specifica.
//e) Non funzionale. Se T fosse Integer allora avrei Integer cant be converted in <?>
//f) Funzionale. Non completa. Corretta.
//g) Non Funzionale. Object cant be converted in <?>



//Esercizio 3
/*
Implementare la classe SharedTotal, che permette a diversi thread di comunicare un valore numerico
(double) e poi ricevere la somma di tutti i valori inviati dai diversi thread. Precisamente, il
costruttore accetta come argomento un timeout in millisecondi. Il metodo sendValAndReceiveTot
accetta come argomento il valore indicato dal thread corrente, mette il thread corrente in attesa
fino allo scadere del timeout, e infine restituisce il totale di tutti i valori inviati.
Se un thread ha già chiamato sendValAndReceiveTot una volta, al secondo tentativo viene sollevata
un’eccezione.
È necessario evitare race condition.
*/
class SharedTotal extends Thread{      //    Chissà
    private long timeout;
    private static double tot=0;
    private boolean flag=false;

    public SharedTotal(long t){
        timeout=t;
    }

    public double sendValAndReceiveTot(double n) throws InterruptedException{
        if(flag==false)
           flag=true;
        else{
            throw new InterruptedException("sendValAndReceiveTot già chiamata da "+Thread.currentThread().getName());
        }

        try{
            tot=tot+n;
            Thread.sleep(timeout);
        }catch(InterruptedException e){
            e.printStackTrace();
        }

         return tot;
    }

    public void run(){
        try{
       sendValAndReceiveTot(timeout);}catch(InterruptedException e){}
    }
}


public class Esame180124 {
    public static void main(String[] args) {

        /*Bug b1 = new Bug("Application crashes on Windows 8"),
        b2 = new Bug("Application freezes after 2 hours"),
        b3 = new Bug("Application does not print on laser printer"),
        b4 = new Bug("Data missing after partial save");
        Set<Bug> unassigned = Bug.getUnassigned();
        System.out.println(unassigned.size());
        b2.assignTo("Paolo");
        b3.assignTo("Filomena");
        b4.assignTo("Filomena");

        System.out.println(unassigned.size());
        Set<Bug> filo = Bug.getAssignedTo("Filomena");
        System.out.println(filo);
        Set<Bug> paolo = Bug.getAssignedTo("Paolo");
        System.out.println(paolo);*/

        //Esercizio 2
       /* Map<Integer,Integer> M=new HashMap();
        M.put(4,2);
        M.put(5,3);

        Comparator c=null;

        System.out.println( Prova.isIncreasing(M,c));*/

        //Esercizio 3
        SharedTotal tot = new SharedTotal(1000);
        SharedTotal tot2 = new SharedTotal(1002);
        SharedTotal tot3 = new SharedTotal(1002);
        tot2.start();
        tot3.start();
       try{
        System.out.println(tot.sendValAndReceiveTot(5.0));
       }
       catch(InterruptedException e){
           e.printStackTrace();
       }


    }

}
