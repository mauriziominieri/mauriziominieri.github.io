/*
 La classe City rappresenta una città. Il costruttore accetta il nome della città, mentre il metodo
connect accetta un’altra città e stabilisce un collegamento tra le due (una strada o un altro tipo
di collegamento). Tutti i collegamenti sono bidirezionali.
Il metodo getConnections restituisce la collezione delle città direttamente collegate a questa. Il
metodo isConnected prende come argomento un’altra città e restituisce vero se è collegata a this
direttamente o indirettamente (cioè, tramite un numero arbitrario di collegamenti).
 */
package esame.pkg13.pkg29.pkg04;
import java.util.*;


class A{
       
       protected static Map<City,Set<City>> Map=new HashMap<>();
      
       public static void put(City città){
           Map.put(città,null);
       }
       
       public void Stampa(){
           // for(City c: Map.keySet())
               System.out.println(Map);
    }  
}

class City{
    String nome;
    
    public City(String nome){
        this.nome=nome;
        A.put(this);
    }
    
    public void connect(City città){                         //Collegamenti bidirezionali     
        
         Set<City> cella1=A.Map.get(this);
         Set<City> cella2=A.Map.get(città);                  //al posto di this metterò città
         
         if(cella1==null){
             cella1=new HashSet<>();
             cella1.add(città);
             A.Map.put(this,cella1);
            
         }
         else
             cella1.add(città);
         
         
         if(cella2==null){                           //this e città invertiti
             cella2=new HashSet<>();
             cella2.add(this);
             A.Map.put(città,cella2);
         }
         else
             cella2.add(this);
   
    }
    
    public Collection<City> getConnections(){
        
        return A.Map.get(this);
    }
    
    
    
    public boolean isConnected(City città){          //devo vedere se    città=salerno   è collegata a      this=roma
       
       /*for(City i: A.Map.keySet()){
           System.out.print("i="+i+" ");
        // for(Set<City> c: A.Map.get(i))
             System.out.println(A.Map.get(i));
       }*/
       
      //   System.out.println(A.Map.get(città));
      
     if(A.Map.get(città)!=null){                               
       for(City c: A.Map.get(città)){                         //scorrerò tutte le città 
         
          if(A.Map.get(c).contains(this) || c==this){             
              return true;
          }
       }
     }
  
         return false;
    }
    
    public String toString(){
        return nome;
    }
    
   
}

public class Esame132904 {
    public static void main(String[] args) {
        
        
        City n = new City("Napoli"), r = new City("Roma"), s = new City("Salerno"), p = new City("Parigi");
        
        n.connect(s);
        n.connect(r);
        
        Collection<City> r_conn = r.getConnections();
        System.out.println(r_conn);
        System.out.println(r.isConnected(n));
        System.out.println(r.isConnected(p));
    }
    
}
