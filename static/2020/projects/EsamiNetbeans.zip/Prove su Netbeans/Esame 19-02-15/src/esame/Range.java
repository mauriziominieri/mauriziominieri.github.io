package esame;

public class Range <T> {
	
	private T minimo;
	private T massimo;
	
	public Range (T min, T max) {
		minimo = min;
		massimo = max;
	}
	
	public Boolean isInside(T x) {
		
		if (x instanceof Number) {
			if(Double.parseDouble(x.toString()) >= Double.parseDouble(minimo.toString()) && Double.parseDouble(x.toString()) <= Double.parseDouble(massimo.toString()))
				return true;
		}
		else if (x instanceof String) {
			if(x.toString().compareTo(minimo.toString()) >= 0 && x.toString().compareTo(massimo.toString()) <= 0)
				return true;
		}
		
		return false;
	}
	
	public Boolean isOverlapping(Range x) {
		
		if(x.minimo.toString().compareTo(this.minimo.toString()) > 0 && x.massimo.toString().compareTo(this.massimo.toString()) < 0 )
			return true;
		
		return false;
	}

}

class Esame {
	
	public static void main(String[] args) {
		
		Range<Integer> a = new Range<>(10, 20);
		System.out.println(a. isInside (10));
		System.out.println(a. isInside (50));
		Range<String> b = new Range<>("albero", "dirupo"),
		c = new Range<>("casa", "catrame");
		System.out.println(b.isOverlapping(c));
		//Range<Object> d = new Range<>(); // errore di compilazione
	}
}