/*          //Esercizio 2
Realizzare la classe DataSeries, che rappresenta una serie storica di dati numerici (ad es., la popolazione di una regione anno per anno).
Il metodo set imposta il valore della serie per un dato anno. Il metodo statico comparatorByYear accetta un anno e restituisce un comparatore
tra serie di dati che confronta il valore delle due serie per quell’anno.

Esempio d’uso: DataSeries pop1 = new DataSeries(), pop2 = new DataSeries(); 
               pop1.set(2000, 15000.0); pop1.set(2005, 18500.0); pop1.set(2010, 19000.0); pop2.set(2000, 12000.0); pop2.set(2005, 16000.0);
               pop2.set(2010, 21000.0); 
               Comparator<DataSeries> c2005 = DataSeries.comparatorByYear(2005), c2010 = DataSeries.comparatorByYear(2010); 
               System.out.println(c2005.compare(pop1, pop2)); 
               System.out.println(c2010.compare(pop1, pop2));

Output: 1 -1
 */


/*              //Esercizio 3
Realizzare la classe Relation, che rappresenta una relazione binaria tra un insieme S e un insieme T. 
In pratica, una Relation è analoga ad una Map, con la diﬀerenza che la Relation accetta chiavi duplicate. 
Il metodo put aggiunge una coppia di oggetti alla relazione. Il metodo remove rimuove una coppia di oggetti dalla relazione. 
Il metodo image accetta un oggetto x di tipo S e restituisce l’insieme degli oggetti di tipo T che sono in relazione con x. 
Il metodo preImage accetta un oggetto x di tipo T e restituisce l’insieme degli oggetti di tipo S che sono in relazione con x.

Esempio d’uso: Relation<Integer,String> r = new Relation<Integer,String>(); 
r.put(0, "a"); r.put(0, "b"); r.put(0, "c"); r.put(1, "b"); r.put(2, "c"); 
r.remove(0, "a"); 
Set<String> set0 = r.image(0); 
Set<Integer> setb = r.preImage("b"); 
System.out.println(set0); System.out.println(setb);

Output: [b, c] [0, 1]
*/

package esame.pkg15.pkg20.pkg01;
import java.util.*;




/*                   //Esercizio 1
class A {
  public String f(Object x, B y) { return "A1"; }
  public String f(A[] x, B y) { return "A2"; }
}
class B extends A {
    public String f(Object x, B y) { return "B1";}//+" + f(y, null); }
    public String f(B[] x, C y) { return "B2"; }
    
}
class C extends B {
   public String f(A[] x, A y) { return "C1+" + f(null, y); }
   public String f(B[] x, C y) { return "C2"; }
  
}

*/



                 //Esercizio 2
class DataSeries{
    private Map<Integer,Double> Map;            //dichiaro una hasmap con il campo delle chiavi intero e i valori double
    
    public DataSeries(){
        Map=new HashMap<>();                    //Creo una hashmap
    }
    
    public void set(int anno,double popolazione){
        Map.put(anno, popolazione);
    }
    
    public static Comparator<DataSeries> comparatorByYear(int anno){
        return new Comparator(){                         //ritorno un comparatore. (Sto usando l'interfaccia Comparator 
                                                      //dato che sto usando un'interfaccia dovrò fare l'override di tutti i suoi metodi
                                                      //creo la classe Comparator con il metodo della classe anonima
          
           public int compare(Object o1,Object o2){
                 DataSeries a=(DataSeries) o1;
                 DataSeries b=(DataSeries) o2;
                if(a.Map.get(anno)>b.Map.get(anno))
                    return 1;
                else if(a.Map.get(anno)<b.Map.get(anno))
                    return -1;
                else
                    return 0;
           }  
                 
        };
    }

 

}


              //esercizio 3
class Relation<T,S>{
    private HashMap<T,Set<S>> dominio;
    private HashMap<S,Set<T>> codominio;
    
    public Relation(){                           //costruttore
       dominio=new HashMap<>();
       codominio=new HashMap();
    }
    
    public void put(T x,S y){
        Set<S> set_d=dominio.get(x);                   //
        Set<T> set_s=codominio.get(y);
        
        if(set_d!=null)
            set_d.add(y);
        else
        {
            set_d=new HashSet<S>();
            set_d.add(y);
            
            dominio.put(x,set_d); 
        }
        
        if(set_s!=null)
            set_s.add(x);
        else
        {
            set_s=new HashSet<T>();
            set_s.add(x);
            
            codominio.put(y,set_s); 
        }
        
        
      System.out.println(dominio);
    }
    
    public void remove(T x,S y){              //  1,b
        Set<S> cella_d=dominio.get(x);
        Set<T> cella_s=codominio.get(y);
        
        if(cella_d!=null){
            cella_d.remove(y);
            cella_s.remove(x);
            if(cella_d.size()==0){
                dominio.remove(x);
            }
            if(cella_s.size()==0){
                codominio.remove(y);
            }
        }
        
      //  System.out.println(dominio);
    }
    
    public Set<T> preImage(S x){
        return codominio.get(x);
    }
    
    public Set<S> image(T x){
        return dominio.get(x);
    }
}


/*
Il metodo difference accetta due insiemi a e b e restituisce un nuovo insieme, che contiene gli
elementi che appartengono ad a ma non a b (cioè, la differenza insiemistica tra a e b).
Valutare ciascuna delle seguenti intestazioni in base ai criteri di funzionalità, completezza, correttezza,
fornitura di ulteriori garanzie, semplicità e specificità del tipo di ritorno. Infine, scegliere
l’intestazione migliore oppure proporne un’altra.
a) Set<?> difference(Set<?> a, Set<?> b)
b) Set<Object> difference(Set<?> a, Set<?> b)
c) Set<Object> difference(Set<String> a, Set<String> b)
d) <T> Set<T> difference(Set<T> a, Set<?> b)
e) <T> Set<T> difference(Set<? extends T> a, Set<? extends T> b)
f) <T> Set<T> difference(Set<T> a, Set<? extends T> b)
*/
//a) NON FUNZIONALE. Object non può essere convertito in <?>
//b) FUNZIONALE. COMPLETA. NON CORRETTA, possono essere confrontati tipi incompatibili. ULT GAR. SEMPLICE. NON SPECIFICA.
//c) FUNZIONALE. NON COMPLETA, accetta solo stringhe. CORRETTA. NON U.G. SEMPLICE. NON SPECIFICA.
//d) FUNZIONALE. COMPLETA. NON CORRETTA. NON ULT. GAR. SEMPLICE. SPECIFICA.
//e) FUNZIONALE. COMPLETA. NON CORRETTA. ULT. GAR. SEMPLICE. SPECIFICA.
//f) FUNZIONALE. COMPLETA. CORRETTA, SE T è object io posso confrontare object con Integer, giusto, Object con String, giusto, se fosse Integer posso confrontare. NON ULT. GAR. SEMPLICE. SPECIFICA.


public class Esame152001 {
    
    public <T> Set<T> difference(Set<Object> a, Set<? extends Object> b){
        Set<T> set= new HashSet();
        a.add("ciao");
        for(Object o:a)
            if(!b.contains(o))
                set.add(o);
        
        return set;
    }
    
    public static void main(String[] args) {
        
    /*B[] beta = new C[10];                      //Esercizio 1
    A[] alfa = beta;
    beta[0] = new C();
    //System.out.println(beta[0].f (beta,beta[3]));
    System.out.println(beta [0]. f ( alfa , beta[2]) );
    //System.out.println(beta [0]. f ( alfa , alfa [0]) );
   // System.out.println(6 & 7);*/
    
    
    DataSeries pop1 = new DataSeries(), pop2 = new DataSeries();     //Esercizio 2
    pop1.set(2000, 15000.0); 
    pop1.set(2005, 18500.0); 
    pop1.set(2010, 19000.0);
    pop2.set(2000, 12000.0); 
    pop2.set(2005, 16000.0);                                    
    pop2.set(2010, 21000.0);
    Comparator<DataSeries> c2005 = DataSeries.comparatorByYear(2005), c2010 = DataSeries.comparatorByYear(2010);
    System.out.println(c2005.compare(pop1, pop2));
    System.out.println(c2010.compare(pop1, pop2));
  
   
    
    
    
    
    
    
   /* Relation<Integer,String> r = new Relation<>();         //la classe dovrà avere due tipi in input, classe parametrica
    r.put(0, "a");
    r.put(0, "b");
    r.put(0, "c");
    r.put(1, "b");
    r.put(2, "c");                                        //Esercizio 3
    r.remove(0, "a");
    Set<String> set0 = r.image(0);
    Set<Integer> setb = r.preImage("b");
    System.out.println(set0);
    System.out.println(setb);*/

    
    
    
    }  
}





