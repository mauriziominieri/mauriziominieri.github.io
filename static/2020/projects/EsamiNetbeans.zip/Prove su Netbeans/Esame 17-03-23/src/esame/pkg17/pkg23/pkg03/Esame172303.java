/*
Realizzare la classe BinRel, che rappresenta una relazione binaria tra un insieme e se stesso. Il
metodo addPair aggiunge una coppia di oggetti alla relazione. Il metodo areRelated verifica se una
data coppia di oggetti appartiene alla relazione. Il metodo isSymmetric verifica se la relazione è
simmetrica.
L’implementazione deve rispettare il seguente caso d’uso:

Esempio d’uso:
BinRel<String> rel = new BinRel<>();
rel .addPair("a", "albero");
rel .addPair("a", "amaca");
System.out.println( rel .isSymmetric());
rel .addPair("albero", "a");
rel .addPair("amaca", "a");
System.out.println( rel.isSymmetric());
System.out.println( rel.areRelated("a", "amaca"));

Output:
false
true
true
*/
package esame.pkg17.pkg23.pkg03;
import esame.pkg17.pkg23.pkg03.Prova.AgeBonus;
import esame.pkg17.pkg23.pkg03.Prova.Employee;
import esame.pkg17.pkg23.pkg03.Prova.LowBonus;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;


class BinRel<T>{
    
    private HashMap<T,Set<T>> M;
   
    public BinRel(){
        M=new HashMap();
    }
    
    public void addPair(T key,T value){
        Set<T> set=M.get(key);
        if(set==null){
            set=new HashSet();
            set.add(value);
            M.put(key,set);
        }
        else
            set.add(value);
    }
    
    public boolean isSymmetric(){
        
        for(T key: M.keySet()){            //key sarà via via le chiavi della Map
            for(T value: M.get(key))       //value sarà via via il valore associato alla chiave(una chiave può avere più valori)
               if(M.get(value)==null||!M.get(value).contains(key)) //devo mettere se è uguale a null, altrimenti mi darebbe errore
                                                                    //quando vado a fare null.contains(key)
                   return false;
        }
        return true;
    }
    
    public boolean areRelated(T t1,T t2){
        if(M.get(t1).contains(t2))        //Controllo se nel set associato alla chiave t1, nel nostro esempio "a", c'è "amaca".
            return true;
        else 
            return false;
    }
}

/*
I seguenti thread accedono ad una lista di Employee, precedentemente istanziata. Gli oggetti
Employee hanno un campo salario (salary) e un campo anzianità in servizio (years). Il primo
thread assegna un bonus di 150 agli impiegati in servizio da più di 10 anni. Il secondo thread
assegna un bonus di 200 agli impiegati che hanno un salario inferiore a 1500.

class AgeBonus extends Thread {
public void run() {
_____1_____
for (Employee e: list ) {
_____2_____
if (e.getYears()>10)
e. setSalary(e.getSalary()+150);
_____3_____
}
_____4_____
}
}

class LowBonus extends Thread {
public void run() {
_____1_____
for (Employee e: list ) {
_____2_____
if (e.getSalary()<1500)
e. setSalary(e.getSalary()+200);
_____3_____
}
_____4_____
}
}

Se un programma avvia questi due thread, dire quali dei seguenti inserimenti rendono il programma
corretto ed esente da race condition (è possibile indicare più risposte, intese come alternative).
Inoltre, se si sceglie più di una risposta, commentare sinteticamente la performance che si
otterrebbe con ciascuna di esse.
(a) 1 = "synchronized (this){" 4 = "}"
(b) 1 = “synchronized {” 4 = “}”
(c) 1 = “synchronized (list){” 4 = “}”
(d) 2 = “synchronized (this){” 3 = “}”
(e) 2 = “synchronized (list){” 3 = “}”
(f) 2 = “synchronized (e){” 3 = “}”
(g) 2 = “ list .wait();” 3 = “ list . notify () ;”
(h) 1 = “synchronized {” 2 = “ list .wait();” 3 = “ list . notify () ;” 4 = “}”

RACE CONDITION= in un sistema basato su processi multipli, il risultato finale dell'esecuzione 
                dei processi dipende dalla temporizzazione o dalla sequenza con cui vengono eseguiti.
Per evitare il verificarsi di queste condizioni sono stati studiati diversi algoritmi che prevedono la mutua esclusione,
ovvero, assicurarsi che, se la risorsa condivisa è occupata da un processo, durante quell'arco di tempo nessun altro processo potrà accedervi.
Se più processi hanno la possibilità di accedere ad una risorsa in modalità di scrittura, 
è importante prevedere l'utilizzo di questi algoritmi. Se invece questi processi condividono la risorsa unicamente 
in modalità lettura non ci saranno race condition perché i processi non potranno influenzare lo stato della risorsa.
*/

class Prova{
    
    public static List<Employee> list=new ArrayList();

    static class Employee{

        private double salary;
        private int years;

        public Employee(double s,int y){
            salary=s;
            years=y;
            list.add(this);
        }

        public double getSalary(){
            return salary;
        }

        public void setSalary(double s){
            salary=s;
        }

        public int getYears(){
            return years;
        }
        
        public String toString(){
            return "(salario:"+salary+" anni:"+years+")";
        }
    }

    static class AgeBonus extends Thread {
     
        public void run() {
     
               synchronized (list){
                   
                     System.out.println("SONO "+Thread.currentThread().getName());
            for (Employee e: list) {
               
                     System.out.println("SONO "+Thread.currentThread().getName());
    
                if (e.getYears()>10)
                   e.setSalary(e.getSalary()+150);
                  
            }
            }
          
        }
    }

    static class LowBonus extends Thread {
        
        public void run() {
    synchronized (list){
          System.out.println("SONO "+Thread.currentThread().getName());
            for (Employee e: list ) {
             
                 System.out.println("SONO "+Thread.currentThread().getName());
               
                if (e.getSalary()<1500)
                   e. setSalary(e.getSalary()+200);
                
            }
          }
        }
    }
}

//a) GIUSTA
//b) sbagliata proprio la sintassi
//c) GIUSTA, è l'unica che evita race condition, cioè fa lavorare un thread alla volta,non contemporaneamente. 
//d) GIUSTA
//e) GIUSTA
//f) GIUSTA
//g) Sbagliata
//h) sbagliata proprio di sintassi

public class Esame172303 {
    public static void main(String[] args) {
       
        /*BinRel<String> rel = new BinRel<>();
        rel .addPair("a", "albero");
        rel .addPair("a", "amaca");
        System.out.println( rel .isSymmetric());
        rel .addPair("albero", "a");
        rel .addPair("amaca", "a");
        System.out.println( rel .isSymmetric());
        System.out.println( rel .areRelated("a", "amaca"));*/
        
        
        Employee e1=new Employee(150,5);          //bonus+200
        Employee e2=new Employee(1600,5);         //niente bonus
        Employee e3=new Employee(150,20);        //stipendio < 1500 quindi bonus+200 e anni > 10 quindi bonus+150
        
        System.out.println("L : "+Prova.list);
        
        Thread a=new AgeBonus();
         Thread a1=new AgeBonus();
        a.start();
        a1.start();
        
        Thread l=new LowBonus();
        l.start();
        
        
        try {
            a.join();
        } catch (InterruptedException ex) {
            
        }
        
        try {
            l.join();
        } catch (InterruptedException ex) {
            
        }
        
        System.out.println("L : "+Prova.list);
 
    } 
}
