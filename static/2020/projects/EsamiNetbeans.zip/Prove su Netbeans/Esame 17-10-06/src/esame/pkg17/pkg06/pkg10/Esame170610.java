package esame.pkg17.pkg06.pkg10;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
//Esercizio 1
class A {
        public String f (Object x, Object y, B z) { return "A1"; }
        private String f(A x, B y, B z) { return "A2"; }
}
class B extends A {
        public String f(Object x, A y, A z) { return "B1 + " + f(null, new B(), new B()); }
        private String f(B x, B y, B z) { return "B2"; }
}



/* Esercizio 2
Data la seguente enumerazione:
enum Specialista { OCULISTA, PEDIATRA; }
Realizzare la classe Clinica, che permette di prenotare e cancellare visite mediche. I metodi prenota e
cancellaPrenotazione accettano uno specialista e il nome di un paziente, ed effettuano o cancellano la
prenotazione, rispettivamente. Il metodo getPrenotati restituisce l’elenco dei prenotati.
La classe deve rispettare le seguenti proprieta':
(a) Non ci si può prenotare con più di uno specialista.
(b) Si deve poter aggiungere uno specialista all’enumerazione senza dover modificare la classe Clinica.
Inoltre, l’implementazione deve rispettare il seguente esempio d’uso:

Esempio d’uso:
Clinica c = new Clinica();
c.prenota(Specialista.OCULISTA, ”Pippo Franco”);
c.prenota(Specialista.OCULISTA, ”Leo Gullotta”);
c.prenota(Specialista.OCULISTA, ”Leo Gullotta”);
c.prenota(Specialista.PEDIATRA, ”Ciccio Ingrassia”);
c.prenota(Specialista.PEDIATRA, ”Leo Gullotta”);
c.cancellaPrenotazione(Specialista.PEDIATRA, ”Ciccio Ingrassia”);
Collection<String> ocu = c.getPrenotati(Specialista.OCULISTA);
System.out.println(ocu);
System.out.println(c.getPrenotati( Specialista .PEDIATRA));

Output:
[Leo Gullotta, Pippo Franco]
[]
 */
enum Specialista{
    OCULISTA,
    PEDIATRA
}
class Clinica{
    
    private Map<Specialista,Set<String>> M;
    public Clinica(){
        M=new HashMap();
    }
    
    public void prenota(Specialista s,String n){
         
        for(Specialista s1: M.keySet()){   //s1 sarà via via la chiave della mappa
            if(M.get(s1).contains(n))      //se il set associato alla chiave contiene già il nome (n)
                return;                   //Ritorno nel main senza fare nient'altro
        }
      
        Set<String> set=M.get(s);
        if(set==null){
            set=new HashSet();
            set.add(n);
            M.put(s,set);
        }
        else
            set.add(n);
      
    }
    
    public void cancellaPrenotazione(Specialista s,String n){
        if(M.get(s)!=null)         //Se fosse null avrei un errore, perchè avrei null.remove(n);
           M.get(s).remove(n);     //Cancello dal set il nome (n)
    }
    
    public Collection<String> getPrenotati(Specialista s){
        return M.get(s);  //restituisco l'intero set
    }
}


/*
Il seguente thread accede ad un array di interi, precedentemente istanziato.
class MyThread extends Thread {
public void run() {
int tot = 0;
_____1_____
for (int i=0; i<array.length; i++) {
_____2_____
tot += array[i];
array[ i ] = 0;
_____3_____
}
_____4_____
System.out.println(tot);
}
}
Un programma avvia due thread di tipo MyThread, con l’obiettivo di ottenere l’output
   <totale dell’array>
   0

Dire quali dei seguenti inserimenti garantiscono l’output desiderato (è possibile indicare più risposte):
(a) 1 = “synchronized (this){” 4 = “}”
(b) 1 = “synchronized {” 4 = “}”
(c) 1 = “synchronized (array){” 4 = “}”
(d) 1 = “synchronized (tot){” 4 = “}”
(e) 2 = “synchronized (this){” 3 = “}”
(f) 2 = “synchronized (array){” 3 = “}”
*/
//ARRAY: 4 2 3 1
//a) so che il synchronized(this) non serve a granchè, so che quindi i due thread lavoreranno contemporaneamente: 
           //potrebbe uscire (10 e 0), (4,6), (6,4), (9,1),(5,5) eccecc
//b) sbagliata la sintassi
//c) si, il risultato sarà sempre 10 0, perchè il sinchronized su un oggetto dove ci interagiscono entrambi sincronizza i thread.
    //se entra prima t1 allora lui farà tutto ciò che sta dentro il blocco e t2 lo aspetterà.
//d) sbagliata, non si può chiamare il synchronized su un intero ma solo sui reference (array, liste, gli oggetti insomma)
//e) stesso discorso di a), il syncronized this è totalmente inutile
//f) no, se vogliamo sincronizzare i thread il blocco deve contenere TUTTE le operazioni che fanno, ANCHE entrare nel for
    //in questo caso i thread possono entrare nel for contemporaneamente e quindi rendere tutto inutile.


public class Esame170610 {
    
    private static int[] array=new int[4];
    
    static class MyThread extends Thread {
    
    public void run() {

        int tot = 0;
  
        for (int i=0; i<array.length; i++) {
              synchronized(array){
            System.out.println("Thread : "+Thread.currentThread().getName());
            tot += array[i];
            array[i]=0;
        }
    }
        System.out.println("Thread : "+Thread.currentThread().getName()+" : "+tot);
    }
}
    
    public static void main(String[] args) {
       //Esercizio 1
        B beta = new B();
        A alfa = beta;
        
        //System.out.println( alfa . f ( alfa , beta, beta));
         //System.out.println(beta. f (beta, alfa , alfa ));
       // System.out.println(beta. f (null, beta, beta));
        //System.out.println(beta.equals( (Object)alfa ));
        
        //Esercizio 2
       /* Clinica c = new Clinica();
        c.prenota(Specialista.OCULISTA, "Pippo Franco");
        c.prenota(Specialista.OCULISTA, "Leo Gullotta");
        c.prenota(Specialista.OCULISTA, "Leo Gullotta");
        c.prenota(Specialista.PEDIATRA, "Ciccio Ingrassia");
        c.prenota(Specialista.PEDIATRA, "Leo Gullotta");
        c.cancellaPrenotazione(Specialista.PEDIATRA, "Ciccio Ingrassia");
        Collection<String> ocu = c.getPrenotati(Specialista.OCULISTA);
        System.out.println(ocu);
        System.out.println(c.getPrenotati( Specialista .PEDIATRA));*/
       
       
       array[0]=4;
       array[1]=2;
       array[2]=3;
       array[3]=1;
       Thread t=new MyThread();
       t.start();
         Thread t1=new MyThread();
       t1.start();
        try {
            t.join();
        } catch (InterruptedException ex) {
            Logger.getLogger(Esame170610.class.getName()).log(Level.SEVERE, null, ex);
        
            try {
            t1.join();
        } catch (InterruptedException ex2) {
            Logger.getLogger(Esame170610.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
  }
    
}
