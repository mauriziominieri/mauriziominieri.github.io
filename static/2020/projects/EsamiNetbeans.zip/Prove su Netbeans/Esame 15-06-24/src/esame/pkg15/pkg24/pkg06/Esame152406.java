package esame.pkg15.pkg24.pkg06;
import java.util.*;

/*
class A {
        public String f(A x, A y, B z) { return "A1"; }
        public String f(A x, Object y, B z) { return "A2"; }
        public String f(B x, Object y, B z) { return "A3"; }
}
class B extends A {
        public String f(A x, A y, B z) { return "B1"; }
        public String f(A x, Object y, A z) { return "B2"; }
        public String f(A x, Object y, B z) { return "B3"; }
}
*/

/*
Realizzare la classe Controller, che rappresenta una centralina per autoveicoli, e la classe Function,
che rappresenta una funzionalità del veicolo, che può essere accesa o spenta. Alcune funzionalità
sono incompatibili tra loro, per cui accenderne una fa spegnere automaticamente l’altra.
La classe Controller ha due metodi: addFunction aggiunge al sistema una nuova funzionalità con
un dato nome; printOn stampa a video i nomi delle funzionalità attive. La classe Function ha tre
metodi: turnOn e turnOff per attivarla e disattivarla; setIncompatible accetta un’altra funzionalità
x e imposta un’incompatibilità tra this e x.
Leggere attentamente il seguente caso d’uso, che mostra, tra le altre cose, che l’incompatibilità è
automaticamente simmetrica, ma non transitiva.

Caso d’uso:
Controller c = new Controller();
Controller.Function ac = c.addFunction("Aria␣condizionata");
Controller.Function risc = c.addFunction("Riscaldamento");
Controller.Function sedile = c.addFunction("Sedile␣riscaldato");
ac.setIncompatible(risc );
ac.setIncompatible(sedile );
ac.turnOn();
c.printOn();
System.out.println("−−−−");
risc .turnOn();
sedile .turnOn();
c.printOn();

Output:
Aria condizionata
----
Sedile riscaldato
Riscaldamento
*/

class Controller{
    private Map<Function,Set<Function>> M;
    public Controller(){
        M=new HashMap();
    }
    public Function addFunction(String s){
        Function f=new Function(s);
        return f;
    }
    
    public void printOn(){
        for(Function f:M.keySet()){
            if(f.on==true)
                System.out.println(f);
        }
    }
    
    
    class Function{
        private String nome;
        private boolean on=false;
        
        public Function(String s){
            nome=s;
        }
        
        public void setIncompatible(Function f){
            Set<Function> set=M.get(this);
            if(set==null){
                set=new HashSet();
                set.add(f);
                M.put(this,set);
            }
            else
                set.add(f);
            
            Set<Function> set2=M.get(f);
            if(set2==null){
                set2=new HashSet();
                set2.add(this);
                M.put(f,set2);
            }
            else
                set2.add(this);
        }
        
        public void turnOn(){
            on=true;
            for(Function f:M.get(this)){
                f.on=false;
            }
        }
        
         public void turnOff(){
            on=false;
            for(Function f:M.get(this)){
                f.on=true;
            }
        }
         
         public String toString(){
             return nome;
         }
    }
}


/*
class Controller {                              //Metodo alternativo strutturando la classe Function come una serie(Set).
    
    private Map<String, Function> functionality = new HashMap<>();
    
    public Function addFunction(String name) {
        Function f = new Function();
        functionality.put(name, f);
        
        
        return f;
    }
    
    public void printOn() {
        for (String s : functionality.keySet())               //Scorro la set di aria condizionata
            if (functionality.get(s).getState())               //se il loro stato è true
                System.out.println(s);                          //stampo il nome
    }  
    
    
    public class Function {
        
        private boolean state;
        private Set<Function> incompatibleTo;
        
       
        
        public Function(){
            incompatibleTo = new HashSet<>();             
        }
        
        public void turnOn() { 
            state = true; 
            
            for (Function f : incompatibleTo)
                f.state = false;
        }
        
        public void turnOff() { 
            state = false; 
            
            for (Function f : incompatibleTo)
                f.state = true;
        }
        
        public boolean getState() { return state; }
        
        public void setIncompatible(Function f) { 
            incompatibleTo.add(f);
            f.incompatibleTo.add(this);
           
           
        }     
    }
}
*/





 class SimpleThread extends Thread
            {
            private static volatile int n = 0;            //volatile cioè una variabile il cui valore sarà cambiato da più thread
            public void run() {
            n++;
            int m = n;
            System.out.println(m);
            }
                  
}



//Esercizio 4
class Test{
    
    public static LinkedList Listintersection(LinkedList l,Set<Integer> s){
        LinkedList<Integer> l2=new LinkedList();
        Iterator i=l.iterator();
        Integer curr=null;
        while(i.hasNext()){
            curr=(Integer) i.next();
            for(Integer elem: s){
                if(curr==elem)
                    l2.add(curr);
            }
        }
     
        return l2;
    }
}



public class Esame152406 {
   
    public static void main(String[] args) {
      
      /*  B beta = new B();
        A alfa = beta;
       // System.out.println( alfa . f ( alfa , alfa , null));
        //System.out.println(beta. f ( alfa , beta, beta));                           //Esercizio 1
       // System.out.println(beta. f (beta, beta, beta));
       // System.out.println(beta. f ( alfa , alfa , alfa ));*/

        
        Controller c = new Controller();
        Controller.Function ac = c.addFunction("Aria␣condizionata");
        Controller.Function risc = c.addFunction("Riscaldamento");
        Controller.Function sedile = c.addFunction("Sedile␣riscaldato");
        ac.setIncompatible(risc );
        ac.setIncompatible(sedile );
        ac.turnOn();
        c.printOn();
        System.out.println("−−−−");
        risc .turnOn();
        sedile .turnOn();
        c.printOn();
        
        
        
        
         /* Thread t1=new SimpleThread();
          Thread t2=new SimpleThread();
 
          t2.start();t1.start(); */
         // try{Thread.sleep(1000);} catch(InterruptedException e){return;}
         

        
         /* Set<Integer> s=new HashSet();
         s.add(1);
          s.add(3);
           s.add(2);
            s.add(0);
            
            LinkedList<Integer> l=new LinkedList();
            l.add(3);
            l.add(10);
            l.add(1);
            l.add(20);
            
            for(Integer elem: s)
               System.out.println(elem);
             System.out.println("\n\n");
             for(Integer elem: l)
               System.out.println(elem);
             
              System.out.println("\n\n");
             LinkedList<Integer> l2=Test.Listintersection(l,s);
              for(Integer elem: l2)
               System.out.println(elem);*/
    }
    
}
