/*
 [CrowdGrader] Realizzare la classe Pizza, in modo che ad ogni oggetto si possano assegnare degli
ingredienti, scelti da un elenco fissato. Ad ogni ingrediente è associato il numero di calorie che apporta
alla pizza. Gli oggetti di tipo Pizza sono dotati di ordinamento naturale, sulla base del numero totale di
calorie. Infine, gli oggetti di tipo Pizza sono anche clonabili.

Esempio d'uso:
Pizza margherita = new Pizza(), marinara = new Pizza();
margherita.addIngrediente(Pizza.Ingrediente.POMODORO);
margherita.addIngrediente(Pizza.Ingrediente.MOZZARELLA);
marinara.addIngrediente(Pizza.Ingrediente.POMODORO);
marinara.addIngrediente(Pizza.Ingrediente.AGLIO);
Pizza altra = margherita.clone();
System.out.println( altra .compareTo(marinara));

Output:
1
 */
package esame.pkg14.pkg03.pkg11;
import java.util.*;



class A {            //Esercizio 1
    public String f(Object a, B b) { return "A1"; }
    public String f(C a, B b) { return "A2"; }
}
class B extends A {
    public String f(Object a, B b) { return "B1+" + f(b, null); }
    public String f(A a, B b) { return "B2"; }
}
class C extends B {
    public String f(Object a, B b) { return "C1+" + f(this, b); }
    private String f(B a, B b) { return "C2"; }
}






class Pizza implements Comparable,Cloneable{
    private int kcal_tot;
    
    public enum Ingrediente{
        POMODORO(18),MOZZARELLA(300),AGLIO(149);
        private int kcal;
        
        private Ingrediente(int kcal) {            
            this.kcal = kcal;
          //  System.out.println(kcal);
        }
    }
    
   
    
    protected Pizza clone(){                             //return this non è la stessa cosa perchè in quel caso stai restituendo lo stesso spazio di memoria di this
        try{                                                //invece con clone() io voglio proprio creare un nuovo oggetto clone, quindi in un altro spazio di memoria
            return(Pizza) super.clone();
        }
        catch(CloneNotSupportedException e){throw new RuntimeException(e);}
    }
    
    public void addIngrediente(Ingrediente i){
          kcal_tot=kcal_tot+i.kcal;
        //  System.out.println("kcal_tot : "+kcal_tot);
    }
    
    public int compareTo(Object o){
        Pizza p1=(Pizza) o;
        if(kcal_tot>p1.kcal_tot)
            return 1;
        else if(kcal_tot<p1.kcal_tot)
            return -1;
        else
            return 0;
    }

    public void Stampa(){
        System.out.println(this);
    }
    
    public String toString(){
        return "["+kcal_tot+"]";
    }
}



public class Esame140311{
    
   
 
    public static void main(String[] args) {
      
       /* C gamma = new C();          //Esercizio 1
        B beta = gamma;
        A alfa = gamma;
        System.out.println(gamma.f(beta, beta));
        System.out.println( alfa . f (beta, gamma));
        System.out.println(9 & 12);*/
        
        
        Pizza margherita = new Pizza(), marinara = new Pizza();  //Esercizio 2
        margherita.addIngrediente(Pizza.Ingrediente.POMODORO);       //Ingrediente già capisco debba essere il nome del mio elenco
        margherita.addIngrediente(Pizza.Ingrediente.MOZZARELLA);
       // margherita.Stampa(); marinara.Stampa();
        marinara.addIngrediente(Pizza.Ingrediente.POMODORO);
        marinara.addIngrediente(Pizza.Ingrediente.AGLIO);
       // margherita.Stampa(); marinara.Stampa();
        Pizza altra = margherita.clone();
       // margherita.Stampa(); marinara.Stampa(); altra.Stampa();
        System.out.println(altra.compareTo(marinara));
        
        
        
    }


}
