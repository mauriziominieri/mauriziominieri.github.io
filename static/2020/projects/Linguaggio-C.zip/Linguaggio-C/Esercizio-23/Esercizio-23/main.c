//
//  main.c
//  Esercizio-23
//
//  Created by Maurizio Minieri on 11/12/20.
//
/*
 Si progetti ed implementi in C/C++ un algoritmo che, presa da standard input una sequenza di n interi, fornisca su
 standard output il valore minimo.
 */

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

int main(int argc, const char * argv[]) {
    
    int n,x;
    int min,null=1;
    
    printf("Inserisci un numero intero n: ");
    scanf("%d",&n);
    
    for(int i=0;i<n;i++) {
        printf("Inserisci il %d° numero: ",i+1);
        scanf("%d",&x);
        
        if(null==1) {
            min = x;
            null = 0;
        }
        else if(x<min)
            min = x;
    }
    
    printf("\nIl valore minimo è: %d",min);
    
    printf("\n\n");
    return 0;
}
