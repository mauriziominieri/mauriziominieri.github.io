//
//  main.c
//  Esercizio-20
//
//  Created by Maurizio Minieri on 10/12/20.
//
/*
 Si progetti ed implementi in C/C++ un algoritmo che, presa da standard input una sequenza qualunque di caratteri
 (inclusi ’spazio’, ’\n’ e ’\t’) terminata con un ’.’, conti e fornisca su standard output
 1. il numero di caratteri;
 2. il numero di parole;
 3. il numero di linee.
 */

#include <stdio.h>
#include <string.h>
#define LENGTH 32

int main(int argc, const char * argv[]) {
    
    char sequenza[LENGTH];
    int parole = 1,linee = 0;
    
    printf("Inserisci una sequenza di caratteri: ");
    fgets(sequenza,LENGTH,stdin);
    //scanf("%s",sequenza);
    
    for(int i=0;i<strlen(sequenza);i++) {
        if(sequenza[i]=='.') break;
        if(sequenza[i]==' ') parole++;
        if(sequenza[i]=='\n') linee++;
    }
    
    printf("\nNumero caratteri: %lu\n",strlen(sequenza));
    printf("Numero parole: %d\n",parole);
    printf("Numero linee: %d",linee);
    printf("\n\n");
    return 0;
}
