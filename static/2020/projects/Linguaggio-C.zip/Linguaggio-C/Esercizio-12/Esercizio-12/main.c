//
//  main.c
//  Esercizio-12
//
//  Created by Maurizio Minieri on 10/12/20.
//
/*
 Si progetti ed implementi in C/C++ un algoritmo che, presa da standard input una sequenza di numeri interi terminata da un numero negativo, calcoli la media aritmetica dei numeri non negativi letti, e fornisca su standard output
 il risultato.
 Il programma deve controllare anche che la sequenza non sia vuota, nel qual caso deve informare l’utente con
 opportuno messaggio in output.
 */

#include <stdio.h>

int main(int argc, const char * argv[]) {
    
    int n,conta=0,somma=0;
    
    printf("Inserisci una sequenza di numeri interi terminata da un numero negativo\n");
    do {
        scanf("%d",&n);
        if(n>=0) {
            somma = somma + n;
            conta++;
        }
    } while(n>=0);
    
    float media = (float)somma/conta;
    
    printf("La media è: %f",media);
    
    printf("\n\n");
    return 0;
}
