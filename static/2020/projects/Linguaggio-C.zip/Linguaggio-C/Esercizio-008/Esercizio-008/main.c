//
//  main.c
//  Esercizio-008
//
//  Created by Maurizio Minieri on 18/12/20.
//
/*
 Stampa il bit in posizione i-esima di un numero intero N
 */

#include <stdio.h>
#include <math.h>
#include <stdbool.h>

bool checkIntero(float numero) {
    
    int tmp;
    
    tmp = floor(numero);    //tmp = (int)numero;
    if(numero == tmp) return true;
    else return false;
}

void convertiDecimaleBinario(int numero){
    
    int binario[32];  //il massimo numero intero rappresentabile è 2 alla 32 = 4294967296.
    //2 alla 31 = 2147483648, alla 30 = 1073741824
    int num,i;
    num = numero;
    
    for(i=0;i<32;i++)
    binario[i] = 0;
    
    i = 31;
    while(num != 0) {
        binario[i] = num % 2;
        num /= 2;  //num = num / 2;
        i--;
    }
    
    printf("\n%d in binario: ",numero);
    for(i=0;i<32;i++)
    printf("%1d",binario[i]);  //0 spazi, %2d mette uno spazio tra i numeri
}

bool checkBinario(int numero) {
    int n;
    
    while(numero) {  //>0 implicito
        n = numero % 10;

        if(n * n != n)
            return false;
        numero/=10;
    }
    
    return true;
}

void convertiBinarioDecimale(int numero) {
    
    int decimale=0,i=0,n=numero;
    //dato che è un binario a me interessa sapere solo se passo dopo passo ho 0 oppure 1
    //i=0 -> n = 101, diviso 10 non fa resto 0 quindi-> decimale = 0 + 1, n = 10
    //i=1 -> n = 10, diviso 10 fa resto 0, decimale = 1, n = 1
    //i=2 -> n = 1, diviso 10 non fa resto 0 -> decimale = 1 + 4, n = 0
    //i=3 -> n = 0
    
    
    while(n>0) {
        if(n%2!=0)
            decimale += pow(2,i);
        n/=10;
        i++;
    }
    
    printf("\n\n%d in decimale: %d",numero,decimale);
}

int main(int argc, const char * argv[]) {
    
    float numeroP;
    int numero,i,bit,bit_pos;
    
    do {
        printf("Inserisci un numero intero: ");    //se numero = 7 allora (00000111)
        scanf("%f",&numeroP);
    }
    while(checkIntero(numeroP) == false && printf("Errore, non è un numero intero. Riprova\n"));
    
    numero = numeroP;
    
    printf("Inserisci la posizione: ");
    scanf("%d",&i);                         //es: 3
    
    if(i>(8*sizeof(int)))   //un intero è composto da 32 bit, il sizeof mi darà il risultato in byte.
        printf("\nLa posizione indicata eccede il numero di bit di un intero");
    else {
        convertiDecimaleBinario(numero);
        bit_pos = 1 << (i-1);   //faccio un left shift del numero binario 1 di (i-1) posizioni. Sposterò 00000001 di 2 posizioni a sinistra -> bit_pos = 00000100
        bit = numero & bit_pos; //faccio un AND tra bit. Es: 00000111 AND 00000100 = 00000100
        bit = bit >> (i-1); //right shift di 00000100 di 2 posizioni -> 00000001
        printf("\nIl %d° bit di %d è: %d",i,numero,bit);
    }
    
    printf("\n\n");

    do {
        printf("Inserisci un numero binario: ");
        scanf("%d",&numero);
    }
    while(checkBinario(numero) == false && printf("Errore, non è un numero binario. Riprova\n"));

    convertiBinarioDecimale(numero);
    
    printf("\n\n");
    return 0;
}
