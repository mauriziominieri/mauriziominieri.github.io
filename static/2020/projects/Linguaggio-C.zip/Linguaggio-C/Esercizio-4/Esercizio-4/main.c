//
//  main.c
//  Esercizio-4
//
//  Created by Maurizio Minieri on 09/12/20.
//
/*
 Si progetti ed implementi in C/C++ un algoritmo che, presi da standard input tre numeri interi x, y e z, calcoli e
 fornisca in output la loro media aritmetica.
 */

#include <stdio.h>

int main(int argc, const char * argv[]) {
    
    int x,y,z;
    
    printf("Inserisci il primo numero (x): ");
    scanf("%d",&x);
    printf("Inserisci il secondo numero (y): ");
    scanf("%d",&y);
    printf("Inserisci il terzo numero (z): ");
    scanf("%d",&z);
    
    printf("\nLa media e': %f",(float)(x+y+z)/3);
    
    printf("\n\n");
    return 0;
}
