//
//  main.c
//  Esercizio-8
//
//  Created by Maurizio Minieri on 09/12/20.
//
/*
 Si progetti ed implementi in C/C++ un algoritmo che, presi da standard input due numeri interi a e b, calcoli e
 fornisca su standard output
 1. a alla b;
 2. a × 10 alla b;
 3. a + 10 alla b;
 */

#include <stdio.h>

int main(int argc, const char * argv[]) {
    
    int a,b;
    
    printf("Inserisci il primo numero (a): ");
    scanf("%d",&a);
    
    do {
        printf("Inserisci il secondo numero (b): ");
        scanf("%d",&b);
    } while(b<0);
    
    int r1 = 1,r2 = 1;
    
    for(int i=0;i<b;i++) {
        r1 = r1 * a;
        r2 = r2 * 10;  //10 alla b
    }
    
    printf("\na:%d alla b:%d = %d\n",a,b,r1);
    printf("a:%d * 10 alla b:%d = %d\n",a,b,a*r2);
    printf("a:%d + 10 alla b:%d = %d",a,b,a+r2);
    printf("\n\n");
    return 0;
}
