//
//  main.c
//  Esercizio-9
//
//  Created by Maurizio Minieri on 10/12/20.
//
/*
 Si progetti ed implementi in C/C++ un algoritmo che, preso da standard input un numero intero N, controlli che
 N ≥ 0 e in tal caso calcoli e fornisca su standard output tutti i quadrati perfetti da 0 ad N.
 Nota: Dato un numero a, il suo quadrato perfetto è a alla 2.
 */

#include <stdio.h>

int main(int argc, const char * argv[]) {
    
    int N;
    
    do {
        printf("Inserisci un numero intero (N): ");
        scanf("%d",&N);
    } while(N<0 && printf("N deve essere >= 0 \n"));
    
    for(int i=0;i<N;i++)
        printf("Quadrato perfetto di %d: %d\n",i,i*i);
    
    printf("\n\n");
    return 0;
}
