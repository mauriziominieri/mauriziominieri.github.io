//
//  main.c
//  Esercizio-24
//
//  Created by Maurizio Minieri on 11/12/20.
//
/*
 Si progetti ed implementi in C/C++ un algoritmo che, letta da standard input una sequenza di caratteri (di lunghezza
 massima n) e terminata da un ’.’, controlli se la sequenza è palindroma.
 Esempi:
 radar e abba sono palindrome.
 abcabc non è palindroma.
 */

#include <stdio.h>
#include <string.h>

int pal (char s1[]){
    
    if(s1[strlen(s1)-1]=='.')  //se l'ultimo carattere è un punto
        s1[strlen(s1)-1] = '\0';  //ci metto null, quindi tolgo il punto
    
    int i = 0;  //inizio
    long f = strlen(s1) - 1;  //in realtà  mela è mela\0 , dove \0 è il carattere null, e strlen conta fino a quel carattere
    //con mela h è 4
    
    while (f > i) {
        if (s1[i++] != s1[f--]) {
            return 0;
        }
    }
    return 1;
}

int main(int argc, const char * argv[]) {
    
    int n = 2;
    char parola[n];
    
    for(int i=0;i<n;i++) {
        printf("Inserisci il %d° carattere: ",i+1);
        scanf(" %c",&parola[i]);
        if(parola[i]=='.')
            break;
    }
    
    if(pal(parola)==1)
        printf("\n%s è palindroma\n", parola);
    else
        printf("\n%s NON è palindroma\n", parola);
    
    printf("\n\n");
    return 0;
}
