//
//  main.c
//  Esercizio-3
//
//  Created by Maurizio Minieri on 09/12/20.
//
/*
 Si progetti ed implementi in C/C++ un algoritmo che, presi da standard input due numeri interi a ≥ 0 e b ≥ 0, ne
 determini il prodotto p, fornendo il risultato su standard output.
 */

#include <stdio.h>
#include <stdlib.h>

int main(int argc, const char * argv[]) {
    
    int a,b;
    
    printf("Inserisci il primo numero (a): ");
    scanf("%d",&a);
    printf("Inserisci il secondo numero (b): ");
    scanf("%d",&b);
    
    int p = 0;
    
    if(a>=0 && b>=0) {
        p = a * b;
        printf("\nIl prodotto e': %d",p);
    }
    
    printf("\n\n");
    return 0;
}
