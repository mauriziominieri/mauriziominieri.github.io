//
//  main.c
//  Esercizio-1
//
//  Created by Maurizio Minieri on 09/12/20.
//
/*
 Si progetti ed implementi in C/C++ un algoritmo che, presi da standard input due numeri reali a e b, effettui le 4
 operazioni
 1. a + b;
 2. a − b;
 3. a × b;
 4. a / b
 .
 Assicurandosi che i risultati siano definiti, l’algoritmo deve fornire su standard output questi ultimi.
 */

//a = [13.0]
//b = [0.0]

#include <stdio.h>

int main(int argc, const char * argv[]) {
    
    float a = 19.0,b = 7.0;    /*definisco due variabili reali*/
    //char = %c
    //int = %d
    //float = %f
    
    //printf("Il valore di a è uguale a: %f",a);

    printf("CIAO GIORGIO, Inserisci il primo numero (a): ");  //C++ --> cout << "Inserisci il primo numero:"
    scanf("%lf",&a); //C++ --> cin >> a;  //vammi a riempiere l'indirizzo di memoria della variabile a
    printf("Inserisci il secondo numero (b): ");
    scanf("%lf",&b); //C++ --> cin >> b;
    
    printf("\n1. La somma di %.2f e %.2f e': %.2f",a,b,(a+b));
    printf("\n2. La differenza di %.2f e %.2f e': %.2f",a,b,(a-b));
    printf("\n3. La moltiplicazione di %.2f e %f e': %.2f",a,b,(a*b));
    printf("\n4. La divisione di %f e %.2f e': %.2f",a,b,(a/b));
    
    printf("\n\n");
    return 0;
}
